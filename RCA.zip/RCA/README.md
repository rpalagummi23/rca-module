# 🌾 Agricultural Field Inspection Variance Analysis System

A comprehensive system for analyzing variances between field inspection actuals and recommended practices in agriculture, with root cause analysis capabilities and an interactive Streamlit dashboard.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [Database Schema](#database-schema)
- [Variance Analysis Logic](#variance-analysis-logic)
- [Root Cause Analysis](#root-cause-analysis)
- [Streamlit Dashboard](#streamlit-dashboard)
- [Configuration](#configuration)
- [API Reference](#api-reference)

---

## Overview

This system compares actual field observations from agricultural inspections against recommended (master) values for each Crop-Variety-Season (CVS) combination. It calculates variance per attribute, produces decomposition summaries, and categorizes likely root causes.

### Key Capabilities

- **Row-level variance calculation** for dates, numeric values, and categorical attributes
- **Rule-based root cause assignment** with configurable heuristics
- **Variance decomposition** showing contribution of each attribute
- **Multi-dimensional aggregation** by Crop/Variety/Season, geography, and time
- **Interactive dashboard** for visualization and drill-down analysis

---

## Features

### ✅ Complete Standalone Schema
- Full PostgreSQL schema with dimension tables, fact tables, and metadata
- Realistic synthetic seed data for testing and demonstration
- 50+ inspection records across multiple crops, varieties, and locations

### ✅ Comprehensive Variance Analysis
- Date variance: days difference with early/late/on-time classification
- Numeric variance: absolute difference, percentage, z-score calculation
- Tolerance checking with configurable thresholds
- Severity flagging (OK, WARNING, CRITICAL)

### ✅ Root Cause Analysis Engine
- Rule-based reason code assignment
- Priority-ordered rule evaluation
- Multiple reason codes per inspection
- Configurable rules via YAML/JSON

### ✅ Interactive Dashboard
- Real-time filtering by crop, variety, category, district
- Variance distribution visualizations
- Attribute-level analysis
- Geographic insights
- Detailed inspection drill-down

---

## Quick Start

### Prerequisites

- Python 3.9+
- PostgreSQL 14+ (optional, for database storage)

### Installation

```bash
# Clone or navigate to the project
cd /path/to/RCA

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Run Demo Analysis

```bash
# Run variance analysis with synthetic data (no database required)
python variance_analysis.py
```

### Launch Dashboard

```bash
# Start Streamlit dashboard
streamlit run streamlit_app.py
```

The dashboard will open at `http://localhost:8501`

### Database Setup (Optional)

```bash
# Connect to PostgreSQL and run schema
psql -h localhost -U your_user -d your_database -f schema.sql
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        DATA SOURCES                              │
├─────────────────────────────────────────────────────────────────┤
│  Inspections    │  Recommendations  │  Metadata                 │
│  (Actuals)      │  (Master Values)  │  (Tolerances, Weights)    │
└────────┬────────┴────────┬──────────┴────────┬──────────────────┘
         │                 │                    │
         └────────────────┼────────────────────┘
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    VARIANCE CALCULATOR                           │
├─────────────────────────────────────────────────────────────────┤
│  • Merge inspections with recommendations (by CVS)              │
│  • Compute date variances (days difference)                     │
│  • Compute numeric variances (diff, %, z-score)                 │
│  • Apply tolerances and flag severity                           │
│  • Standardize and weight contributions                         │
└────────┬────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   REASON CODE ENGINE                             │
├─────────────────────────────────────────────────────────────────┤
│  • Evaluate rule conditions per inspection                      │
│  • Match patterns: timing slip, pest pressure, etc.             │
│  • Assign multiple reason codes with priority                   │
└────────┬────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  VARIANCE DECOMPOSER                             │
├─────────────────────────────────────────────────────────────────┤
│  • Compute overall variance score per inspection                │
│  • Categorize: LOW / MEDIUM / HIGH / CRITICAL                   │
│  • Identify top variance drivers                                │
│  • Aggregate by CVS, location, time                             │
└────────┬────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    OUTPUT & STORAGE                              │
├─────────────────────────────────────────────────────────────────┤
│  fact_variance           │  fact_inspection_variance_summary    │
│  agg_variance_by_cvs     │  agg_variance_by_location            │
└──────────────────────────┴──────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  STREAMLIT DASHBOARD                             │
├─────────────────────────────────────────────────────────────────┤
│  📊 Overview      │  🔬 Attributes   │  🔍 Root Causes          │
│  🗺️ Geography    │  🌱 Crops        │  📋 Details               │
└─────────────────────────────────────────────────────────────────┘
```

---

## Database Schema

### Dimension Tables

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `season` | Agricultural seasons | season_id, season_code, season_start_date |
| `crop` | Crop types | crop_id, crop_code, crop_name, crop_category |
| `variety` | Seed varieties | variety_id, crop_id, variety_code, variety_type |
| `location` | Geographic hierarchy | location_id, location_type, agro_climatic_zone |
| `farm` | Farm records | farm_id, farmer_name, location_id |
| `field` | Field within farm | field_id, farm_id, soil_type, irrigation_type |
| `plot` | Plot within field | plot_id, field_id, area_ha |

### Metadata Tables

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `meta_attribute` | Attribute definitions | attribute_id, attribute_code, data_type, comparison_method |
| `meta_tolerance` | Tolerance configurations | attribute_id, tolerance_type, tolerance_value, tolerance_pct |
| `meta_variance_weight` | Weight assignments | attribute_id, weight_value |

### Master Data

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `master_recommendation` | Recommended values | crop_id, variety_id, season_id, rec_* columns |

### Fact Tables

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `inspection` | Actual observations | inspection_id, CVS IDs, actual_* columns |
| `fact_variance` | Computed variances | inspection_id, attribute_id, variance_*, status |
| `fact_inspection_variance_summary` | Inspection-level summary | inspection_id, overall_variance_score, reason_codes |

---

## Variance Analysis Logic

### Date Variance

```
variance_days = actual_date - recommended_date

Status:
  - ON_TARGET: |variance_days| <= tolerance
  - EARLY: variance_days < -tolerance
  - LATE: variance_days > tolerance

Standardized: min(|variance_days| / 30, 1.0)
```

### Numeric Variance

```
variance_numeric = actual - target

variance_pct = (variance_numeric / target) * 100

z_score = variance_numeric / stddev (if available)

Status:
  - ON_TARGET: within tolerance
  - ABOVE: positive variance, outside tolerance
  - BELOW: negative variance, outside tolerance

Standardized: min(|z_score| / 3, 1.0) or min(|variance_pct| / 100, 1.0)
```

### Overall Score

```
overall_score = Σ (weight[attr] × standardized_variance[attr])

Category:
  - LOW: score <= 0.20
  - MEDIUM: 0.20 < score <= 0.40
  - HIGH: 0.40 < score <= 0.60
  - CRITICAL: score > 0.60
```

---

## Root Cause Analysis

### Reason Code Rules

| Rule | Conditions | Description |
|------|------------|-------------|
| `upstream_timing_slip` | Late soaking + Late sowing | Upstream delay cascading |
| `transplant_delay` | Transplant date >7 days late | Seedling establishment risk |
| `pest_pressure` | High pest + Low health | Pest damage impacting crop |
| `disease_outbreak` | High disease + Low health | Disease affecting crop |
| `establishment_issue` | Low plant ratio + Late transplant | Poor stand development |
| `poor_germination` | Low plant ratio | Below-target population |
| `low_tillering` | Tillers below minimum | Reduced yield potential |
| `early_planting` | Sowing >7 days early | Weather/frost risk |
| `data_quality_issue` | Values out of valid range | Unreliable data |
| `missing_data` | Actual values missing | Incomplete inspection |

### Rule Evaluation

Rules are evaluated in priority order. All matching rules generate reason codes, but the highest-priority match becomes the `primary_reason_code`.

---

## Streamlit Dashboard

### Tab Overview

| Tab | Purpose |
|-----|---------|
| 📊 Overview | Key metrics, category distribution, score histogram |
| 🔬 Attributes | Attribute contribution chart, tolerance performance |
| 🔍 Root Causes | Reason code distribution, detailed explanations |
| 🗺️ Geography | District-level analysis, geographic patterns |
| 🌱 Crops | Crop-variety performance comparison |
| 📋 Details | Individual inspection drill-down |

### Filtering

Use the sidebar to filter by:
- Crop
- Variety
- Variance Category
- District

All visualizations update dynamically based on filters.

---

## Configuration

### Tolerance Configuration (via database or defaults)

```python
tolerances = {
    'SOAKING_DATE': {'type': 'ABSOLUTE', 'value': 3},      # ±3 days
    'SOWING_DATE': {'type': 'ABSOLUTE', 'value': 5},       # ±5 days
    'TRANSPLANT_DATE': {'type': 'ABSOLUTE', 'value': 7},   # ±7 days
    'PEST_SEVERITY': {'type': 'RANGE', 'max': 3},          # 0-3 acceptable
    'TILLER_COUNT': {'type': 'PERCENTAGE', 'pct': 15},     # ±15%
    'HEALTH_SCORE': {'type': 'ABSOLUTE', 'value': 1},      # ±1 score
    'PLANT_RATIO': {'type': 'PERCENTAGE', 'pct': 10},      # ±10%
}
```

### Weight Configuration

```python
weights = {
    'SOAKING_DATE': 0.10,
    'SOWING_DATE': 0.15,
    'TRANSPLANT_DATE': 0.12,
    'FLOWERING_DATE': 0.08,
    'PEST_SEVERITY': 0.15,
    'TILLER_COUNT': 0.12,
    'HEALTH_SCORE': 0.13,
    'PLANT_RATIO': 0.10,
    'DISEASE_SEVERITY': 0.05,
}
# Sum = 1.00
```

---

## API Reference

### Main Classes

```python
# Pipeline orchestration
pipeline = VarianceAnalysisPipeline(connection_string=None)
pipeline.initialize(use_db=False)
pipeline.df_inspections = df_inspections
pipeline.df_recommendations = df_recommendations
results = pipeline.run_analysis()

# Results dictionary contains:
# - 'variance_detail': Per-inspection per-attribute variances
# - 'inspection_summaries': Inspection-level scores and reason codes
# - 'attribute_contributions': Attribute contribution analysis
# - 'cvs_aggregation': Crop-Variety-Season aggregation
# - 'location_aggregation': Location-level aggregation
# - 'reason_code_distribution': Reason code counts
```

### Key Functions

```python
# Generate demo data
df_insp, df_rec = generate_demo_data()

# Run demo
results = run_demo()
```

---

## File Structure

```
RCA/
├── schema.sql              # Complete PostgreSQL schema with seed data
├── variance_analysis.py    # Core analysis logic
├── streamlit_app.py        # Interactive dashboard
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── config/
│   ├── config.yaml         # Configuration file (optional)
│   └── reason_rules.json   # Reason rules (optional)
└── backup/
    ├── schema_backup.sql   # Previous schema version
    └── variance_analysis_backup.py
```

---

## Performance Considerations

- **Indexing**: Key columns are indexed for efficient filtering and joins
- **Batch Processing**: Process inspections in batches for large datasets
- **Materialized Views**: Use for frequently-accessed aggregations
- **Caching**: Streamlit caches data loading with `@st.cache_data`

---

## Support

For questions or issues, contact the Data Architecture Team.

---

*Agricultural Variance Analysis System | Version 1.0 | 2024*
