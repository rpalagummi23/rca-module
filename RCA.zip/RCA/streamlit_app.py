"""
Agricultural Field Inspection - Variance Analysis Dashboard
===========================================================

A Streamlit application for visualizing variance analysis results
and root cause analysis of agricultural field inspections.

This is a UI-only layer that imports:
- Business logic from rca_module
- Styling from ui-kit

Run: streamlit run streamlit_app.py
"""

import streamlit as st
import pandas as pd
import json
from datetime import datetime
from typing import Dict, Tuple

# Import business logic from rca_module
from rca_module import (
    Authenticator,
    DataLoader,
    AnalysisEngine,
    VisualizationHelper,
    get_category_color,
    create_gauge_chart,
    get_reason_code_description,
    ANALYSIS_EXPLANATIONS
)

# Import UI components from ui-kit
from ui_kit.streamlit_integration import (
    inject_prsti_theme,
    metric_card,
    section_header,
    badge,
    info_box
)

# Import for charts
import plotly.express as px
import plotly.graph_objects as go


# =============================================================================
# PAGE CONFIG
# =============================================================================

st.set_page_config(
    page_title="Agricultural Variance Analysis",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =============================================================================
# INJECT UI-KIT THEME
# =============================================================================

inject_prsti_theme()


# =============================================================================
# SESSION STATE INITIALIZATION
# =============================================================================

def initialize_session_state():
    """Initialize session state variables"""
    if 'results' not in st.session_state:
        st.session_state.results = None
    if 'pipeline' not in st.session_state:
        st.session_state.pipeline = None
    if 'data_loaded' not in st.session_state:
        st.session_state.data_loaded = False


# =============================================================================
# DATA LOADING (Using rca_module)
# =============================================================================

@st.cache_data
def load_and_analyze_data():
    """Load demo data and run analysis using rca_module"""
    return DataLoader.load_and_analyze()


# =============================================================================
# AUTHENTICATION UI
# =============================================================================

def render_login_page():
    """Render the login page"""
    # Show sidebar with only the logo (same as after login)
    col1, col2, col3 = st.sidebar.columns([1, 2, 1])
    with col2:
        st.image("assets/logo.png", width=150)
    
    # Center the login form with narrower center column
    col1, col2, col3 = st.columns([2, 1.2, 2])
    
    with col2:
        st.markdown("""
        <div style='text-align: center; padding: 2rem 0;'>
            <h1 style='color: #1e3a5f; margin-bottom: 0.3rem; font-size: 1.8rem;'>Prsti Agricultural Intelligence</h1>
            <h3 style='color: #0d9488; font-size: 1.1rem; font-weight: 500; margin-top: 0;'>Variance Analysis</h3>
        </div>
        """, unsafe_allow_html=True)
        
        # Simple Login title
        st.markdown("""
        <h4 style='color: #1e3a5f; margin: 1rem 0 0.5rem 0; text-align: center; font-weight: 600;'>Login</h4>
        """, unsafe_allow_html=True)
        
        # Form inputs
        username = st.text_input("Username", placeholder="Enter username", key="login_username")
        password = st.text_input("Password", type="password", placeholder="Enter password", key="login_password")
        
        # Login button
        if st.button("Login", type="primary", use_container_width=True):
            success, message = Authenticator.login(username, password)
            
            if success:
                st.session_state.authenticated = True
                st.session_state.username = username
                st.session_state.login_time = datetime.now()
                st.rerun()
            else:
                st.error(message)
        
        # Help text
        st.markdown("""
        <p style='text-align: center; color: #9ca3af; font-size: 0.85rem; margin-top: 1.5rem;'>
            Contact your administrator if you need access.
        </p>
        """, unsafe_allow_html=True)


def check_authentication() -> bool:
    """Check if user is authenticated with valid session"""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
        return False
    
    if not st.session_state.authenticated:
        return False
    
    # Check session timeout using rca_module
    is_valid, _ = Authenticator.check_session_timeout(
        st.session_state.get('login_time')
    )
    
    if not is_valid:
        st.session_state.authenticated = False
        st.session_state.username = None
        st.session_state.login_time = None
        return False
    
    return True


# =============================================================================
# SIDEBAR
# =============================================================================

def render_sidebar() -> Dict[str, str]:
    """Render sidebar with filters"""
    # Display centered logo at the top of sidebar
    col1, col2, col3 = st.sidebar.columns([1, 2, 1])
    with col2:
        st.image("assets/logo.png", width=150)
    
    st.sidebar.markdown("### Filters")
    st.sidebar.markdown("---")
    
    # Get data
    data = load_and_analyze_data()
    filter_options = DataLoader.get_filter_options(data)
    
    # Crop filter
    selected_crop = st.sidebar.selectbox("Crop", filter_options['crops'], key="filter_crop")
    
    # Variety filter (filtered by crop)
    variety_options = DataLoader.get_filtered_variety_options(data, selected_crop)
    selected_variety = st.sidebar.selectbox("Variety", variety_options, key="filter_variety")
    
    # Category filter
    selected_category = st.sidebar.selectbox("Variance Category", filter_options['categories'], key="filter_category")
    
    # District filter
    selected_district = st.sidebar.selectbox("District", filter_options['districts'], key="filter_district")
    
    st.sidebar.markdown("---")
    
    # About section
    st.sidebar.markdown("### About")
    st.sidebar.info("""
    This dashboard analyzes field inspection data to identify 
    variances from recommended practices and determine root causes.
    
    **Key Features:**
    - Variance scoring by attribute
    - Root cause analysis
    - Geographic insights
    - Trend analysis
    """)
    
    return {
        'crop': selected_crop,
        'variety': selected_variety,
        'category': selected_category,
        'district': selected_district
    }


# =============================================================================
# OVERVIEW TAB
# =============================================================================

def render_overview(df_insp: pd.DataFrame, df_summary: pd.DataFrame, data: Dict):
    """Render overview section with key metrics"""
    st.markdown(section_header("Overview Dashboard"), unsafe_allow_html=True)
    
    # Get summary metrics using rca_module
    metrics = DataLoader.get_summary_metrics(df_summary)
    
    # Key metrics using UI-kit components
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(metric_card(metrics['total_inspections'], "Total Inspections Analyzed", ""), unsafe_allow_html=True)
    
    with col2:
        st.markdown(metric_card(f"{metrics['avg_variance_score']:.3f}", "Average Variance Score", "green"), unsafe_allow_html=True)
    
    with col3:
        st.markdown(metric_card(f"{metrics['pct_acceptable']:.1f}%", "Within Acceptable Range", "blue"), unsafe_allow_html=True)
    
    with col4:
        st.markdown(metric_card(metrics['critical_count'], "Critical Variances", "orange"), unsafe_allow_html=True)
    
    # Charts row
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Variance Category Distribution")
        cat_counts = df_summary['variance_category'].value_counts().reset_index()
        cat_counts.columns = ['Category', 'Count']
        
        fig = px.pie(
            cat_counts, 
            values='Count', 
            names='Category',
            color='Category',
            color_discrete_map={
                'LOW': '#10b981',
                'MEDIUM': '#f59e0b',
                'HIGH': '#ef4444',
                'CRITICAL': '#7c3aed'
            },
            hole=0.4
        )
        fig.update_layout(
            height=350,
            margin=dict(l=20, r=20, t=30, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=-0.15)
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### Variance Score Distribution")
        fig = px.histogram(
            df_summary, 
            x='overall_variance_score',
            nbins=20,
            color_discrete_sequence=['#0284c7'],
            labels={'overall_variance_score': 'Variance Score', 'count': 'Count'}
        )
        fig.update_layout(
            height=350,
            margin=dict(l=20, r=20, t=30, b=20),
            xaxis_title="Variance Score",
            yaxis_title="Number of Inspections"
        )
        # Add category boundaries
        for threshold, color, label in [(0.2, '#10b981', 'Low'), (0.4, '#f59e0b', 'Med'), (0.6, '#ef4444', 'High')]:
            fig.add_vline(x=threshold, line_dash="dash", line_color=color, annotation_text=label)
        st.plotly_chart(fig, use_container_width=True)


def render_explanation():
    """Render explanation section using descriptions from rca_module"""
    st.markdown(section_header("Understanding the Analysis"), unsafe_allow_html=True)
    
    with st.expander("What is Variance Analysis?", expanded=True):
        st.markdown("""
        **Variance analysis** compares actual field observations against recommended best practices:
        
        - **Date Variances**: Early/late timing for soaking, sowing, transplanting
        - **Numeric Variances**: Pest levels, tiller counts, health scores, plant population
        
        Each variance is scored and weighted to produce an **overall variance score** from 0 to 1:
        
        | Score Range | Category | Interpretation |
        |-------------|----------|----------------|
        | 0.00 - 0.20 | LOW | Excellent - On target |
        | 0.20 - 0.40 | MEDIUM | Good - Minor deviations |
        | 0.40 - 0.60 | HIGH | Concern - Significant deviations |
        | 0.60 - 1.00 | CRITICAL | Action Required - Major issues |
        """)
    
    with st.expander("How are Weights and Tolerances Applied?", expanded=False):
        st.markdown("""
        **Tolerances** define acceptable deviation ranges:
        - Date attributes: ±3-7 days depending on activity
        - Numeric attributes: Percentage-based (e.g., ±15% for tillers) or absolute ranges
        
        **Weights** determine importance in overall score (sum to 1.0):
        
        | Attribute | Weight | Rationale |
        |-----------|--------|-----------|
        | Sowing Date | 0.15 | Critical timing event |
        | Pest Severity | 0.15 | Direct yield impact |
        | Health Score | 0.13 | Overall crop condition |
        | Transplant Date | 0.12 | Establishment success |
        | Tiller Count | 0.12 | Yield potential |
        | Soaking Date | 0.10 | Foundation activity |
        | Plant Ratio | 0.10 | Population adequacy |
        | Flowering Date | 0.08 | Maturity indicator |
        | Disease Severity | 0.05 | Quality impact |
        """)
    
    with st.expander("How Does the Analysis Pipeline Work?", expanded=False):
        st.markdown(ANALYSIS_EXPLANATIONS['pipeline_flow'])


# =============================================================================
# ATTRIBUTE ANALYSIS TAB
# =============================================================================

def render_attribute_analysis(data: Dict, df_summary: pd.DataFrame):
    """Render attribute-level analysis"""
    st.markdown(section_header("Attribute Analysis"), unsafe_allow_html=True)
    
    df_attr = data['results']['attribute_contributions'].copy()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Variance Contribution by Attribute")
        fig = px.bar(
            df_attr.sort_values('pct_of_total', ascending=True),
            x='pct_of_total',
            y='attribute_code',
            orientation='h',
            color='pct_of_total',
            color_continuous_scale='Reds',
            labels={'pct_of_total': '% of Total Variance', 'attribute_code': 'Attribute'}
        )
        fig.update_layout(height=400, margin=dict(l=20, r=20, t=30, b=20), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### Tolerance Performance by Attribute")
        fig = px.bar(
            df_attr.sort_values('pct_within_tolerance', ascending=False),
            x='attribute_code',
            y='pct_within_tolerance',
            color='pct_within_tolerance',
            color_continuous_scale='Greens',
            labels={'pct_within_tolerance': '% Within Tolerance', 'attribute_code': 'Attribute'}
        )
        fig.add_hline(y=80, line_dash="dash", line_color="red", annotation_text="Target: 80%")
        fig.update_layout(height=400, margin=dict(l=20, r=20, t=30, b=20), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    
    # Generate automatic interpretations using rca_module
    df_attr_sorted = df_attr.sort_values('pct_of_total', ascending=False).reset_index(drop=True)
    
    df_attr_sorted['Severity'] = df_attr_sorted['pct_of_total'].apply(AnalysisEngine.get_severity_level)
    df_attr_sorted['What This Means'] = df_attr_sorted.apply(
        lambda row: AnalysisEngine.get_attribute_interpretation(
            row['attribute_code'], row['pct_of_total'], row['pct_within_tolerance']
        ), axis=1
    )
    
    # Detailed table
    st.markdown("#### Attribute Metrics Detail")
    display_cols = ['attribute_code', 'Severity', 'total_contribution', 'avg_contribution', 
                   'count', 'pct_within_tolerance', 'pct_of_total', 'What This Means']
    df_display = df_attr_sorted[display_cols].copy()
    df_display.columns = ['Attribute', 'Severity', 'Total Contribution', 'Avg Contribution', 
                         'Count', '% Within Tolerance', '% of Total', 'What This Means']
    
    st.dataframe(
        df_display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Attribute": st.column_config.TextColumn("Attribute", width="medium"),
            "Severity": st.column_config.TextColumn("Severity", width="small",
                help="🔴 Critical (≥25%), 🟠 Significant (≥15%), 🟡 Moderate (≥8%), 🟢 Good (<8%)"),
            "What This Means": st.column_config.TextColumn("What This Means", width="large"),
            "Total Contribution": st.column_config.NumberColumn(format="%.4f"),
            "Avg Contribution": st.column_config.NumberColumn(format="%.4f"),
            "% Within Tolerance": st.column_config.NumberColumn(format="%.1f%%"),
            "% of Total": st.column_config.NumberColumn(format="%.2f%%"),
        }
    )
    
    # Business Action Section using rca_module
    st.markdown("---")
    st.markdown("#### Recommended Business Actions")
    st.markdown("*Prioritized actions based on variance analysis results:*")
    
    top_attrs = df_attr_sorted.head(5)
    
    for rank, (_, row) in enumerate(top_attrs.iterrows(), 1):
        attr_code = row['attribute_code']
        pct_of_total = row['pct_of_total']
        pct_within_tolerance = row['pct_within_tolerance']
        
        if pct_of_total < 2:
            continue
        
        action_info = AnalysisEngine.get_business_action(attr_code, pct_of_total, pct_within_tolerance, rank)
        
        with st.expander(f"{action_info.priority} **{attr_code.replace('_', ' ').title()}** - {action_info.issue} ({pct_of_total:.1f}% of variance)", expanded=(rank <= 2)):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown("**Recommended Actions:**")
                for i, action in enumerate(action_info.actions, 1):
                    st.markdown(f"{i}. {action}")
            
            with col2:
                st.markdown(f"**Owner:** {action_info.owner}")
                st.markdown(f"**Urgency:** {action_info.urgency}")
                st.markdown(f"**Compliance:** {pct_within_tolerance:.1f}%")
                
                if pct_within_tolerance >= 80:
                    st.success("Within target threshold")
                elif pct_within_tolerance >= 70:
                    st.warning("Below target (80%)")
                else:
                    st.error("Significantly below target")
    
    # Summary recommendation using rca_module
    st.markdown("---")
    attrs_below_target = len(df_attr_sorted[df_attr_sorted['pct_within_tolerance'] < 80])
    top_contributor = df_attr_sorted.iloc[0]['attribute_code'] if len(df_attr_sorted) > 0 else "N/A"
    top_pct = df_attr_sorted.iloc[0]['pct_of_total'] if len(df_attr_sorted) > 0 else 0
    
    summary = AnalysisEngine.generate_summary_recommendation(attrs_below_target, top_contributor, top_pct)
    
    if summary['type'] == 'error':
        st.error(f"**{summary['title']}**\n\n{summary['message']}\n\n**Recommendation:** {summary['recommendation']}")
    elif summary['type'] == 'warning':
        st.warning(f"**{summary['title']}**\n\n{summary['message']}\n\n**Recommendation:** {summary['recommendation']}")
    else:
        st.success(f"**{summary['title']}**\n\n{summary['message']}\n\n**Recommendation:** {summary['recommendation']}")


# =============================================================================
# ROOT CAUSE ANALYSIS TAB
# =============================================================================

def render_root_cause_analysis(data: Dict, df_summary: pd.DataFrame):
    """Render root cause analysis section"""
    st.markdown(section_header("Root Cause Analysis"), unsafe_allow_html=True)
    
    df_reason = data['results']['reason_code_distribution'].copy()
    
    if len(df_reason) == 0:
        st.info("No reason codes identified in the filtered data.")
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("#### Root Cause Distribution")
        df_reason['description'] = df_reason['reason_code'].apply(get_reason_code_description)
        
        fig = px.bar(
            df_reason.sort_values('count', ascending=True).head(10),
            x='count',
            y='reason_code',
            orientation='h',
            color='pct',
            color_continuous_scale='Oranges',
            labels={'count': 'Occurrence Count', 'reason_code': 'Reason Code', 'pct': '% of Inspections'},
            hover_data=['description']
        )
        fig.update_layout(
            height=450,
            margin=dict(l=20, r=20, t=30, b=20),
            yaxis={'categoryorder': 'total ascending'}
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### Top Issues")
        for _, row in df_reason.head(5).iterrows():
            code = row['reason_code']
            count = row['count']
            pct = row['pct']
            desc = get_reason_code_description(code)
            
            st.markdown(f"""
            **{code.replace('_', ' ').title()}**
            - Occurrences: {count}
            - Affected: {pct:.1f}%
            
            *{desc}*
            
            ---
            """)
    
    # RCA Explanation
    st.markdown("#### Understanding Root Causes")
    
    with st.expander("How are reason codes assigned?", expanded=False):
        st.markdown("""
        Reason codes are assigned using a **rule-based engine** that evaluates multiple conditions:
        
        | Reason Code | Key Conditions | Business Impact |
        |-------------|----------------|-----------------|
        | **Upstream Timing Slip** | Late soaking date + Late sowing date | Entire crop cycle delayed |
        | **Pest Pressure** | High pest severity + Low health score | Yield loss, quality issues |
        | **Establishment Issue** | Low plant ratio + Late transplanting | Poor stand, reduced yield |
        | **Disease Outbreak** | High disease severity + Low health | Significant crop damage |
        | **Low Tillering** | Tiller count below minimum | Reduced grain production |
        | **Early Planting** | Sowing date >7 days early | Risk of weather damage |
        | **Poor Germination** | Low plant ratio only | Sub-optimal population |
        | **Data Quality Issue** | Values outside valid ranges | Unreliable analysis |
        
        **Priority System**: Rules are evaluated in priority order. If multiple rules match, all reason codes are captured, 
        but the **primary reason code** reflects the highest-priority issue.
        """)


# =============================================================================
# GEOGRAPHIC ANALYSIS TAB
# =============================================================================

def render_geographic_analysis(data: Dict, df_insp: pd.DataFrame, df_summary: pd.DataFrame):
    """Render geographic analysis"""
    st.markdown(section_header("Geographic Analysis"), unsafe_allow_html=True)
    
    df_loc = df_insp.merge(df_summary[['inspection_id', 'overall_variance_score', 'variance_category']], on='inspection_id')
    
    district_agg = df_loc.groupby('district_name').agg({
        'inspection_id': 'count',
        'overall_variance_score': 'mean',
        'variance_category': lambda x: (x == 'CRITICAL').sum()
    }).round(4).reset_index()
    district_agg.columns = ['District', 'Inspections', 'Avg Score', 'Critical Count']
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Average Variance Score by District")
        fig = px.bar(
            district_agg.sort_values('Avg Score', ascending=True),
            x='District',
            y='Avg Score',
            color='Avg Score',
            color_continuous_scale='RdYlGn_r',
            labels={'Avg Score': 'Average Variance Score'}
        )
        fig.update_layout(height=350, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### Inspection Volume by District")
        fig = px.pie(
            district_agg,
            values='Inspections',
            names='District',
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        fig.update_layout(height=350, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("#### District-Level Summary")
    st.dataframe(district_agg.sort_values('Avg Score', ascending=False), use_container_width=True, hide_index=True)


# =============================================================================
# CROP & VARIETY TAB
# =============================================================================

def render_crop_variety_analysis(data: Dict, df_insp: pd.DataFrame, df_summary: pd.DataFrame):
    """Render crop and variety analysis"""
    st.markdown(section_header("Crop & Variety Performance"), unsafe_allow_html=True)
    
    df_cvs = data['results']['cvs_aggregation'].copy()
    
    if len(df_cvs) == 0:
        st.info("No crop-variety aggregation available.")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Performance by Crop-Variety")
        fig = px.scatter(
            df_cvs,
            x='avg_score',
            y='inspection_count',
            size='max_score',
            color='crop_name',
            hover_data=['variety_name'],
            labels={
                'avg_score': 'Average Variance Score',
                'inspection_count': 'Number of Inspections',
                'max_score': 'Max Score'
            }
        )
        fig.update_layout(height=400, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### Variety Comparison")
        fig = px.bar(
            df_cvs.sort_values('avg_score', ascending=True),
            x='avg_score',
            y='variety_name',
            color='crop_name',
            orientation='h',
            labels={'avg_score': 'Avg Variance Score', 'variety_name': 'Variety', 'crop_name': 'Crop'}
        )
        fig.update_layout(height=400, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("#### Detailed Crop-Variety Metrics")
    display_df = df_cvs[['crop_name', 'variety_name', 'inspection_count', 'avg_score', 'max_score', 'avg_attrs_ok']].copy()
    display_df.columns = ['Crop', 'Variety', 'Inspections', 'Avg Score', 'Max Score', 'Avg Attrs OK']
    st.dataframe(display_df, use_container_width=True, hide_index=True)


# =============================================================================
# INSPECTION DETAIL TAB
# =============================================================================

def render_inspection_detail(data: Dict, df_insp: pd.DataFrame, df_summary: pd.DataFrame):
    """Render detailed inspection view"""
    st.markdown(section_header("Inspection Details"), unsafe_allow_html=True)
    
    df_detail = df_insp.merge(df_summary, on='inspection_id')
    st.session_state['_detail_df'] = df_detail
    st.session_state['_detail_data'] = data
    
    _render_inspection_detail_fragment()


@st.fragment
def _render_inspection_detail_fragment():
    """Fragment for inspection detail - reruns independently without resetting tabs"""
    df_detail = st.session_state.get('_detail_df')
    data = st.session_state.get('_detail_data')
    
    if df_detail is None or data is None:
        st.warning("Please refresh the page.")
        return
    
    col1, col2 = st.columns([1, 3])
    with col1:
        selected_inspection = st.selectbox(
            "Select Inspection",
            df_detail['inspection_event_id'].tolist(),
            key="inspection_detail_selector"
        )
    
    if selected_inspection:
        row = df_detail[df_detail['inspection_event_id'] == selected_inspection].iloc[0]
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("#### Inspection Info")
            st.markdown(f"""
            - **Event ID**: {row['inspection_event_id']}
            - **Date**: {row['inspection_date']}
            - **Crop**: {row['crop_name']}
            - **Variety**: {row['variety_name']}
            - **Season**: {row['season_code']}
            - **District**: {row['district_name']}
            """)
        
        with col2:
            st.markdown("#### Variance Assessment")
            score = row['overall_variance_score']
            category = row['variance_category']
            
            fig = create_gauge_chart(score, "Variance Score")
            st.plotly_chart(fig, use_container_width=True)
            
            st.markdown(VisualizationHelper.get_category_badge_html(category), unsafe_allow_html=True)
        
        with col3:
            st.markdown("#### Root Causes")
            reason_codes = row['reason_codes']
            if reason_codes and len(reason_codes) > 0:
                for code in reason_codes:
                    st.markdown(f"**{code.replace('_', ' ').title()}**")
                    st.caption(get_reason_code_description(code))
            else:
                st.success("No significant issues identified")
        
        # Variance detail
        st.markdown("#### Attribute-Level Variances")
        df_var = data['results']['variance_detail']
        df_var_insp = df_var[df_var['inspection_id'] == row['inspection_id']].copy()
        
        if len(df_var_insp) > 0:
            cols_to_show = ['attribute_code', 'actual_value_date', 'actual_value_numeric',
                          'recommended_value_date', 'recommended_value_numeric',
                          'variance_days', 'variance_numeric', 'variance_status', 
                          'within_tolerance', 'severity_flag']
            df_var_display = df_var_insp[cols_to_show].copy()
            df_var_display.columns = ['Attribute', 'Actual (Date)', 'Actual (Num)', 
                                     'Rec (Date)', 'Rec (Num)', 'Var (Days)', 'Var (Num)',
                                     'Status', 'Within Tol', 'Severity']
            st.dataframe(df_var_display, use_container_width=True, hide_index=True)
        
        # Top drivers
        try:
            drivers = json.loads(row['top_variance_drivers'])
            if drivers:
                st.markdown("#### Top Variance Drivers")
                for i, driver in enumerate(drivers, 1):
                    attr = driver.get('attribute_code', 'Unknown')
                    contrib = driver.get('weighted_contribution', 0)
                    status = driver.get('variance_status', 'Unknown')
                    st.markdown(f"{i}. **{attr}**: Contribution = {contrib:.4f} ({status})")
        except:
            pass


# =============================================================================
# MAIN APPLICATION
# =============================================================================

def main():
    """Main application entry point"""
    
    # Initialize session state
    initialize_session_state()
    
    # Check authentication
    if not check_authentication():
        render_login_page()
        return
    
    # --- Authenticated user content below ---
    
    # Header with logout button
    header_col1, header_col2 = st.columns([5, 1])
    with header_col1:
        st.title("Agricultural Field Inspection Variance Analysis")
        st.markdown("*Analyzing deviations from recommended practices and identifying root causes*")
    with header_col2:
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown(f"""
        <div style='text-align: right; font-size: 0.8rem; color: #6b7280; margin-bottom: 0.3rem;'>
            Logged in as: <b>{st.session_state.username.title()}</b>
        </div>
        """, unsafe_allow_html=True)
        col_spacer, col_btn = st.columns([1, 1])
        with col_btn:
            if st.button("Logout", type="secondary", use_container_width=True):
                st.session_state.authenticated = False
                st.session_state.username = None
                st.session_state.login_time = None
                st.rerun()
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Load data
    try:
        data = load_and_analyze_data()
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return
    
    # Sidebar filters
    filters = render_sidebar()
    
    # Filter data using rca_module
    df_insp, df_summary = DataLoader.filter_data_dict(data, filters)
    
    if len(df_summary) == 0:
        st.warning("No data matches the selected filters. Please adjust your selection.")
        return
    
    # Main content tabs
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "Overview",
        "Attributes",
        "Root Causes",
        "Geography",
        "Crops",
        "Details"
    ])
    
    with tab1:
        render_overview(df_insp, df_summary, data)
        render_explanation()
    
    with tab2:
        render_attribute_analysis(data, df_summary)
    
    with tab3:
        render_root_cause_analysis(data, df_summary)
    
    with tab4:
        render_geographic_analysis(data, df_insp, df_summary)
    
    with tab5:
        render_crop_variety_analysis(data, df_insp, df_summary)
    
    with tab6:
        render_inspection_detail(data, df_insp, df_summary)
    
    # Footer
    st.markdown("---")
    st.markdown(
        f"<p style='text-align: center; color: #6b7280; font-size: 0.8rem;'>"
        f"Agricultural Variance Analysis System | Logged in as: {st.session_state.username.title()} | 2024"
        "</p>",
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()
