-- ============================================================================
-- AGRICULTURAL FIELD INSPECTION VARIANCE ANALYSIS - DATABASE SCHEMA
-- ============================================================================
-- Purpose: Row-level variance analysis between field inspection actuals and 
--          recommended (master) values for Crop-Variety-Season combinations
-- Database: PostgreSQL 14+
-- 
-- INTEGRATION NOTE: This schema integrates with existing tables:
--   - Crop (crop_id PK)
--   - Variety (variety_id PK, crop_id FK)
--   - Season (season_id PK)
--   - Location (location_id PK) - contains geography/farm/field/plot data
--   - Inspection (season_id, crop_id, variety_id as composite PK) - actuals
-- ============================================================================

-- ============================================================================
-- SECTION 1: EXISTING TABLES (FOR REFERENCE ONLY - DO NOT CREATE)
-- ============================================================================
-- These tables already exist in your database. Shown here for documentation.

/*
-- EXISTING: Crop table
CREATE TABLE Crop (
    crop_id         SERIAL PRIMARY KEY,
    crop_code       VARCHAR(20) NOT NULL UNIQUE,
    crop_name       VARCHAR(100) NOT NULL,
    -- other existing columns...
);

-- EXISTING: Variety table
CREATE TABLE Variety (
    variety_id      SERIAL PRIMARY KEY,
    crop_id         INTEGER NOT NULL REFERENCES Crop(crop_id),
    variety_code    VARCHAR(30) NOT NULL,
    variety_name    VARCHAR(150) NOT NULL,
    -- other existing columns...
);

-- EXISTING: Season table
CREATE TABLE Season (
    season_id           SERIAL PRIMARY KEY,
    season_code         VARCHAR(20) NOT NULL,
    season_name         VARCHAR(50) NOT NULL,
    season_year         INTEGER,
    season_start_date   DATE,
    season_end_date     DATE,
    -- other existing columns...
);

-- EXISTING: Location table (combines geography/farm/field/plot)
CREATE TABLE Location (
    location_id         SERIAL PRIMARY KEY,
    location_code       VARCHAR(50),
    location_name       VARCHAR(150),
    -- Geography fields
    geography_level     VARCHAR(30),  -- 'Country', 'State', 'District', 'Zone', etc.
    parent_location_id  INTEGER REFERENCES Location(location_id),
    agro_climatic_zone  VARCHAR(50),
    latitude            DECIMAL(9,6),
    longitude           DECIMAL(9,6),
    -- Farm fields
    farm_code           VARCHAR(30),
    farm_name           VARCHAR(150),
    farmer_name         VARCHAR(150),
    -- Field fields
    field_code          VARCHAR(30),
    field_name          VARCHAR(100),
    area_ha             DECIMAL(10,4),
    soil_type           VARCHAR(50),
    irrigation_type     VARCHAR(50),
    -- Plot fields
    plot_code           VARCHAR(30),
    plot_name           VARCHAR(100),
    row_count           INTEGER,
    -- other existing columns...
);

-- EXISTING: Inspection table (contains actual/observed values)
CREATE TABLE Inspection (
    -- Composite Primary Key
    season_id           INTEGER NOT NULL REFERENCES Season(season_id),
    crop_id             INTEGER NOT NULL REFERENCES Crop(crop_id),
    variety_id          INTEGER NOT NULL REFERENCES Variety(variety_id),
    
    -- Additional key fields (if applicable)
    location_id         INTEGER REFERENCES Location(location_id),
    inspection_date     DATE,
    inspection_event_id VARCHAR(50),
    
    -- Actual observed values
    actual_soaking_date     DATE,
    actual_sowing_date      DATE,
    actual_transplant_date  DATE,
    actual_flowering_date   DATE,
    actual_pest_severity    INTEGER,
    actual_tiller_count     INTEGER,
    actual_health_score     INTEGER,
    actual_plant_ratio      DECIMAL(5,2),
    actual_disease_severity INTEGER,
    -- other existing columns...
    
    PRIMARY KEY (season_id, crop_id, variety_id)
    -- Or if location is part of grain: PRIMARY KEY (season_id, crop_id, variety_id, location_id)
);
*/

-- ============================================================================
-- SECTION 2: METADATA TABLES
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: meta_attribute
-- Grain: One row per measurable attribute
-- Purpose: Defines attributes that are compared between actual and recommended
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS meta_attribute (
    attribute_id        SERIAL PRIMARY KEY,
    attribute_code      VARCHAR(50) NOT NULL UNIQUE,
    attribute_name      VARCHAR(100) NOT NULL,
    attribute_category  VARCHAR(50) NOT NULL,  -- 'Date', 'Numeric', 'Categorical'
    data_type           VARCHAR(30) NOT NULL,  -- 'DATE', 'INTEGER', 'DECIMAL', 'VARCHAR'
    unit_of_measure     VARCHAR(30),           -- 'days', 'count', 'percentage', 'score'
    comparison_method   VARCHAR(30) NOT NULL,  -- 'DIFF', 'RANGE', 'EXACT_MATCH', 'SEVERITY'
    is_higher_better    BOOLEAN,               -- For numeric: TRUE if higher is better
    description         TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_meta_attr_code ON meta_attribute(attribute_code);
CREATE INDEX IF NOT EXISTS idx_meta_attr_category ON meta_attribute(attribute_category);

COMMENT ON TABLE meta_attribute IS 'Metadata defining measurable attributes and their comparison rules';

-- Insert standard attributes (run once)
INSERT INTO meta_attribute (attribute_code, attribute_name, attribute_category, data_type, unit_of_measure, comparison_method, is_higher_better, description) 
VALUES
('SOAKING_DATE', 'Soaking Date', 'Date', 'DATE', 'days', 'DIFF', NULL, 'Date when seeds were soaked'),
('SOWING_DATE', 'Sowing Date', 'Date', 'DATE', 'days', 'DIFF', NULL, 'Date when seeds were sown'),
('TRANSPLANT_DATE', 'Transplantation Date', 'Date', 'DATE', 'days', 'DIFF', NULL, 'Date when seedlings were transplanted'),
('PEST_SEVERITY', 'Pest Severity Index', 'Numeric', 'INTEGER', 'score', 'RANGE', FALSE, 'Pest severity score 0-10 (0=none, 10=severe)'),
('TILLER_COUNT', 'Tiller Count', 'Numeric', 'INTEGER', 'count', 'RANGE', TRUE, 'Number of tillers per plant'),
('HEALTH_SCORE', 'Plant Health Score', 'Numeric', 'INTEGER', 'score', 'RANGE', TRUE, 'Overall health score 1-5 (5=excellent)'),
('PLANT_RATIO', 'Plant Population Ratio', 'Numeric', 'DECIMAL', 'percentage', 'RANGE', TRUE, 'Actual vs expected plant population ratio'),
('FLOWERING_DATE', 'Flowering Date', 'Date', 'DATE', 'days', 'DIFF', NULL, 'Date when 50% flowering observed'),
('DISEASE_SEVERITY', 'Disease Severity Index', 'Numeric', 'INTEGER', 'score', 'RANGE', FALSE, 'Disease severity score 0-10')
ON CONFLICT (attribute_code) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Table: meta_tolerance
-- Grain: One row per attribute tolerance configuration
-- Purpose: Configurable tolerances for variance classification
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS meta_tolerance (
    tolerance_id        SERIAL PRIMARY KEY,
    attribute_id        INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    tolerance_type      VARCHAR(30) NOT NULL,  -- 'ABSOLUTE', 'PERCENTAGE', 'RANGE'
    tolerance_value     DECIMAL(10,4),         -- e.g., 3 for +/- 3 days
    tolerance_pct       DECIMAL(5,2),          -- e.g., 10 for +/- 10%
    lower_threshold     DECIMAL(10,4),         -- For range: lower bound
    upper_threshold     DECIMAL(10,4),         -- For range: upper bound
    severity_level      VARCHAR(20) DEFAULT 'NORMAL',  -- 'LOW', 'NORMAL', 'HIGH', 'CRITICAL'
    effective_from      DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to        DATE DEFAULT '9999-12-31',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(attribute_id, severity_level, effective_from)
);

CREATE INDEX IF NOT EXISTS idx_tolerance_attr ON meta_tolerance(attribute_id);
CREATE INDEX IF NOT EXISTS idx_tolerance_effective ON meta_tolerance(effective_from, effective_to);

COMMENT ON TABLE meta_tolerance IS 'Configurable tolerance thresholds per attribute';

-- Insert default tolerances (run once)
INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'ABSOLUTE', 3, NULL, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'SOAKING_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'ABSOLUTE', 5, NULL, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'SOWING_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'ABSOLUTE', 7, NULL, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'TRANSPLANT_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'RANGE', NULL, NULL, 0, 3, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'PEST_SEVERITY'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'PERCENTAGE', NULL, 15, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'TILLER_COUNT'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'ABSOLUTE', 1, NULL, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'HEALTH_SCORE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'PERCENTAGE', NULL, 10, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'PLANT_RATIO'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'ABSOLUTE', 5, NULL, NULL, NULL, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'FLOWERING_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) 
SELECT attribute_id, 'RANGE', NULL, NULL, 0, 3, 'NORMAL' 
FROM meta_attribute WHERE attribute_code = 'DISEASE_SEVERITY'
ON CONFLICT DO NOTHING;

-- -----------------------------------------------------------------------------
-- Table: meta_variance_weight
-- Grain: One row per attribute weight for variance scoring
-- Purpose: Weights for computing overall variance score
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS meta_variance_weight (
    weight_id           SERIAL PRIMARY KEY,
    attribute_id        INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    weight_value        DECIMAL(5,4) NOT NULL,  -- e.g., 0.15 for 15% weight
    weight_group        VARCHAR(50) DEFAULT 'DEFAULT',  -- Allow different weight profiles
    effective_from      DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to        DATE DEFAULT '9999-12-31',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(attribute_id, weight_group, effective_from)
);

CREATE INDEX IF NOT EXISTS idx_weight_attr ON meta_variance_weight(attribute_id);
CREATE INDEX IF NOT EXISTS idx_weight_group ON meta_variance_weight(weight_group);

COMMENT ON TABLE meta_variance_weight IS 'Weights for computing weighted variance scores';

-- Insert default weights (should sum to 1.0)
INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.10, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'SOAKING_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.15, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'SOWING_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.12, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'TRANSPLANT_DATE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.15, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'PEST_SEVERITY'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.12, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'TILLER_COUNT'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.15, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'HEALTH_SCORE'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.13, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'PLANT_RATIO'
ON CONFLICT DO NOTHING;

INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) 
SELECT attribute_id, 0.08, 'DEFAULT' FROM meta_attribute WHERE attribute_code = 'DISEASE_SEVERITY'
ON CONFLICT DO NOTHING;


-- ============================================================================
-- SECTION 3: MASTER RECOMMENDATION TABLE
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: master_recommendation
-- Grain: One row per (crop, variety, season, location) with version control
-- Purpose: Stores recommended values for each CVS combination
-- References: Existing Crop, Variety, Season, Location tables
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS master_recommendation (
    recommendation_id   SERIAL PRIMARY KEY,
    
    -- Foreign keys to existing tables
    crop_id             INTEGER NOT NULL,  -- References Crop(crop_id)
    variety_id          INTEGER NOT NULL,  -- References Variety(variety_id)
    season_id           INTEGER NOT NULL,  -- References Season(season_id)
    location_id         INTEGER,           -- References Location(location_id), NULL = global default
    
    -- Version control
    version_number      INTEGER NOT NULL DEFAULT 1,
    effective_start     DATE NOT NULL,
    effective_end       DATE DEFAULT '9999-12-31',
    is_current          BOOLEAN DEFAULT TRUE,
    
    -- Recommended date values (stored as absolute dates OR offset config)
    -- Using offset approach: dates relative to season_start or soaking_date
    rec_soaking_date    DATE,                    -- Absolute recommended soaking date
    rec_soaking_offset  INTEGER,                 -- Days after season_start
    rec_sowing_date     DATE,
    rec_sowing_offset   INTEGER,                 -- Days after soaking_date
    rec_transplant_date DATE,
    rec_transplant_offset INTEGER,               -- Days after sowing_date
    rec_flowering_date  DATE,
    rec_flowering_offset INTEGER,                -- Days after transplant_date
    
    -- Recommended numeric values (target with min/max ranges)
    rec_pest_severity_target    INTEGER DEFAULT 0,
    rec_pest_severity_max       INTEGER DEFAULT 3,
    rec_tiller_count_target     INTEGER,
    rec_tiller_count_min        INTEGER,
    rec_tiller_count_max        INTEGER,
    rec_health_score_target     INTEGER DEFAULT 4,
    rec_health_score_min        INTEGER DEFAULT 3,
    rec_plant_ratio_target      DECIMAL(5,2) DEFAULT 95.00,
    rec_plant_ratio_min         DECIMAL(5,2) DEFAULT 85.00,
    rec_disease_severity_target INTEGER DEFAULT 0,
    rec_disease_severity_max    INTEGER DEFAULT 2,
    
    -- Statistical parameters for z-score calculation
    tiller_count_stddev         DECIMAL(10,4),
    plant_ratio_stddev          DECIMAL(10,4),
    
    -- Flexible storage for additional attributes
    additional_recommendations  JSONB DEFAULT '{}',
    
    -- Audit
    created_by          VARCHAR(100),
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Ensure unique version per CVS-location combination
    UNIQUE(crop_id, variety_id, season_id, location_id, version_number)
);

-- Add foreign key constraints (assuming tables exist)
-- Uncomment these after verifying your existing table names match
-- ALTER TABLE master_recommendation ADD CONSTRAINT fk_rec_crop FOREIGN KEY (crop_id) REFERENCES Crop(crop_id);
-- ALTER TABLE master_recommendation ADD CONSTRAINT fk_rec_variety FOREIGN KEY (variety_id) REFERENCES Variety(variety_id);
-- ALTER TABLE master_recommendation ADD CONSTRAINT fk_rec_season FOREIGN KEY (season_id) REFERENCES Season(season_id);
-- ALTER TABLE master_recommendation ADD CONSTRAINT fk_rec_location FOREIGN KEY (location_id) REFERENCES Location(location_id);

CREATE INDEX IF NOT EXISTS idx_rec_crop ON master_recommendation(crop_id);
CREATE INDEX IF NOT EXISTS idx_rec_variety ON master_recommendation(variety_id);
CREATE INDEX IF NOT EXISTS idx_rec_season ON master_recommendation(season_id);
CREATE INDEX IF NOT EXISTS idx_rec_location ON master_recommendation(location_id);
CREATE INDEX IF NOT EXISTS idx_rec_effective ON master_recommendation(effective_start, effective_end);
CREATE INDEX IF NOT EXISTS idx_rec_current ON master_recommendation(is_current) WHERE is_current = TRUE;
CREATE INDEX IF NOT EXISTS idx_rec_cvs ON master_recommendation(crop_id, variety_id, season_id);

COMMENT ON TABLE master_recommendation IS 'Versioned master recommendations per Crop-Variety-Season-Location. References existing Crop, Variety, Season, Location tables.';


-- ============================================================================
-- SECTION 4: VARIANCE FACT TABLES
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: fact_variance
-- Grain: One row per (season, crop, variety) inspection per attribute (EAV-style)
-- Purpose: Stores computed variances for each inspection record
-- Note: Uses composite key (season_id, crop_id, variety_id) to link to Inspection
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fact_variance (
    variance_id             SERIAL PRIMARY KEY,
    
    -- Composite foreign key to Inspection table
    season_id               INTEGER NOT NULL,  -- Part of Inspection PK
    crop_id                 INTEGER NOT NULL,  -- Part of Inspection PK
    variety_id              INTEGER NOT NULL,  -- Part of Inspection PK
    
    -- Optional: if location is part of inspection grain
    location_id             INTEGER,           -- References Location(location_id)
    
    -- Attribute being compared
    attribute_id            INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    
    -- Recommendation used for comparison
    recommendation_id       INTEGER REFERENCES master_recommendation(recommendation_id),
    
    -- Values compared
    actual_value_date       DATE,
    actual_value_numeric    DECIMAL(15,4),
    actual_value_text       VARCHAR(100),
    
    recommended_value_date  DATE,
    recommended_value_numeric DECIMAL(15,4),
    recommended_value_text  VARCHAR(100),
    
    -- Variance calculations
    variance_days           INTEGER,           -- For dates: actual - recommended
    variance_numeric        DECIMAL(15,4),     -- For numeric: actual - target
    variance_pct            DECIMAL(10,4),     -- Percentage variance
    z_score                 DECIMAL(10,4),     -- Standardized score
    
    -- Classification
    variance_status         VARCHAR(20),       -- 'ON_TARGET', 'EARLY', 'LATE', 'ABOVE', 'BELOW', 'MISMATCH'
    within_tolerance        BOOLEAN,
    severity_flag           VARCHAR(20),       -- 'OK', 'WARNING', 'CRITICAL'
    
    -- Missingness flags
    is_actual_missing       BOOLEAN DEFAULT FALSE,
    is_recommended_missing  BOOLEAN DEFAULT FALSE,
    
    -- For decomposition
    standardized_variance   DECIMAL(10,4),     -- Normalized 0-1 scale
    weight_applied          DECIMAL(5,4),
    weighted_contribution   DECIMAL(10,4),     -- weight * standardized_variance
    
    -- Audit
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Unique constraint: one variance record per inspection per attribute
    UNIQUE(season_id, crop_id, variety_id, attribute_id)
    -- Or if location is part of grain: UNIQUE(season_id, crop_id, variety_id, location_id, attribute_id)
);

-- Add foreign key constraint to Inspection (uncomment after verifying)
-- ALTER TABLE fact_variance ADD CONSTRAINT fk_var_inspection 
--     FOREIGN KEY (season_id, crop_id, variety_id) REFERENCES Inspection(season_id, crop_id, variety_id);

CREATE INDEX IF NOT EXISTS idx_var_cvs ON fact_variance(season_id, crop_id, variety_id);
CREATE INDEX IF NOT EXISTS idx_var_attribute ON fact_variance(attribute_id);
CREATE INDEX IF NOT EXISTS idx_var_recommendation ON fact_variance(recommendation_id);
CREATE INDEX IF NOT EXISTS idx_var_status ON fact_variance(variance_status);
CREATE INDEX IF NOT EXISTS idx_var_tolerance ON fact_variance(within_tolerance);
CREATE INDEX IF NOT EXISTS idx_var_severity ON fact_variance(severity_flag);
CREATE INDEX IF NOT EXISTS idx_var_location ON fact_variance(location_id);

COMMENT ON TABLE fact_variance IS 'Computed variance per inspection (CVS) per attribute. Links to existing Inspection table via composite key.';

-- -----------------------------------------------------------------------------
-- Table: fact_inspection_variance_summary
-- Grain: One row per inspection (season, crop, variety)
-- Purpose: Overall variance score and reason codes per inspection
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fact_inspection_variance_summary (
    summary_id              SERIAL PRIMARY KEY,
    
    -- Composite foreign key to Inspection table
    season_id               INTEGER NOT NULL,
    crop_id                 INTEGER NOT NULL,
    variety_id              INTEGER NOT NULL,
    
    -- Optional: if location is part of inspection grain
    location_id             INTEGER,
    
    -- Overall scores
    overall_variance_score  DECIMAL(10,4),     -- Weighted sum of standardized variances
    variance_category       VARCHAR(20),       -- 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
    
    -- Counts
    attributes_evaluated    INTEGER,
    attributes_within_tolerance INTEGER,
    attributes_missing_actual INTEGER,
    attributes_missing_rec  INTEGER,
    
    -- Top drivers (JSON array of top 3)
    top_variance_drivers    JSONB,
    
    -- Reason codes (can have multiple)
    reason_codes            VARCHAR(200)[],    -- Array of reason codes
    primary_reason_code     VARCHAR(50),       -- Main attributed cause
    
    -- Audit
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Unique constraint
    UNIQUE(season_id, crop_id, variety_id)
    -- Or if location is part of grain: UNIQUE(season_id, crop_id, variety_id, location_id)
);

-- Add foreign key constraint to Inspection (uncomment after verifying)
-- ALTER TABLE fact_inspection_variance_summary ADD CONSTRAINT fk_summary_inspection 
--     FOREIGN KEY (season_id, crop_id, variety_id) REFERENCES Inspection(season_id, crop_id, variety_id);

CREATE INDEX IF NOT EXISTS idx_summary_cvs ON fact_inspection_variance_summary(season_id, crop_id, variety_id);
CREATE INDEX IF NOT EXISTS idx_summary_score ON fact_inspection_variance_summary(overall_variance_score);
CREATE INDEX IF NOT EXISTS idx_summary_category ON fact_inspection_variance_summary(variance_category);
CREATE INDEX IF NOT EXISTS idx_summary_reason ON fact_inspection_variance_summary(primary_reason_code);
CREATE INDEX IF NOT EXISTS idx_summary_reason_array ON fact_inspection_variance_summary USING GIN(reason_codes);
CREATE INDEX IF NOT EXISTS idx_summary_location ON fact_inspection_variance_summary(location_id);

COMMENT ON TABLE fact_inspection_variance_summary IS 'Aggregated variance summary per inspection (CVS) with reason codes. Links to existing Inspection table.';


-- ============================================================================
-- SECTION 5: AGGREGATION TABLES
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: agg_variance_by_cvs
-- Grain: One row per (crop, variety, season, time_period)
-- Purpose: Aggregated variance metrics by CVS for dashboards
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agg_variance_by_cvs (
    agg_id                  SERIAL PRIMARY KEY,
    crop_id                 INTEGER NOT NULL,  -- References Crop(crop_id)
    variety_id              INTEGER NOT NULL,  -- References Variety(variety_id)
    season_id               INTEGER NOT NULL,  -- References Season(season_id)
    
    -- Time aggregation
    aggregation_period      VARCHAR(20) NOT NULL,  -- 'WEEK', 'MONTH', 'SEASON'
    period_start            DATE NOT NULL,
    period_end              DATE NOT NULL,
    
    -- Metrics
    inspection_count        INTEGER,
    avg_variance_score      DECIMAL(10,4),
    median_variance_score   DECIMAL(10,4),
    max_variance_score      DECIMAL(10,4),
    pct_within_tolerance    DECIMAL(5,2),
    
    -- Attribute-level contributions (JSONB for flexibility)
    attribute_contributions JSONB,  -- {"SOWING_DATE": 0.25, "PEST_SEVERITY": 0.35, ...}
    
    -- Reason code distribution
    reason_code_counts      JSONB,  -- {"upstream_timing_slip": 15, "pest_pressure": 8, ...}
    
    -- Audit
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(crop_id, variety_id, season_id, aggregation_period, period_start)
);

CREATE INDEX IF NOT EXISTS idx_agg_cvs ON agg_variance_by_cvs(crop_id, variety_id, season_id);
CREATE INDEX IF NOT EXISTS idx_agg_period ON agg_variance_by_cvs(period_start, period_end);

COMMENT ON TABLE agg_variance_by_cvs IS 'Aggregated variance summary by Crop-Variety-Season and time period';

-- -----------------------------------------------------------------------------
-- Table: agg_variance_by_location
-- Grain: One row per (location, season, time_period)
-- Purpose: Aggregated variance metrics by location for spatial analysis
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agg_variance_by_location (
    agg_id                  SERIAL PRIMARY KEY,
    location_id             INTEGER NOT NULL,  -- References Location(location_id)
    season_id               INTEGER,           -- References Season(season_id)
    
    -- Time aggregation
    aggregation_period      VARCHAR(20) NOT NULL,
    period_start            DATE NOT NULL,
    period_end              DATE NOT NULL,
    
    -- Metrics
    inspection_count        INTEGER,
    unique_cvs_count        INTEGER,  -- Number of distinct crop-variety-season combinations
    avg_variance_score      DECIMAL(10,4),
    pct_within_tolerance    DECIMAL(5,2),
    
    -- Top issues in this location
    top_variance_attributes JSONB,
    top_reason_codes        JSONB,
    
    -- Audit
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(location_id, season_id, aggregation_period, period_start)
);

CREATE INDEX IF NOT EXISTS idx_agg_location ON agg_variance_by_location(location_id);
CREATE INDEX IF NOT EXISTS idx_agg_loc_season ON agg_variance_by_location(season_id);

COMMENT ON TABLE agg_variance_by_location IS 'Aggregated variance summary by location and time period';


-- ============================================================================
-- SECTION 6: VIEWS
-- ============================================================================

-- -----------------------------------------------------------------------------
-- View: v_inspection_with_recommendation
-- Purpose: Join Inspection actuals with effective recommendations
-- Note: Assumes Inspection and related tables exist
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_inspection_with_recommendation AS
SELECT 
    -- Inspection keys
    i.season_id,
    i.crop_id,
    i.variety_id,
    i.location_id,
    
    -- From existing Crop table
    c.crop_code,
    c.crop_name,
    
    -- From existing Variety table
    v.variety_code,
    v.variety_name,
    
    -- From existing Season table
    s.season_code,
    s.season_name,
    s.season_year,
    s.season_start_date,
    
    -- From existing Location table
    l.location_code,
    l.location_name,
    l.agro_climatic_zone,
    
    -- Inspection actuals
    i.inspection_date,
    i.inspection_event_id,
    i.actual_soaking_date,
    i.actual_sowing_date,
    i.actual_transplant_date,
    i.actual_flowering_date,
    i.actual_pest_severity,
    i.actual_tiller_count,
    i.actual_health_score,
    i.actual_plant_ratio,
    i.actual_disease_severity,
    
    -- Recommendations (with computed dates)
    mr.recommendation_id,
    COALESCE(mr.rec_soaking_date, s.season_start_date + mr.rec_soaking_offset) AS rec_soaking_date,
    COALESCE(mr.rec_sowing_date, 
             COALESCE(mr.rec_soaking_date, s.season_start_date + mr.rec_soaking_offset) + mr.rec_sowing_offset
    ) AS rec_sowing_date,
    mr.rec_transplant_offset,
    mr.rec_flowering_offset,
    mr.rec_pest_severity_target, mr.rec_pest_severity_max,
    mr.rec_tiller_count_target, mr.rec_tiller_count_min, mr.rec_tiller_count_max,
    mr.rec_health_score_target, mr.rec_health_score_min,
    mr.rec_plant_ratio_target, mr.rec_plant_ratio_min,
    mr.rec_disease_severity_target, mr.rec_disease_severity_max,
    mr.tiller_count_stddev, mr.plant_ratio_stddev

FROM Inspection i
-- Join to existing dimension tables
JOIN Crop c ON i.crop_id = c.crop_id
JOIN Variety v ON i.variety_id = v.variety_id
JOIN Season s ON i.season_id = s.season_id
LEFT JOIN Location l ON i.location_id = l.location_id
-- Join to recommendations
LEFT JOIN master_recommendation mr ON (
    mr.crop_id = i.crop_id 
    AND mr.variety_id = i.variety_id 
    AND mr.season_id = i.season_id
    AND mr.is_current = TRUE
    AND (i.inspection_date IS NULL OR i.inspection_date BETWEEN mr.effective_start AND mr.effective_end)
    AND (mr.location_id = i.location_id OR mr.location_id IS NULL)
)
-- Prefer location-specific recommendations over global
WHERE mr.recommendation_id IS NULL OR mr.recommendation_id = (
    SELECT mr2.recommendation_id 
    FROM master_recommendation mr2
    WHERE mr2.crop_id = i.crop_id 
      AND mr2.variety_id = i.variety_id 
      AND mr2.season_id = i.season_id
      AND mr2.is_current = TRUE
      AND (i.inspection_date IS NULL OR i.inspection_date BETWEEN mr2.effective_start AND mr2.effective_end)
      AND (mr2.location_id = i.location_id OR mr2.location_id IS NULL)
    ORDER BY mr2.location_id NULLS LAST
    LIMIT 1
);

COMMENT ON VIEW v_inspection_with_recommendation IS 'Joined view of Inspection actuals with effective recommendations from existing tables';

-- -----------------------------------------------------------------------------
-- View: v_variance_summary_report
-- Purpose: Comprehensive variance report with all dimensions
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_variance_summary_report AS
SELECT 
    fis.summary_id,
    fis.season_id,
    fis.crop_id,
    fis.variety_id,
    fis.location_id,
    
    -- From existing tables
    c.crop_code, 
    c.crop_name,
    v.variety_code, 
    v.variety_name,
    s.season_code,
    l.location_code,
    l.agro_climatic_zone,
    
    -- Variance summary
    fis.overall_variance_score,
    fis.variance_category,
    fis.attributes_evaluated,
    fis.attributes_within_tolerance,
    fis.top_variance_drivers,
    fis.reason_codes,
    fis.primary_reason_code,
    fis.computed_at

FROM fact_inspection_variance_summary fis
JOIN Crop c ON fis.crop_id = c.crop_id
JOIN Variety v ON fis.variety_id = v.variety_id
JOIN Season s ON fis.season_id = s.season_id
LEFT JOIN Location l ON fis.location_id = l.location_id;

COMMENT ON VIEW v_variance_summary_report IS 'Comprehensive variance report joining with existing Crop, Variety, Season, Location tables';


-- ============================================================================
-- SECTION 7: HELPER FUNCTIONS
-- ============================================================================

-- Function to compute effective recommendation date based on offset
CREATE OR REPLACE FUNCTION compute_recommended_date(
    base_date DATE,
    absolute_date DATE,
    offset_days INTEGER
) RETURNS DATE AS $$
BEGIN
    IF absolute_date IS NOT NULL THEN
        RETURN absolute_date;
    ELSIF offset_days IS NOT NULL AND base_date IS NOT NULL THEN
        RETURN base_date + offset_days;
    ELSE
        RETURN NULL;
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- ============================================================================
-- SECTION 8: GRANTS (adjust role names as needed)
-- ============================================================================

-- Example grants (uncomment and modify as needed):
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON fact_variance, fact_inspection_variance_summary TO etl_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON agg_variance_by_cvs, agg_variance_by_location TO etl_role;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO etl_role;


-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
