"""
Data Loader Module
==================

Handles data loading, caching, and filtering for variance analysis.
"""

import pandas as pd
from typing import Dict, Tuple, Optional, Any
from dataclasses import dataclass

# Import from variance_analysis module
import sys
from pathlib import Path

# Add parent directory to path if needed
parent_dir = Path(__file__).parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

from variance_analysis import VarianceAnalysisPipeline, generate_demo_data


@dataclass
class FilterConfig:
    """Filter configuration for data filtering"""
    crop: str = 'All'
    variety: str = 'All'
    category: str = 'All'
    district: str = 'All'
    season: str = 'All'


@dataclass
class AnalysisData:
    """Container for all analysis data"""
    inspections: pd.DataFrame
    recommendations: pd.DataFrame
    results: Dict[str, pd.DataFrame]
    pipeline: VarianceAnalysisPipeline


class DataLoader:
    """
    Data loading and filtering for variance analysis.
    
    This class provides methods to:
    - Load demo or production data
    - Run variance analysis pipeline
    - Filter data based on user selections
    - Cache results for performance
    
    Example:
        # Load data
        data = DataLoader.load_and_analyze()
        
        # Apply filters
        filters = FilterConfig(crop='Rice', district='Guntur')
        filtered = DataLoader.filter_data(data, filters)
    """
    
    _cached_data: Optional[AnalysisData] = None
    
    @classmethod
    def load_and_analyze(cls, use_cache: bool = True) -> Dict[str, Any]:
        """
        Load demo data and run analysis.
        
        Args:
            use_cache: Whether to use cached data if available
            
        Returns:
            Dictionary containing inspections, recommendations, results, and pipeline
        """
        if use_cache and cls._cached_data is not None:
            return {
                'inspections': cls._cached_data.inspections,
                'recommendations': cls._cached_data.recommendations,
                'results': cls._cached_data.results,
                'pipeline': cls._cached_data.pipeline
            }
        
        # Generate demo data
        df_insp, df_rec = generate_demo_data()
        
        # Initialize and run pipeline
        pipeline = VarianceAnalysisPipeline()
        pipeline.initialize(use_db=False)
        pipeline.df_inspections = df_insp
        pipeline.df_recommendations = df_rec
        
        results = pipeline.run_analysis()
        
        # Cache the results
        cls._cached_data = AnalysisData(
            inspections=df_insp,
            recommendations=df_rec,
            results=results,
            pipeline=pipeline
        )
        
        return {
            'inspections': df_insp,
            'recommendations': df_rec,
            'results': results,
            'pipeline': pipeline
        }
    
    @classmethod
    def load_from_database(cls, connection_string: str, **filters) -> Dict[str, Any]:
        """
        Load data from database and run analysis.
        
        Args:
            connection_string: Database connection string
            **filters: Optional filters to pass to data loading
            
        Returns:
            Dictionary containing analysis results
        """
        pipeline = VarianceAnalysisPipeline(connection_string)
        pipeline.initialize(use_db=True)
        pipeline.load_data(**filters)
        
        results = pipeline.run_analysis()
        
        return {
            'inspections': pipeline.df_inspections,
            'recommendations': pipeline.df_recommendations,
            'results': results,
            'pipeline': pipeline
        }
    
    @classmethod
    def load_from_csv(
        cls,
        inspections_path: str,
        recommendations_path: str,
        inspections_encoding: str = 'utf-8',
        recommendations_encoding: str = 'utf-8',
        date_columns: Optional[Dict[str, list]] = None
    ) -> Dict[str, Any]:
        """
        Load data from CSV files and run analysis.
        
        Args:
            inspections_path: Path to inspections CSV file
            recommendations_path: Path to recommendations CSV file
            inspections_encoding: Encoding for inspections file (default: utf-8)
            recommendations_encoding: Encoding for recommendations file (default: utf-8)
            date_columns: Optional dict specifying date columns to parse
                         e.g., {'inspections': ['inspection_date', 'actual_sowing_date'],
                                'recommendations': ['rec_sowing_date']}
            
        Returns:
            Dictionary containing inspections, recommendations, results, and pipeline
            
        Example:
            # Basic usage
            data = DataLoader.load_from_csv(
                'data/inspections.csv',
                'data/recommendations.csv'
            )
            
            # With date parsing
            data = DataLoader.load_from_csv(
                'data/inspections.csv',
                'data/recommendations.csv',
                date_columns={
                    'inspections': ['inspection_date', 'actual_soaking_date', 
                                   'actual_sowing_date', 'actual_transplant_date'],
                    'recommendations': ['rec_soaking_date', 'rec_sowing_date', 
                                       'rec_transplant_date']
                }
            )
        """
        # Default date columns if not specified
        if date_columns is None:
            date_columns = {
                'inspections': [
                    'inspection_date',
                    'actual_soaking_date', 'actual_sowing_date',
                    'actual_transplant_date', 'actual_flowering_date',
                    'season_start_date'
                ],
                'recommendations': [
                    'rec_soaking_date', 'rec_sowing_date',
                    'rec_transplant_date', 'rec_flowering_date',
                    'effective_start', 'effective_end'
                ]
            }
        
        # Load inspections CSV
        insp_date_cols = date_columns.get('inspections', [])
        df_insp = pd.read_csv(
            inspections_path,
            encoding=inspections_encoding,
            parse_dates=[col for col in insp_date_cols if col],
            low_memory=False
        )
        
        # Load recommendations CSV
        rec_date_cols = date_columns.get('recommendations', [])
        df_rec = pd.read_csv(
            recommendations_path,
            encoding=recommendations_encoding,
            parse_dates=[col for col in rec_date_cols if col],
            low_memory=False
        )
        
        # Initialize and run pipeline
        pipeline = VarianceAnalysisPipeline()
        pipeline.initialize(use_db=False)
        pipeline.df_inspections = df_insp
        pipeline.df_recommendations = df_rec
        
        results = pipeline.run_analysis()
        
        # Cache the results
        cls._cached_data = AnalysisData(
            inspections=df_insp,
            recommendations=df_rec,
            results=results,
            pipeline=pipeline
        )
        
        return {
            'inspections': df_insp,
            'recommendations': df_rec,
            'results': results,
            'pipeline': pipeline
        }
    
    @classmethod
    def load_from_excel(
        cls,
        file_path: str,
        inspections_sheet: str = 'inspections',
        recommendations_sheet: str = 'recommendations',
        date_columns: Optional[Dict[str, list]] = None
    ) -> Dict[str, Any]:
        """
        Load data from Excel file with multiple sheets and run analysis.
        
        Args:
            file_path: Path to Excel file
            inspections_sheet: Name of sheet containing inspections data
            recommendations_sheet: Name of sheet containing recommendations data
            date_columns: Optional dict specifying date columns to parse
            
        Returns:
            Dictionary containing inspections, recommendations, results, and pipeline
            
        Example:
            data = DataLoader.load_from_excel(
                'data/agricultural_data.xlsx',
                inspections_sheet='Inspections',
                recommendations_sheet='Recommendations'
            )
        """
        # Default date columns if not specified
        if date_columns is None:
            date_columns = {
                'inspections': [
                    'inspection_date',
                    'actual_soaking_date', 'actual_sowing_date',
                    'actual_transplant_date', 'actual_flowering_date',
                    'season_start_date'
                ],
                'recommendations': [
                    'rec_soaking_date', 'rec_sowing_date',
                    'rec_transplant_date', 'rec_flowering_date',
                    'effective_start', 'effective_end'
                ]
            }
        
        # Load inspections sheet
        insp_date_cols = date_columns.get('inspections', [])
        df_insp = pd.read_excel(
            file_path,
            sheet_name=inspections_sheet,
            parse_dates=[col for col in insp_date_cols if col]
        )
        
        # Load recommendations sheet
        rec_date_cols = date_columns.get('recommendations', [])
        df_rec = pd.read_excel(
            file_path,
            sheet_name=recommendations_sheet,
            parse_dates=[col for col in rec_date_cols if col]
        )
        
        # Initialize and run pipeline
        pipeline = VarianceAnalysisPipeline()
        pipeline.initialize(use_db=False)
        pipeline.df_inspections = df_insp
        pipeline.df_recommendations = df_rec
        
        results = pipeline.run_analysis()
        
        # Cache the results
        cls._cached_data = AnalysisData(
            inspections=df_insp,
            recommendations=df_rec,
            results=results,
            pipeline=pipeline
        )
        
        return {
            'inspections': df_insp,
            'recommendations': df_rec,
            'results': results,
            'pipeline': pipeline
        }
    
    @classmethod
    def filter_data(
        cls,
        data: Dict[str, Any],
        filters: FilterConfig
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Filter data based on sidebar selections.
        
        Args:
            data: The loaded analysis data dictionary
            filters: FilterConfig with filter selections
            
        Returns:
            Tuple of (filtered_inspections_df, filtered_summary_df)
        """
        df_insp = data['inspections'].copy()
        df_summary = data['results']['inspection_summaries'].copy()
        
        # Apply crop filter
        if filters.crop != 'All':
            mask = df_insp['crop_name'] == filters.crop
            df_insp = df_insp[mask]
        
        # Apply variety filter
        if filters.variety != 'All':
            mask = df_insp['variety_name'] == filters.variety
            df_insp = df_insp[mask]
        
        # Apply district filter
        if filters.district != 'All':
            mask = df_insp['district_name'] == filters.district
            df_insp = df_insp[mask]
        
        # Apply season filter (if present)
        if filters.season != 'All' and 'season_code' in df_insp.columns:
            mask = df_insp['season_code'] == filters.season
            df_insp = df_insp[mask]
        
        # Filter summary to match inspections
        df_summary = df_summary[df_summary['inspection_id'].isin(df_insp['inspection_id'])]
        
        # Apply category filter
        if filters.category != 'All':
            df_summary = df_summary[df_summary['variance_category'] == filters.category]
            df_insp = df_insp[df_insp['inspection_id'].isin(df_summary['inspection_id'])]
        
        return df_insp, df_summary
    
    @classmethod
    def filter_data_dict(
        cls,
        data: Dict[str, Any],
        filters: Dict[str, str]
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Filter data using a dictionary of filters.
        
        Args:
            data: The loaded analysis data dictionary
            filters: Dictionary with filter keys (crop, variety, category, district)
            
        Returns:
            Tuple of (filtered_inspections_df, filtered_summary_df)
        """
        filter_config = FilterConfig(
            crop=filters.get('crop', 'All'),
            variety=filters.get('variety', 'All'),
            category=filters.get('category', 'All'),
            district=filters.get('district', 'All'),
            season=filters.get('season', 'All')
        )
        return cls.filter_data(data, filter_config)
    
    @classmethod
    def get_filter_options(cls, data: Dict[str, Any]) -> Dict[str, list]:
        """
        Get available filter options from data.
        
        Args:
            data: The loaded analysis data dictionary
            
        Returns:
            Dictionary with filter option lists
        """
        df_insp = data['inspections']
        df_summary = data['results']['inspection_summaries']
        
        return {
            'crops': ['All'] + df_insp['crop_name'].unique().tolist(),
            'varieties': ['All'] + df_insp['variety_name'].unique().tolist(),
            'categories': ['All'] + df_summary['variance_category'].unique().tolist(),
            'districts': ['All'] + df_insp['district_name'].unique().tolist(),
            'seasons': ['All'] + df_insp['season_code'].unique().tolist() if 'season_code' in df_insp.columns else ['All']
        }
    
    @classmethod
    def get_filtered_variety_options(cls, data: Dict[str, Any], crop: str) -> list:
        """
        Get variety options filtered by selected crop.
        
        Args:
            data: The loaded analysis data dictionary
            crop: Selected crop name
            
        Returns:
            List of variety options
        """
        df_insp = data['inspections']
        
        if crop != 'All':
            varieties = df_insp[df_insp['crop_name'] == crop]['variety_name'].unique().tolist()
        else:
            varieties = df_insp['variety_name'].unique().tolist()
        
        return ['All'] + varieties
    
    @classmethod
    def clear_cache(cls):
        """Clear the cached data"""
        cls._cached_data = None
    
    @classmethod
    def get_summary_metrics(cls, df_summary: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate summary metrics from filtered data.
        
        Args:
            df_summary: Filtered inspection summary DataFrame
            
        Returns:
            Dictionary with summary metrics
        """
        if len(df_summary) == 0:
            return {
                'total_inspections': 0,
                'avg_variance_score': 0,
                'pct_acceptable': 0,
                'critical_count': 0,
                'category_counts': {}
            }
        
        return {
            'total_inspections': len(df_summary),
            'avg_variance_score': df_summary['overall_variance_score'].mean(),
            'pct_acceptable': len(df_summary[df_summary['variance_category'].isin(['LOW', 'MEDIUM'])]) / len(df_summary) * 100,
            'critical_count': len(df_summary[df_summary['variance_category'] == 'CRITICAL']),
            'category_counts': df_summary['variance_category'].value_counts().to_dict()
        }
