"""
Visualization Module
====================

Helper functions for creating charts and visual elements.
Framework-agnostic where possible, with specific support for Plotly.
"""

from typing import Dict, List, Optional, Tuple, Any
import plotly.graph_objects as go


# =============================================================================
# COLOR DEFINITIONS
# =============================================================================

# Category colors (variance categories)
CATEGORY_COLORS = {
    'LOW': '#10b981',      # Green
    'MEDIUM': '#f59e0b',   # Amber
    'HIGH': '#ef4444',     # Red
    'CRITICAL': '#7c3aed'  # Purple
}

# Metric card gradient backgrounds
METRIC_GRADIENTS = {
    'default': 'linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%)',
    'green': 'linear-gradient(135deg, #065f46 0%, #047857 100%)',
    'blue': 'linear-gradient(135deg, #0369a1 0%, #0284c7 100%)',
    'orange': 'linear-gradient(135deg, #7c2d12 0%, #c2410c 100%)',
    'purple': 'linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%)',
    'teal': 'linear-gradient(135deg, #0d9488 0%, #14b8a6 100%)'
}

# Chart color palettes
CHART_PALETTES = {
    'primary': ['#1e3a5f', '#2d5a87', '#3d6a97', '#4d7aa7'],
    'accent': ['#0d9488', '#14b8a6', '#2dd4bf', '#5eead4'],
    'categorical': ['#0d9488', '#1e3a5f', '#f59e0b', '#10b981', '#6366f1', '#ef4444'],
    'diverging': ['#10b981', '#fef3c7', '#ef4444'],
    'sequential_green': ['#d1fae5', '#6ee7b7', '#34d399', '#10b981', '#059669'],
    'sequential_red': ['#fee2e2', '#fca5a5', '#f87171', '#ef4444', '#dc2626']
}


def get_category_color(category: str) -> str:
    """
    Get color for variance category.
    
    Args:
        category: Variance category (LOW, MEDIUM, HIGH, CRITICAL)
        
    Returns:
        Hex color code
    """
    return CATEGORY_COLORS.get(category.upper(), '#6b7280')


def get_severity_color(severity: str) -> str:
    """
    Get color for severity level.
    
    Args:
        severity: Severity level string
        
    Returns:
        Hex color code
    """
    severity_lower = severity.lower()
    if 'critical' in severity_lower:
        return '#ef4444'
    elif 'significant' in severity_lower or 'high' in severity_lower:
        return '#f59e0b'
    elif 'moderate' in severity_lower or 'medium' in severity_lower:
        return '#fbbf24'
    else:
        return '#10b981'


# =============================================================================
# PLOTLY CHART HELPERS
# =============================================================================

def create_gauge_chart(
    value: float,
    title: str,
    thresholds: List[float] = [0.2, 0.4, 0.6],
    max_value: float = 1.0
) -> go.Figure:
    """
    Create a gauge chart for score visualization.
    
    Args:
        value: The value to display
        title: Chart title
        thresholds: List of threshold values for color bands
        max_value: Maximum value for the gauge
        
    Returns:
        Plotly Figure object
    """
    # Determine color based on value
    if value <= thresholds[0]:
        color = '#10b981'  # Green
    elif value <= thresholds[1]:
        color = '#f59e0b'  # Amber
    elif value <= thresholds[2]:
        color = '#ef4444'  # Red
    else:
        color = '#7c3aed'  # Purple
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value,
        title={'text': title, 'font': {'size': 16, 'color': '#1f2937'}},
        number={'font': {'size': 32, 'color': '#1f2937'}, 'suffix': ''},
        gauge={
            'axis': {'range': [0, max_value], 'tickwidth': 1, 'tickcolor': '#d1d5db'},
            'bar': {'color': color},
            'bgcolor': 'white',
            'borderwidth': 2,
            'bordercolor': '#e5e7eb',
            'steps': [
                {'range': [0, thresholds[0]], 'color': '#d1fae5'},
                {'range': [thresholds[0], thresholds[1]], 'color': '#fef3c7'},
                {'range': [thresholds[1], thresholds[2]], 'color': '#fee2e2'},
                {'range': [thresholds[2], max_value], 'color': '#ede9fe'}
            ],
            'threshold': {
                'line': {'color': '#1f2937', 'width': 4},
                'thickness': 0.75,
                'value': value
            }
        }
    ))
    
    fig.update_layout(
        height=250,
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': '#1f2937', 'family': 'IBM Plex Sans, sans-serif'}
    )
    
    return fig


def get_plotly_layout_defaults() -> Dict[str, Any]:
    """
    Get default Plotly layout configuration.
    
    Returns:
        Dictionary with default layout settings
    """
    return {
        'paper_bgcolor': 'rgba(0,0,0,0)',
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'font': {
            'family': 'IBM Plex Sans, sans-serif',
            'color': '#1f2937'
        },
        'margin': dict(l=20, r=20, t=30, b=20),
        'showlegend': True,
        'legend': {
            'orientation': 'h',
            'yanchor': 'bottom',
            'y': -0.15,
            'xanchor': 'center',
            'x': 0.5
        }
    }


def create_bar_chart(
    df,
    x: str,
    y: str,
    color: Optional[str] = None,
    orientation: str = 'v',
    color_scale: str = 'Reds',
    title: str = ''
) -> go.Figure:
    """
    Create a styled bar chart.
    
    Args:
        df: DataFrame with data
        x: Column name for x-axis
        y: Column name for y-axis
        color: Column name for color encoding
        orientation: 'v' for vertical, 'h' for horizontal
        color_scale: Plotly color scale name
        title: Chart title
        
    Returns:
        Plotly Figure object
    """
    import plotly.express as px
    
    fig = px.bar(
        df,
        x=x,
        y=y,
        color=color if color else y,
        orientation=orientation,
        color_continuous_scale=color_scale
    )
    
    layout = get_plotly_layout_defaults()
    layout['title'] = title
    layout['height'] = 400
    layout['showlegend'] = False
    
    fig.update_layout(**layout)
    
    return fig


def create_pie_chart(
    df,
    values: str,
    names: str,
    color_map: Optional[Dict[str, str]] = None,
    hole: float = 0.4,
    title: str = ''
) -> go.Figure:
    """
    Create a styled donut/pie chart.
    
    Args:
        df: DataFrame with data
        values: Column name for values
        names: Column name for names/labels
        color_map: Dictionary mapping names to colors
        hole: Size of center hole (0 for pie, >0 for donut)
        title: Chart title
        
    Returns:
        Plotly Figure object
    """
    import plotly.express as px
    
    fig = px.pie(
        df,
        values=values,
        names=names,
        color=names,
        color_discrete_map=color_map or CATEGORY_COLORS,
        hole=hole
    )
    
    layout = get_plotly_layout_defaults()
    layout['title'] = title
    layout['height'] = 350
    
    fig.update_layout(**layout)
    
    return fig


# =============================================================================
# VISUALIZATION HELPER CLASS
# =============================================================================

class VisualizationHelper:
    """
    Helper class for visualization tasks.
    
    Provides static methods for:
    - Color selection
    - Chart creation
    - Style configuration
    
    Example:
        color = VisualizationHelper.get_category_color('HIGH')
        fig = VisualizationHelper.create_gauge(0.45, 'Variance Score')
    """
    
    @staticmethod
    def get_category_color(category: str) -> str:
        """Get color for variance category"""
        return get_category_color(category)
    
    @staticmethod
    def get_severity_color(severity: str) -> str:
        """Get color for severity level"""
        return get_severity_color(severity)
    
    @staticmethod
    def create_gauge(value: float, title: str, **kwargs) -> go.Figure:
        """Create gauge chart"""
        return create_gauge_chart(value, title, **kwargs)
    
    @staticmethod
    def get_category_badge_html(category: str) -> str:
        """
        Get HTML for a category badge.
        
        Args:
            category: Variance category
            
        Returns:
            HTML string for badge
        """
        color = get_category_color(category)
        return f'<span style="background-color:{color}; color:white; padding:0.5rem 1rem; border-radius:20px; font-weight:600;">{category}</span>'
    
    @staticmethod
    def get_severity_badge_html(severity: str) -> str:
        """
        Get HTML for a severity badge.
        
        Args:
            severity: Severity level string
            
        Returns:
            HTML string for badge
        """
        color = get_severity_color(severity)
        # Extract just the text part if emoji is included
        text = severity.split(' ')[-1] if ' ' in severity else severity
        return f'<span style="background-color:{color}; color:white; padding:0.25rem 0.75rem; border-radius:15px; font-size:0.85rem; font-weight:500;">{severity}</span>'
    
    @staticmethod
    def format_metric_card_html(value: Any, label: str, variant: str = 'default') -> str:
        """
        Generate HTML for a metric card.
        
        Args:
            value: The metric value
            label: Label text
            variant: Color variant (default, green, blue, orange, purple, teal)
            
        Returns:
            HTML string
        """
        gradient = METRIC_GRADIENTS.get(variant, METRIC_GRADIENTS['default'])
        
        return f'''
        <div style="background: {gradient}; border-radius: 12px; padding: 1.5rem; color: white; margin-bottom: 1rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h2 style="font-size: 2.5rem; margin: 0; font-weight: 700; color: white;">{value}</h2>
            <p style="margin: 0.5rem 0 0 0; opacity: 0.85; font-size: 0.9rem; color: white;">{label}</p>
        </div>
        '''
    
    @staticmethod
    def get_variance_histogram_config(df, column: str = 'overall_variance_score') -> Dict[str, Any]:
        """
        Get configuration for variance score histogram.
        
        Args:
            df: DataFrame with variance scores
            column: Column name for scores
            
        Returns:
            Configuration dictionary for histogram
        """
        return {
            'data': df[column].tolist(),
            'nbins': 20,
            'color': '#0284c7',
            'thresholds': [
                {'value': 0.2, 'color': '#10b981', 'label': 'Low'},
                {'value': 0.4, 'color': '#f59e0b', 'label': 'Med'},
                {'value': 0.6, 'color': '#ef4444', 'label': 'High'}
            ]
        }
