"""
Descriptions Module
===================

Text descriptions, reason codes, and explanatory content.
Centralized location for all user-facing text.
"""

from typing import Dict


# =============================================================================
# REASON CODE DESCRIPTIONS
# =============================================================================

REASON_CODE_DESCRIPTIONS: Dict[str, str] = {
    'upstream_timing_slip': 'Upstream Timing Slip - Late soaking caused delayed sowing',
    'transplant_delay': 'Transplant Delay - Seedlings transplanted later than recommended',
    'pest_pressure': 'Pest Pressure - High pest levels impacting crop health',
    'disease_outbreak': 'Disease Outbreak - Significant disease presence detected',
    'establishment_issue': 'Establishment Issue - Poor plant population due to transplant problems',
    'poor_germination': 'Poor Germination - Below-target plant population from germination',
    'low_tillering': 'Low Tillering - Insufficient tiller development',
    'early_planting': 'Early Planting - Crop planted before optimal window',
    'data_quality_issue': 'Data Quality Issue - Values outside valid ranges',
    'missing_data': 'Missing Data - Required observations not recorded'
}


def get_reason_code_description(code: str) -> str:
    """
    Get human-readable description for reason codes.
    
    Args:
        code: Reason code string
        
    Returns:
        Human-readable description
    """
    return REASON_CODE_DESCRIPTIONS.get(code, code.replace('_', ' ').title())


# =============================================================================
# VARIANCE CATEGORY DESCRIPTIONS
# =============================================================================

VARIANCE_CATEGORY_DESCRIPTIONS: Dict[str, Dict[str, str]] = {
    'LOW': {
        'range': '0.00 - 0.20',
        'label': 'Excellent',
        'interpretation': 'On target - field is performing as expected',
        'action': 'Continue current practices'
    },
    'MEDIUM': {
        'range': '0.20 - 0.40',
        'label': 'Good',
        'interpretation': 'Minor deviations - generally acceptable',
        'action': 'Monitor for trends'
    },
    'HIGH': {
        'range': '0.40 - 0.60',
        'label': 'Concern',
        'interpretation': 'Significant deviations from recommendations',
        'action': 'Investigation recommended'
    },
    'CRITICAL': {
        'range': '0.60 - 1.00',
        'label': 'Action Required',
        'interpretation': 'Major issues - field significantly off-track',
        'action': 'Immediate intervention needed'
    }
}


# =============================================================================
# ATTRIBUTE DESCRIPTIONS
# =============================================================================

ATTRIBUTE_DESCRIPTIONS: Dict[str, Dict[str, str]] = {
    'SOAKING_DATE': {
        'name': 'Soaking Date',
        'description': 'Date when seeds were soaked for germination',
        'importance': 'Foundation activity that determines the entire crop calendar',
        'tolerance': '±3 days from recommended',
        'weight': '10%'
    },
    'SOWING_DATE': {
        'name': 'Sowing Date',
        'description': 'Date when seeds were sown in the nursery',
        'importance': 'Critical timing event affecting entire crop cycle',
        'tolerance': '±5 days from recommended',
        'weight': '15%'
    },
    'TRANSPLANT_DATE': {
        'name': 'Transplant Date',
        'description': 'Date when seedlings were transplanted to main field',
        'importance': 'Affects establishment success and yield potential',
        'tolerance': '±7 days from recommended',
        'weight': '12%'
    },
    'FLOWERING_DATE': {
        'name': 'Flowering Date',
        'description': 'Date when 50% of plants reached flowering stage',
        'importance': 'Indicator of crop maturity and harvest timing',
        'tolerance': '±5 days from expected',
        'weight': '8%'
    },
    'PEST_SEVERITY': {
        'name': 'Pest Severity',
        'description': 'Severity score of pest infestation (0-10 scale)',
        'importance': 'Direct impact on yield and quality',
        'tolerance': 'Maximum acceptable: 3',
        'weight': '15%'
    },
    'TILLER_COUNT': {
        'name': 'Tiller Count',
        'description': 'Number of tillers per plant sample',
        'importance': 'Key determinant of grain production potential',
        'tolerance': '±15% from target',
        'weight': '12%'
    },
    'HEALTH_SCORE': {
        'name': 'Health Score',
        'description': 'Overall crop health rating (1-5 scale)',
        'importance': 'Composite indicator of crop condition',
        'tolerance': 'Minimum acceptable: 3',
        'weight': '13%'
    },
    'PLANT_RATIO': {
        'name': 'Plant Ratio',
        'description': 'Percentage of target plant population achieved',
        'importance': 'Determines yield potential through stand establishment',
        'tolerance': '±10% from target',
        'weight': '10%'
    },
    'DISEASE_SEVERITY': {
        'name': 'Disease Severity',
        'description': 'Severity score of disease incidence (0-10 scale)',
        'importance': 'Impacts crop quality and marketability',
        'tolerance': 'Maximum acceptable: 2',
        'weight': '5%'
    }
}


# =============================================================================
# RULE EXPLANATION TABLE
# =============================================================================

RULE_EXPLANATIONS: Dict[str, Dict[str, str]] = {
    'upstream_timing_slip': {
        'conditions': 'Late soaking date + Late sowing date',
        'impact': 'Entire crop cycle delayed',
        'priority': 'High'
    },
    'pest_pressure': {
        'conditions': 'High pest severity + Low health score',
        'impact': 'Yield loss, quality issues',
        'priority': 'High'
    },
    'establishment_issue': {
        'conditions': 'Low plant ratio + Late transplanting',
        'impact': 'Poor stand, reduced yield',
        'priority': 'High'
    },
    'disease_outbreak': {
        'conditions': 'High disease severity + Low health',
        'impact': 'Significant crop damage',
        'priority': 'High'
    },
    'low_tillering': {
        'conditions': 'Tiller count below minimum',
        'impact': 'Reduced grain production',
        'priority': 'Medium'
    },
    'early_planting': {
        'conditions': 'Sowing date >7 days early',
        'impact': 'Risk of weather damage',
        'priority': 'Medium'
    },
    'poor_germination': {
        'conditions': 'Low plant ratio only',
        'impact': 'Sub-optimal population',
        'priority': 'Medium'
    },
    'data_quality_issue': {
        'conditions': 'Values outside valid ranges',
        'impact': 'Unreliable analysis',
        'priority': 'Low'
    }
}


# =============================================================================
# EXPLANATORY CONTENT
# =============================================================================

ANALYSIS_EXPLANATIONS = {
    'variance_analysis': """
**Variance analysis** compares actual field observations against recommended best practices:

- **Date Variances**: Early/late timing for soaking, sowing, transplanting
- **Numeric Variances**: Pest levels, tiller counts, health scores, plant population

Each variance is scored and weighted to produce an **overall variance score** from 0 to 1.
""",
    
    'weights_tolerances': """
**Tolerances** define acceptable deviation ranges:
- Date attributes: ±3-7 days depending on activity
- Numeric attributes: Percentage-based (e.g., ±15% for tillers) or absolute ranges

**Weights** determine importance in overall score (sum to 1.0).
""",
    
    'pipeline_flow': """
```
1. DATA LOAD
   └─> Inspections + Recommendations + Metadata

2. MERGE
   └─> Match each inspection to its CVS recommendation

3. COMPUTE VARIANCES
   └─> For each attribute: actual vs recommended
       ├─> Date: difference in days
       ├─> Numeric: difference + z-score if stddev available
       └─> Check against tolerance, assign status

4. ASSIGN REASON CODES
   └─> Evaluate rule conditions
       └─> Match patterns to business causes

5. COMPUTE SCORES
   └─> Standardize variances (0-1)
   └─> Apply weights
   └─> Sum for overall score

6. AGGREGATE
   └─> By CVS, location, time
   └─> Identify systemic patterns
```
""",
    
    'reason_code_assignment': """
Reason codes are assigned using a **rule-based engine** that evaluates multiple conditions.

**Priority System**: Rules are evaluated in priority order. If multiple rules match, all reason codes 
are captured, but the **primary reason code** reflects the highest-priority issue.
"""
}


# =============================================================================
# STATUS LABELS
# =============================================================================

VARIANCE_STATUS_LABELS = {
    'ON_TARGET': 'On Target',
    'EARLY': 'Early',
    'LATE': 'Late',
    'ABOVE': 'Above Target',
    'BELOW': 'Below Target',
    'MISSING_ACTUAL': 'Missing Actual',
    'MISSING_RECOMMENDATION': 'Missing Recommendation'
}


SEVERITY_FLAG_LABELS = {
    'OK': 'OK',
    'WARNING': 'Warning',
    'CRITICAL': 'Critical'
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_attribute_name(code: str) -> str:
    """
    Get human-readable attribute name.
    
    Args:
        code: Attribute code
        
    Returns:
        Human-readable name
    """
    if code in ATTRIBUTE_DESCRIPTIONS:
        return ATTRIBUTE_DESCRIPTIONS[code]['name']
    return code.replace('_', ' ').title()


def get_variance_status_label(status: str) -> str:
    """
    Get human-readable variance status label.
    
    Args:
        status: Variance status code
        
    Returns:
        Human-readable label
    """
    return VARIANCE_STATUS_LABELS.get(status, status)


def format_reason_codes_list(codes: list) -> str:
    """
    Format list of reason codes as human-readable text.
    
    Args:
        codes: List of reason code strings
        
    Returns:
        Formatted string with descriptions
    """
    if not codes:
        return "No significant issues identified"
    
    descriptions = [get_reason_code_description(code) for code in codes]
    return "\n".join(f"• {desc}" for desc in descriptions)


def get_category_explanation(category: str) -> Dict[str, str]:
    """
    Get full explanation for a variance category.
    
    Args:
        category: Variance category (LOW, MEDIUM, HIGH, CRITICAL)
        
    Returns:
        Dictionary with category details
    """
    return VARIANCE_CATEGORY_DESCRIPTIONS.get(
        category.upper(),
        {'label': 'Unknown', 'interpretation': 'Category not recognized', 'action': 'Review data'}
    )
