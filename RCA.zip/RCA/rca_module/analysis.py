"""
Analysis Engine Module
======================

Business logic for interpreting variance analysis results.
Includes severity assessment, interpretations, and business action recommendations.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class BusinessAction:
    """Container for business action recommendation"""
    priority: str
    urgency: str
    issue: str
    actions: List[str]
    owner: str


@dataclass
class AttributeInterpretation:
    """Container for attribute interpretation"""
    severity: str
    impact: str
    tolerance_status: str
    context: str
    full_interpretation: str


class AnalysisEngine:
    """
    Analysis and interpretation engine for variance analysis results.
    
    This class provides methods to:
    - Assess severity of variances
    - Generate automatic interpretations
    - Recommend business actions
    - Prioritize issues
    
    Example:
        # Get severity
        severity = AnalysisEngine.get_severity_level(pct_of_total=25.5)
        
        # Get interpretation
        interp = AnalysisEngine.get_attribute_interpretation(
            'PLANT_RATIO', pct_of_total=18.5, pct_within_tolerance=72.0
        )
        
        # Get business actions
        action = AnalysisEngine.get_business_action(
            'PEST_SEVERITY', pct_of_total=22.0, pct_within_tolerance=68.0, rank=1
        )
    """
    
    # Severity thresholds (percentage of total variance)
    SEVERITY_THRESHOLDS = {
        'critical': 25,
        'significant': 15,
        'moderate': 8
    }
    
    # Tolerance target (percentage within tolerance)
    TOLERANCE_TARGET = 80
    
    @classmethod
    def get_severity_level(cls, pct_of_total: float) -> str:
        """
        Get severity level based on percentage of total variance.
        
        Args:
            pct_of_total: Percentage contribution to total variance
            
        Returns:
            Severity string with emoji indicator
        """
        if pct_of_total >= cls.SEVERITY_THRESHOLDS['critical']:
            return "🔴 Critical"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['significant']:
            return "🟠 Significant"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['moderate']:
            return "🟡 Moderate"
        else:
            return "🟢 Good"
    
    @classmethod
    def get_severity_level_plain(cls, pct_of_total: float) -> str:
        """
        Get severity level without emoji (for API responses).
        
        Args:
            pct_of_total: Percentage contribution to total variance
            
        Returns:
            Severity string without emoji
        """
        if pct_of_total >= cls.SEVERITY_THRESHOLDS['critical']:
            return "Critical"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['significant']:
            return "Significant"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['moderate']:
            return "Moderate"
        else:
            return "Good"
    
    @classmethod
    def get_impact_description(cls, pct_of_total: float) -> str:
        """
        Get impact description based on variance contribution.
        
        Args:
            pct_of_total: Percentage contribution to total variance
            
        Returns:
            Impact description string
        """
        if pct_of_total >= cls.SEVERITY_THRESHOLDS['critical']:
            return "Major contributor to overall variance"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['significant']:
            return "Notable contributor to variance"
        elif pct_of_total >= cls.SEVERITY_THRESHOLDS['moderate']:
            return "Some deviation from targets"
        else:
            return "Minor or negligible variance"
    
    @classmethod
    def get_tolerance_status(cls, pct_within_tolerance: float) -> str:
        """
        Get tolerance compliance status.
        
        Args:
            pct_within_tolerance: Percentage of inspections within tolerance
            
        Returns:
            Tolerance status description
        """
        if pct_within_tolerance >= 90:
            return "Excellent compliance"
        elif pct_within_tolerance >= cls.TOLERANCE_TARGET:
            return "Acceptable compliance"
        elif pct_within_tolerance >= 70:
            return "Below target - needs attention"
        else:
            return "Poor compliance - urgent action needed"
    
    @classmethod
    def get_attribute_context(cls, attr_code: str, pct_within_tolerance: float) -> str:
        """
        Get attribute-specific context message.
        
        Args:
            attr_code: Attribute code
            pct_within_tolerance: Percentage within tolerance
            
        Returns:
            Context-specific interpretation
        """
        below_target = pct_within_tolerance < cls.TOLERANCE_TARGET
        pct_issues = 100 - pct_within_tolerance
        
        contexts = {
            'PLANT_RATIO': f"Plant population is {'frequently below target' if below_target else 'generally adequate'}. {pct_issues:.0f}% of inspections show population issues.",
            'TILLER_COUNT': f"Tiller development {'needs improvement' if below_target else 'is on track'}. Affects yield potential directly.",
            'SOAKING_DATE': f"Seed soaking timing {'often deviates' if below_target else 'mostly follows'} schedule. Upstream delays cascade downstream.",
            'SOWING_DATE': f"Sowing dates {'frequently off-schedule' if below_target else 'well-managed'}. Critical for crop cycle alignment.",
            'TRANSPLANT_DATE': f"Transplanting timing {'needs attention' if below_target else 'is acceptable'}. Affects establishment success.",
            'FLOWERING_DATE': f"Flowering observations {'inconsistent' if below_target else 'align with expectations'}.",
            'HEALTH_SCORE': f"Overall crop health {'concerning' if below_target else 'satisfactory'}. Reflects combined stress factors.",
            'PEST_SEVERITY': f"Pest pressure {'above acceptable levels' if below_target else 'under control'} in most inspections.",
            'DISEASE_SEVERITY': f"Disease incidence {'elevated' if below_target else 'within limits'}."
        }
        
        return contexts.get(attr_code, "Attribute performance varies across inspections.")
    
    @classmethod
    def get_attribute_interpretation(
        cls,
        attr_code: str,
        pct_of_total: float,
        pct_within_tolerance: float
    ) -> str:
        """
        Generate automatic interpretation for an attribute.
        
        Args:
            attr_code: Attribute code
            pct_of_total: Percentage of total variance
            pct_within_tolerance: Percentage within tolerance
            
        Returns:
            Full interpretation string
        """
        impact = cls.get_impact_description(pct_of_total)
        tol_status = cls.get_tolerance_status(pct_within_tolerance)
        context = cls.get_attribute_context(attr_code, pct_within_tolerance)
        
        return f"{impact}. {tol_status}. {context}"
    
    @classmethod
    def get_attribute_interpretation_structured(
        cls,
        attr_code: str,
        pct_of_total: float,
        pct_within_tolerance: float
    ) -> AttributeInterpretation:
        """
        Get structured interpretation for an attribute.
        
        Args:
            attr_code: Attribute code
            pct_of_total: Percentage of total variance
            pct_within_tolerance: Percentage within tolerance
            
        Returns:
            AttributeInterpretation dataclass
        """
        return AttributeInterpretation(
            severity=cls.get_severity_level(pct_of_total),
            impact=cls.get_impact_description(pct_of_total),
            tolerance_status=cls.get_tolerance_status(pct_within_tolerance),
            context=cls.get_attribute_context(attr_code, pct_within_tolerance),
            full_interpretation=cls.get_attribute_interpretation(
                attr_code, pct_of_total, pct_within_tolerance
            )
        )
    
    @classmethod
    def get_business_action(
        cls,
        attr_code: str,
        pct_of_total: float,
        pct_within_tolerance: float,
        rank: int
    ) -> BusinessAction:
        """
        Generate business action recommendation for an attribute.
        
        Args:
            attr_code: Attribute code
            pct_of_total: Percentage of total variance
            pct_within_tolerance: Percentage within tolerance
            rank: Ranking position (1 = highest contributor)
            
        Returns:
            BusinessAction dataclass with recommendations
        """
        # Action definitions by attribute
        action_definitions = {
            'PLANT_RATIO': {
                'issue': 'Low plant population',
                'actions': [
                    'Review seed quality and germination rates',
                    'Check seedbed preparation and planting depth',
                    'Evaluate transplanting techniques and timing',
                    'Assess water management during establishment'
                ],
                'owner': 'Field Operations Team'
            },
            'TILLER_COUNT': {
                'issue': 'Insufficient tillering',
                'actions': [
                    'Review nitrogen fertilization timing and rates',
                    'Check plant spacing compliance',
                    'Evaluate water stress during tillering phase',
                    'Assess variety-specific tillering potential'
                ],
                'owner': 'Agronomist Team'
            },
            'SOAKING_DATE': {
                'issue': 'Seed soaking timing deviation',
                'actions': [
                    'Improve seed distribution logistics',
                    'Enhance farmer communication on schedules',
                    'Review weather-based scheduling flexibility',
                    'Track upstream supply chain delays'
                ],
                'owner': 'Supply Chain & Extension'
            },
            'SOWING_DATE': {
                'issue': 'Sowing schedule deviation',
                'actions': [
                    'Reinforce optimal sowing window messaging',
                    'Address input availability issues',
                    'Review labor availability constraints',
                    'Consider weather forecast integration'
                ],
                'owner': 'Extension Team'
            },
            'TRANSPLANT_DATE': {
                'issue': 'Transplanting delays',
                'actions': [
                    'Ensure nursery readiness aligns with schedule',
                    'Address labor bottlenecks during peak period',
                    'Review field preparation timelines',
                    'Optimize nursery-to-field logistics'
                ],
                'owner': 'Field Operations Team'
            },
            'HEALTH_SCORE': {
                'issue': 'Suboptimal crop health',
                'actions': [
                    'Conduct detailed stress factor analysis',
                    'Review integrated pest management practices',
                    'Assess nutrient deficiency patterns',
                    'Evaluate water management practices'
                ],
                'owner': 'Agronomist Team'
            },
            'PEST_SEVERITY': {
                'issue': 'Elevated pest pressure',
                'actions': [
                    'Intensify pest monitoring frequency',
                    'Review IPM implementation effectiveness',
                    'Ensure timely pesticide application',
                    'Consider resistant variety recommendations'
                ],
                'owner': 'Plant Protection Team'
            },
            'DISEASE_SEVERITY': {
                'issue': 'Disease incidence above threshold',
                'actions': [
                    'Identify disease hotspots geographically',
                    'Review prophylactic treatment schedules',
                    'Assess seed treatment effectiveness',
                    'Consider crop rotation recommendations'
                ],
                'owner': 'Plant Protection Team'
            },
            'FLOWERING_DATE': {
                'issue': 'Flowering timing variance',
                'actions': [
                    'Review variety maturity group alignment',
                    'Assess environmental stress impacts',
                    'Validate observation recording accuracy',
                    'Compare against historical patterns'
                ],
                'owner': 'Research Team'
            }
        }
        
        # Default action if attribute not found
        default_action = {
            'issue': 'Performance deviation',
            'actions': ['Investigate root causes', 'Review historical trends', 'Consult agronomists'],
            'owner': 'Operations Team'
        }
        
        action_info = action_definitions.get(attr_code, default_action)
        
        # Determine priority based on ranking and values
        if rank <= 2 and pct_of_total >= cls.SEVERITY_THRESHOLDS['significant']:
            priority = "🔴 HIGH"
            urgency = "Immediate action required"
        elif rank <= 4 and pct_of_total >= cls.SEVERITY_THRESHOLDS['moderate']:
            priority = "🟠 MEDIUM"
            urgency = "Address within current season"
        else:
            priority = "🟢 LOW"
            urgency = "Monitor and review periodically"
        
        return BusinessAction(
            priority=priority,
            urgency=urgency,
            issue=action_info['issue'],
            actions=action_info['actions'],
            owner=action_info['owner']
        )
    
    @classmethod
    def get_business_action_dict(
        cls,
        attr_code: str,
        pct_of_total: float,
        pct_within_tolerance: float,
        rank: int
    ) -> Dict[str, Any]:
        """
        Get business action as dictionary (for API responses).
        
        Args:
            attr_code: Attribute code
            pct_of_total: Percentage of total variance
            pct_within_tolerance: Percentage within tolerance
            rank: Ranking position
            
        Returns:
            Dictionary with action details
        """
        action = cls.get_business_action(attr_code, pct_of_total, pct_within_tolerance, rank)
        return {
            'priority': action.priority,
            'urgency': action.urgency,
            'issue': action.issue,
            'actions': action.actions,
            'owner': action.owner,
            'pct_of_total': pct_of_total,
            'pct_within_tolerance': pct_within_tolerance
        }
    
    @classmethod
    def generate_summary_recommendation(
        cls,
        attrs_below_target: int,
        top_contributor: str,
        top_pct: float
    ) -> Dict[str, Any]:
        """
        Generate overall summary recommendation.
        
        Args:
            attrs_below_target: Number of attributes below tolerance target
            top_contributor: Name of top variance contributor
            top_pct: Percentage contribution of top contributor
            
        Returns:
            Dictionary with recommendation type and message
        """
        top_name = top_contributor.replace('_', ' ').title()
        
        if attrs_below_target >= 4:
            return {
                'type': 'error',
                'title': 'Multiple Attributes Need Attention',
                'message': f"{attrs_below_target} attributes are below the 80% tolerance target. "
                          f"The highest variance contributor is **{top_name}** at {top_pct:.1f}% of total variance.",
                'recommendation': "Conduct a comprehensive field operations review focusing on timing discipline "
                                "and agronomic practice adherence."
            }
        elif attrs_below_target >= 2:
            return {
                'type': 'warning',
                'title': 'Targeted Improvements Needed',
                'message': f"{attrs_below_target} attributes require attention. "
                          f"Focus corrective efforts on **{top_name}** which contributes {top_pct:.1f}% of total variance.",
                'recommendation': "Address the top 2-3 variance drivers through targeted interventions."
            }
        else:
            return {
                'type': 'success',
                'title': 'Good Overall Performance',
                'message': f"Most attributes are within tolerance thresholds. "
                          f"Continue monitoring **{top_name}** ({top_pct:.1f}% of variance) for any emerging trends.",
                'recommendation': "Maintain current practices and focus on continuous improvement."
            }
    
    @classmethod
    def categorize_variance_score(cls, score: float) -> str:
        """
        Categorize variance score into category.
        
        Args:
            score: Overall variance score (0-1)
            
        Returns:
            Category string (LOW, MEDIUM, HIGH, CRITICAL)
        """
        if score <= 0.2:
            return 'LOW'
        elif score <= 0.4:
            return 'MEDIUM'
        elif score <= 0.6:
            return 'HIGH'
        else:
            return 'CRITICAL'
