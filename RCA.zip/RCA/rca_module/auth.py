"""
Authentication Module
=====================

Handles user authentication with session management.
Can be used with Streamlit session state or adapted for API token-based auth.
"""

from datetime import datetime
from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class SessionInfo:
    """Session information container"""
    username: str
    login_time: datetime
    is_valid: bool
    remaining_seconds: float


class Authenticator:
    """
    Authentication handler with session timeout support.
    
    For Streamlit usage, this integrates with st.session_state.
    For API usage, this can be adapted to work with JWT tokens.
    
    Example (Streamlit):
        success, message = Authenticator.login(username, password)
        if success:
            st.session_state.authenticated = True
            st.session_state.username = username
            st.session_state.login_time = datetime.now()
    
    Example (API):
        auth = Authenticator()
        if auth.validate(username, password):
            token = auth.create_token(username)
            return {"token": token}
    """
    
    # Default credentials (in production, use secure storage/database)
    USERS: Dict[str, str] = {
        "analyst": "analyst123"
    }
    
    # Session timeout in seconds (1 hour = 3600 seconds)
    SESSION_TIMEOUT: int = 3600
    
    @classmethod
    def validate(cls, username: str, password: str) -> bool:
        """
        Validate username and password.
        
        Args:
            username: The username to validate
            password: The password to validate
            
        Returns:
            True if credentials are valid, False otherwise
        """
        if username in cls.USERS:
            return cls.USERS[username] == password
        return False
    
    @classmethod
    def login(cls, username: str, password: str) -> Tuple[bool, str]:
        """
        Attempt login and return success status with message.
        
        Args:
            username: The username for login
            password: The password for login
            
        Returns:
            Tuple of (success_bool, message_string)
        """
        if not username or not password:
            return False, "Please enter both username and password."
        
        if cls.validate(username, password):
            return True, "Login successful!"
        return False, "Your username/password are incorrect. Please enter again."
    
    @classmethod
    def check_session_timeout(cls, login_time: Optional[datetime]) -> Tuple[bool, float]:
        """
        Check if a session has timed out.
        
        Args:
            login_time: The datetime when the user logged in
            
        Returns:
            Tuple of (is_valid_bool, remaining_seconds)
        """
        if login_time is None:
            return False, 0.0
        
        elapsed = (datetime.now() - login_time).total_seconds()
        remaining = max(0, cls.SESSION_TIMEOUT - elapsed)
        is_valid = elapsed <= cls.SESSION_TIMEOUT
        
        return is_valid, remaining
    
    @classmethod
    def format_remaining_time(cls, remaining_seconds: float) -> str:
        """
        Format remaining session time as a human-readable string.
        
        Args:
            remaining_seconds: Number of seconds remaining
            
        Returns:
            Formatted string like "45m 30s"
        """
        if remaining_seconds <= 0:
            return "Expired"
        
        minutes = int(remaining_seconds // 60)
        seconds = int(remaining_seconds % 60)
        return f"{minutes}m {seconds}s"
    
    @classmethod
    def get_session_info(cls, username: Optional[str], login_time: Optional[datetime]) -> SessionInfo:
        """
        Get complete session information.
        
        Args:
            username: The logged in username
            login_time: The login timestamp
            
        Returns:
            SessionInfo dataclass with session details
        """
        if username is None or login_time is None:
            return SessionInfo(
                username="",
                login_time=datetime.now(),
                is_valid=False,
                remaining_seconds=0.0
            )
        
        is_valid, remaining = cls.check_session_timeout(login_time)
        
        return SessionInfo(
            username=username,
            login_time=login_time,
            is_valid=is_valid,
            remaining_seconds=remaining
        )
    
    # =========================================================================
    # API Token Support (for future API deployment)
    # =========================================================================
    
    @classmethod
    def create_api_token(cls, username: str) -> Dict[str, Any]:
        """
        Create an API token for authenticated users.
        Placeholder for JWT token generation.
        
        Args:
            username: The authenticated username
            
        Returns:
            Dict with token and expiry information
        """
        # In production, use proper JWT library:
        # import jwt
        # token = jwt.encode({
        #     "sub": username,
        #     "exp": datetime.utcnow() + timedelta(hours=1)
        # }, SECRET_KEY, algorithm="HS256")
        
        return {
            "token_type": "bearer",
            "username": username,
            "expires_in": cls.SESSION_TIMEOUT,
            "note": "Implement JWT for production"
        }
    
    @classmethod
    def add_user(cls, username: str, password: str) -> bool:
        """
        Add a new user (for admin functionality).
        
        Args:
            username: New username
            password: New password
            
        Returns:
            True if user added successfully
        """
        if username in cls.USERS:
            return False
        cls.USERS[username] = password
        return True
    
    @classmethod
    def remove_user(cls, username: str) -> bool:
        """
        Remove a user (for admin functionality).
        
        Args:
            username: Username to remove
            
        Returns:
            True if user removed successfully
        """
        if username not in cls.USERS:
            return False
        del cls.USERS[username]
        return True
