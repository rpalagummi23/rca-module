"""
RCA Module - Root Cause Analysis for Agricultural Field Inspections
====================================================================

A modular Python package containing all business logic for variance analysis
and root cause analysis of agricultural field inspections.

This module can be:
- Used with Streamlit for dashboards
- Deployed as an API service (FastAPI/Flask)
- Used in batch processing pipelines

Example Usage:
    from rca_module import (
        Authenticator,
        DataLoader,
        AnalysisEngine,
        get_category_color,
        get_reason_code_description
    )
    
    # Load and analyze data
    data = DataLoader.load_and_analyze()
    filtered_data = DataLoader.filter_data(data, filters)
    
    # Get interpretations
    interpretation = AnalysisEngine.get_attribute_interpretation(attr_code, pct_total, pct_tol)
"""

__version__ = "1.0.0"

# Authentication
from .auth import Authenticator

# Data loading and filtering
from .data_loader import DataLoader

# Analysis and interpretation
from .analysis import AnalysisEngine

# Visualization helpers
from .visualization import (
    VisualizationHelper,
    get_category_color,
    create_gauge_chart
)

# Text descriptions
from .descriptions import (
    get_reason_code_description,
    VARIANCE_CATEGORY_DESCRIPTIONS,
    ATTRIBUTE_DESCRIPTIONS,
    REASON_CODE_DESCRIPTIONS,
    ANALYSIS_EXPLANATIONS
)

# Re-export variance_analysis components for backward compatibility
from variance_analysis import (
    VarianceAnalysisPipeline,
    generate_demo_data,
    VarianceCalculator,
    ReasonCodeEngine,
    VarianceDecomposer,
    ConfigLoader,
    VarianceStatus,
    SeverityFlag,
    VarianceCategory
)

__all__ = [
    # Version
    "__version__",
    
    # Authentication
    "Authenticator",
    
    # Data
    "DataLoader",
    
    # Analysis
    "AnalysisEngine",
    
    # Visualization
    "VisualizationHelper",
    "get_category_color",
    "create_gauge_chart",
    
    # Descriptions
    "get_reason_code_description",
    "VARIANCE_CATEGORY_DESCRIPTIONS",
    "ATTRIBUTE_DESCRIPTIONS",
    "REASON_CODE_DESCRIPTIONS",
    "ANALYSIS_EXPLANATIONS",
    
    # Variance Analysis (from variance_analysis.py)
    "VarianceAnalysisPipeline",
    "generate_demo_data",
    "VarianceCalculator",
    "ReasonCodeEngine",
    "VarianceDecomposer",
    "ConfigLoader",
    "VarianceStatus",
    "SeverityFlag",
    "VarianceCategory",
]
