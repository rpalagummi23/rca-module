"""
Agricultural Field Inspection Variance Analysis System
======================================================

Complete standalone implementation for variance analysis and root cause analysis
between field inspection actuals and recommended (master) values.

Author: Data Architecture Team
"""

import os
import json
import yaml
import logging
from datetime import datetime, date
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum

import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================

class VarianceStatus(Enum):
    ON_TARGET = "ON_TARGET"
    EARLY = "EARLY"
    LATE = "LATE"
    ABOVE = "ABOVE"
    BELOW = "BELOW"
    MISSING_ACTUAL = "MISSING_ACTUAL"
    MISSING_RECOMMENDATION = "MISSING_RECOMMENDATION"


class SeverityFlag(Enum):
    OK = "OK"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class VarianceCategory(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class ToleranceConfig:
    attribute_code: str
    tolerance_type: str
    tolerance_value: Optional[float] = None
    tolerance_pct: Optional[float] = None
    lower_threshold: Optional[float] = None
    upper_threshold: Optional[float] = None


@dataclass
class WeightConfig:
    attribute_code: str
    weight_value: float


# =============================================================================
# CONFIGURATION LOADER
# =============================================================================

class ConfigLoader:
    """Load configuration from database or files"""
    
    def __init__(self):
        self.tolerances: Dict[str, ToleranceConfig] = {}
        self.weights: Dict[str, WeightConfig] = {}
        self.reason_rules: List[Dict] = []
        
    def load_from_database(self, engine) -> None:
        """Load configuration from database tables"""
        # Load tolerances
        tol_query = """
            SELECT ma.attribute_code, mt.tolerance_type, mt.tolerance_value,
                   mt.tolerance_pct, mt.lower_threshold, mt.upper_threshold
            FROM meta_tolerance mt
            JOIN meta_attribute ma ON mt.attribute_id = ma.attribute_id
            WHERE CURRENT_DATE BETWEEN mt.effective_from AND mt.effective_to
        """
        df_tol = pd.read_sql(tol_query, engine)
        for _, row in df_tol.iterrows():
            self.tolerances[row['attribute_code']] = ToleranceConfig(
                attribute_code=row['attribute_code'],
                tolerance_type=row['tolerance_type'],
                tolerance_value=row['tolerance_value'],
                tolerance_pct=row['tolerance_pct'],
                lower_threshold=row['lower_threshold'],
                upper_threshold=row['upper_threshold']
            )
        
        # Load weights
        wt_query = """
            SELECT ma.attribute_code, mw.weight_value
            FROM meta_variance_weight mw
            JOIN meta_attribute ma ON mw.attribute_id = ma.attribute_id
            WHERE CURRENT_DATE BETWEEN mw.effective_from AND mw.effective_to
        """
        df_wt = pd.read_sql(wt_query, engine)
        for _, row in df_wt.iterrows():
            self.weights[row['attribute_code']] = WeightConfig(
                attribute_code=row['attribute_code'],
                weight_value=float(row['weight_value'])
            )
        
        # Load default reason rules
        self._load_default_rules()
        logger.info(f"Loaded {len(self.tolerances)} tolerances and {len(self.weights)} weights")
    
    def _load_default_rules(self):
        """Load default reason code rules"""
        self.reason_rules = [
            {'rule_id': 'R001', 'reason_code': 'data_quality_issue', 'priority': 1,
             'conditions': [{'attribute': 'ANY', 'operator': 'OUT_OF_RANGE'}]},
            {'rule_id': 'R002', 'reason_code': 'missing_data', 'priority': 2,
             'conditions': [{'attribute': 'ANY', 'operator': 'MISSING_ACTUAL'}]},
            {'rule_id': 'R010', 'reason_code': 'upstream_timing_slip', 'priority': 10,
             'conditions': [{'attribute': 'SOWING_DATE', 'operator': 'LATE', 'min_days': 3},
                          {'attribute': 'SOAKING_DATE', 'operator': 'LATE', 'min_days': 2}]},
            {'rule_id': 'R011', 'reason_code': 'transplant_delay', 'priority': 11,
             'conditions': [{'attribute': 'TRANSPLANT_DATE', 'operator': 'LATE', 'min_days': 7}]},
            {'rule_id': 'R020', 'reason_code': 'pest_pressure', 'priority': 20,
             'conditions': [{'attribute': 'PEST_SEVERITY', 'operator': 'ABOVE_MAX'},
                          {'attribute': 'HEALTH_SCORE', 'operator': 'BELOW_TARGET'}]},
            {'rule_id': 'R021', 'reason_code': 'disease_outbreak', 'priority': 21,
             'conditions': [{'attribute': 'DISEASE_SEVERITY', 'operator': 'ABOVE_MAX'},
                          {'attribute': 'HEALTH_SCORE', 'operator': 'BELOW_TARGET'}]},
            {'rule_id': 'R030', 'reason_code': 'establishment_issue', 'priority': 30,
             'conditions': [{'attribute': 'PLANT_RATIO', 'operator': 'BELOW_MIN'},
                          {'attribute': 'TRANSPLANT_DATE', 'operator': 'LATE', 'min_days': 5}]},
            {'rule_id': 'R031', 'reason_code': 'poor_germination', 'priority': 31,
             'conditions': [{'attribute': 'PLANT_RATIO', 'operator': 'BELOW_MIN'}]},
            {'rule_id': 'R040', 'reason_code': 'low_tillering', 'priority': 40,
             'conditions': [{'attribute': 'TILLER_COUNT', 'operator': 'BELOW_MIN'}]},
            {'rule_id': 'R050', 'reason_code': 'early_planting', 'priority': 50,
             'conditions': [{'attribute': 'SOWING_DATE', 'operator': 'EARLY', 'min_days': 7}]},
        ]
    
    def load_defaults(self):
        """Load default configuration without database"""
        self.tolerances = {
            'SOAKING_DATE': ToleranceConfig('SOAKING_DATE', 'ABSOLUTE', 3),
            'SOWING_DATE': ToleranceConfig('SOWING_DATE', 'ABSOLUTE', 5),
            'TRANSPLANT_DATE': ToleranceConfig('TRANSPLANT_DATE', 'ABSOLUTE', 7),
            'FLOWERING_DATE': ToleranceConfig('FLOWERING_DATE', 'ABSOLUTE', 5),
            'PEST_SEVERITY': ToleranceConfig('PEST_SEVERITY', 'RANGE', None, None, 0, 3),
            'TILLER_COUNT': ToleranceConfig('TILLER_COUNT', 'PERCENTAGE', None, 15),
            'HEALTH_SCORE': ToleranceConfig('HEALTH_SCORE', 'ABSOLUTE', 1),
            'PLANT_RATIO': ToleranceConfig('PLANT_RATIO', 'PERCENTAGE', None, 10),
            'DISEASE_SEVERITY': ToleranceConfig('DISEASE_SEVERITY', 'RANGE', None, None, 0, 3)
        }
        self.weights = {
            'SOAKING_DATE': WeightConfig('SOAKING_DATE', 0.10),
            'SOWING_DATE': WeightConfig('SOWING_DATE', 0.15),
            'TRANSPLANT_DATE': WeightConfig('TRANSPLANT_DATE', 0.12),
            'FLOWERING_DATE': WeightConfig('FLOWERING_DATE', 0.08),
            'PEST_SEVERITY': WeightConfig('PEST_SEVERITY', 0.15),
            'TILLER_COUNT': WeightConfig('TILLER_COUNT', 0.12),
            'HEALTH_SCORE': WeightConfig('HEALTH_SCORE', 0.13),
            'PLANT_RATIO': WeightConfig('PLANT_RATIO', 0.10),
            'DISEASE_SEVERITY': WeightConfig('DISEASE_SEVERITY', 0.05)
        }
        self._load_default_rules()


# =============================================================================
# DATA ACCESS LAYER
# =============================================================================

class DataAccessLayer:
    """Database access for loading and writing data"""
    
    def __init__(self, connection_string: str):
        self.engine = create_engine(connection_string)
        
    def load_inspections(self, **filters) -> pd.DataFrame:
        """Load inspection data with dimension joins"""
        query = """
            SELECT 
                i.inspection_id, i.inspection_event_id, i.inspection_date, i.inspection_type,
                i.crop_id, i.variety_id, i.season_id, i.farm_id, i.field_id, i.plot_id,
                c.crop_code, c.crop_name,
                v.variety_code, v.variety_name, v.variety_type,
                s.season_code, s.season_start_date,
                l.location_id, l.location_code, l.agro_climatic_zone, l.district_name, l.state_name,
                f.farm_code, f.farmer_name,
                i.actual_soaking_date, i.actual_sowing_date, i.actual_transplant_date, i.actual_flowering_date,
                i.actual_pest_severity, i.actual_tiller_count, i.actual_health_score, 
                i.actual_plant_ratio, i.actual_disease_severity, i.notes
            FROM inspection i
            JOIN crop c ON i.crop_id = c.crop_id
            JOIN variety v ON i.variety_id = v.variety_id
            JOIN season s ON i.season_id = s.season_id
            JOIN farm f ON i.farm_id = f.farm_id
            JOIN location l ON f.location_id = l.location_id
            WHERE 1=1
        """
        params = {}
        if filters.get('crop_id'):
            query += " AND i.crop_id = :crop_id"
            params['crop_id'] = filters['crop_id']
        if filters.get('season_id'):
            query += " AND i.season_id = :season_id"
            params['season_id'] = filters['season_id']
        if filters.get('variety_id'):
            query += " AND i.variety_id = :variety_id"
            params['variety_id'] = filters['variety_id']
        
        query += " ORDER BY i.inspection_date"
        return pd.read_sql(text(query), self.engine, params=params)
    
    def load_recommendations(self, crop_ids=None, variety_ids=None, season_ids=None) -> pd.DataFrame:
        """Load master recommendations"""
        query = """
            SELECT * FROM master_recommendation
            WHERE is_current = TRUE
              AND CURRENT_DATE BETWEEN effective_start AND effective_end
        """
        params = {}
        if crop_ids:
            query += " AND crop_id = ANY(:crop_ids)"
            params['crop_ids'] = crop_ids
        if variety_ids:
            query += " AND variety_id = ANY(:variety_ids)"
            params['variety_ids'] = variety_ids
        if season_ids:
            query += " AND season_id = ANY(:season_ids)"
            params['season_ids'] = season_ids
        
        return pd.read_sql(text(query), self.engine, params=params)
    
    def load_attributes(self) -> pd.DataFrame:
        """Load attribute metadata"""
        return pd.read_sql("SELECT * FROM meta_attribute WHERE is_active = TRUE", self.engine)
    
    def write_variance_results(self, df_variance: pd.DataFrame, df_summary: pd.DataFrame) -> None:
        """Write variance results to database"""
        with self.engine.begin() as conn:
            # Clear existing results for these inspections
            inspection_ids = df_variance['inspection_id'].unique().tolist()
            if inspection_ids:
                conn.execute(text("DELETE FROM fact_variance WHERE inspection_id = ANY(:ids)"), {'ids': inspection_ids})
                conn.execute(text("DELETE FROM fact_inspection_variance_summary WHERE inspection_id = ANY(:ids)"), {'ids': inspection_ids})
            
            # Write variance detail
            df_variance.to_sql('fact_variance', conn, if_exists='append', index=False)
            
            # Write summary
            df_summary.to_sql('fact_inspection_variance_summary', conn, if_exists='append', index=False)
        
        logger.info(f"Written {len(df_variance)} variance records and {len(df_summary)} summaries")
    
    def get_summary_stats(self) -> Dict:
        """Get summary statistics for dashboard"""
        stats = {}
        
        # Total inspections
        stats['total_inspections'] = pd.read_sql(
            "SELECT COUNT(*) as cnt FROM inspection", self.engine
        ).iloc[0]['cnt']
        
        # Analyzed inspections
        stats['analyzed_inspections'] = pd.read_sql(
            "SELECT COUNT(*) as cnt FROM fact_inspection_variance_summary", self.engine
        ).iloc[0]['cnt']
        
        # Category distribution
        stats['category_distribution'] = pd.read_sql("""
            SELECT variance_category, COUNT(*) as count
            FROM fact_inspection_variance_summary
            GROUP BY variance_category
            ORDER BY variance_category
        """, self.engine).to_dict('records')
        
        # Reason code distribution
        stats['reason_codes'] = pd.read_sql("""
            SELECT primary_reason_code, COUNT(*) as count
            FROM fact_inspection_variance_summary
            WHERE primary_reason_code IS NOT NULL
            GROUP BY primary_reason_code
            ORDER BY count DESC
        """, self.engine).to_dict('records')
        
        # Average score by crop
        stats['score_by_crop'] = pd.read_sql("""
            SELECT c.crop_name, AVG(fvs.overall_variance_score) as avg_score
            FROM fact_inspection_variance_summary fvs
            JOIN inspection i ON fvs.inspection_id = i.inspection_id
            JOIN crop c ON i.crop_id = c.crop_id
            GROUP BY c.crop_name
        """, self.engine).to_dict('records')
        
        return stats


# =============================================================================
# VARIANCE CALCULATOR
# =============================================================================

class VarianceCalculator:
    """Calculate variances between actuals and recommendations"""
    
    ATTRIBUTE_MAPPING = {
        'SOAKING_DATE': {'actual': 'actual_soaking_date', 'rec': 'rec_soaking_date', 'type': 'Date'},
        'SOWING_DATE': {'actual': 'actual_sowing_date', 'rec': 'rec_sowing_date', 'type': 'Date'},
        'TRANSPLANT_DATE': {'actual': 'actual_transplant_date', 'rec': 'rec_transplant_date', 'type': 'Date'},
        'FLOWERING_DATE': {'actual': 'actual_flowering_date', 'rec': 'rec_flowering_date', 'type': 'Date'},
        'PEST_SEVERITY': {'actual': 'actual_pest_severity', 'rec_target': 'rec_pest_severity_target', 
                         'rec_max': 'rec_pest_severity_max', 'type': 'Numeric', 'higher_better': False},
        'TILLER_COUNT': {'actual': 'actual_tiller_count', 'rec_target': 'rec_tiller_count_target',
                        'rec_min': 'rec_tiller_count_min', 'rec_max': 'rec_tiller_count_max',
                        'stddev': 'tiller_count_stddev', 'type': 'Numeric', 'higher_better': True},
        'HEALTH_SCORE': {'actual': 'actual_health_score', 'rec_target': 'rec_health_score_target',
                        'rec_min': 'rec_health_score_min', 'type': 'Numeric', 'higher_better': True},
        'PLANT_RATIO': {'actual': 'actual_plant_ratio', 'rec_target': 'rec_plant_ratio_target',
                       'rec_min': 'rec_plant_ratio_min', 'stddev': 'plant_ratio_stddev',
                       'type': 'Numeric', 'higher_better': True},
        'DISEASE_SEVERITY': {'actual': 'actual_disease_severity', 'rec_target': 'rec_disease_severity_target',
                            'rec_max': 'rec_disease_severity_max', 'type': 'Numeric', 'higher_better': False}
    }
    
    ATTR_ID_MAP = {
        'SOAKING_DATE': 1, 'SOWING_DATE': 2, 'TRANSPLANT_DATE': 3, 'FLOWERING_DATE': 4,
        'PEST_SEVERITY': 5, 'TILLER_COUNT': 6, 'HEALTH_SCORE': 7, 'PLANT_RATIO': 8, 'DISEASE_SEVERITY': 9
    }
    
    def __init__(self, config: ConfigLoader):
        self.config = config
        
    def merge_with_recommendations(self, df_insp: pd.DataFrame, df_rec: pd.DataFrame) -> pd.DataFrame:
        """Merge inspections with their recommendations"""
        df = df_insp.merge(
            df_rec,
            on=['crop_id', 'variety_id', 'season_id'],
            how='left',
            suffixes=('', '_rec')
        )
        
        # Compute dates from offsets if needed
        df = self._compute_rec_dates(df)
        
        logger.info(f"Merged {len(df)} inspection records with recommendations")
        return df
    
    def _compute_rec_dates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Compute absolute dates from offsets"""
        df = df.copy()
        
        # Soaking date
        if 'rec_soaking_date' in df.columns and 'rec_soaking_offset' in df.columns:
            mask = df['rec_soaking_date'].isna() & df['rec_soaking_offset'].notna()
            if mask.any() and 'season_start_date' in df.columns:
                df.loc[mask, 'rec_soaking_date'] = pd.to_datetime(df.loc[mask, 'season_start_date']) + \
                    pd.to_timedelta(df.loc[mask, 'rec_soaking_offset'], unit='D')
        
        # Sowing date
        if 'rec_sowing_date' in df.columns and 'rec_sowing_offset' in df.columns:
            mask = df['rec_sowing_date'].isna() & df['rec_sowing_offset'].notna()
            if mask.any() and 'rec_soaking_date' in df.columns:
                df.loc[mask, 'rec_sowing_date'] = pd.to_datetime(df.loc[mask, 'rec_soaking_date']) + \
                    pd.to_timedelta(df.loc[mask, 'rec_sowing_offset'], unit='D')
        
        # Transplant date
        if 'rec_transplant_date' in df.columns and 'rec_transplant_offset' in df.columns:
            mask = df['rec_transplant_date'].isna() & df['rec_transplant_offset'].notna()
            if mask.any() and 'rec_sowing_date' in df.columns:
                df.loc[mask, 'rec_transplant_date'] = pd.to_datetime(df.loc[mask, 'rec_sowing_date']) + \
                    pd.to_timedelta(df.loc[mask, 'rec_transplant_offset'], unit='D')
        
        return df
    
    def compute_variances(self, df_merged: pd.DataFrame) -> pd.DataFrame:
        """Compute variance for each inspection and attribute"""
        records = []
        
        for _, row in df_merged.iterrows():
            for attr_code, attr_cfg in self.ATTRIBUTE_MAPPING.items():
                rec = self._compute_single_variance(row, attr_code, attr_cfg)
                rec['inspection_id'] = row['inspection_id']
                rec['attribute_id'] = self.ATTR_ID_MAP[attr_code]
                rec['attribute_code'] = attr_code
                rec['recommendation_id'] = row.get('recommendation_id')
                records.append(rec)
        
        df = pd.DataFrame(records)
        logger.info(f"Computed {len(df)} variance records")
        return df
    
    def _compute_single_variance(self, row, attr_code: str, cfg: Dict) -> Dict:
        """Compute variance for a single attribute"""
        result = {
            'actual_value_date': None, 'actual_value_numeric': None,
            'recommended_value_date': None, 'recommended_value_numeric': None,
            'variance_days': None, 'variance_numeric': None, 'variance_pct': None, 'z_score': None,
            'variance_status': None, 'within_tolerance': True, 'severity_flag': 'OK',
            'is_actual_missing': False, 'is_recommended_missing': False,
            'standardized_variance': 0.0, 'weight_applied': 0.0, 'weighted_contribution': 0.0
        }
        
        # Get weight
        weight = self.config.weights.get(attr_code)
        result['weight_applied'] = weight.weight_value if weight else 0.1
        
        # Get tolerance
        tolerance = self.config.tolerances.get(attr_code)
        
        if cfg['type'] == 'Date':
            return self._compute_date_variance(row, attr_code, cfg, tolerance, result)
        else:
            return self._compute_numeric_variance(row, attr_code, cfg, tolerance, result)
    
    def _compute_date_variance(self, row, attr_code, cfg, tolerance, result) -> Dict:
        """Compute date variance"""
        actual = row.get(cfg['actual'])
        rec = row.get(cfg['rec'])
        
        result['actual_value_date'] = actual
        result['recommended_value_date'] = rec
        
        if pd.isna(actual):
            result['is_actual_missing'] = True
            result['variance_status'] = 'MISSING_ACTUAL'
            result['within_tolerance'] = False
            result['severity_flag'] = 'WARNING'
            result['standardized_variance'] = 1.0
            result['weighted_contribution'] = result['weight_applied']
            return result
        
        if pd.isna(rec):
            result['is_recommended_missing'] = True
            result['variance_status'] = 'MISSING_RECOMMENDATION'
            return result
        
        # Convert to date
        if hasattr(actual, 'date'):
            actual = actual.date() if callable(getattr(actual, 'date', None)) else actual
        if hasattr(rec, 'date'):
            rec = rec.date() if callable(getattr(rec, 'date', None)) else rec
        
        try:
            actual_dt = pd.to_datetime(actual)
            rec_dt = pd.to_datetime(rec)
            variance_days = (actual_dt - rec_dt).days
            result['variance_days'] = int(variance_days)
            
            tol_value = tolerance.tolerance_value if tolerance else 5
            
            if abs(variance_days) <= tol_value:
                result['variance_status'] = 'ON_TARGET'
                result['within_tolerance'] = True
            elif variance_days < 0:
                result['variance_status'] = 'EARLY'
                result['within_tolerance'] = False
            else:
                result['variance_status'] = 'LATE'
                result['within_tolerance'] = False
            
            # Severity
            if not result['within_tolerance']:
                ratio = abs(variance_days) / max(tol_value, 1)
                result['severity_flag'] = 'CRITICAL' if ratio > 3 else ('WARNING' if ratio > 2 else 'OK')
            
            # Standardize (0-1, using 30 days as max)
            result['standardized_variance'] = min(abs(variance_days) / 30, 1.0)
            result['weighted_contribution'] = result['weight_applied'] * result['standardized_variance']
            
        except Exception as e:
            logger.warning(f"Error computing date variance for {attr_code}: {e}")
        
        return result
    
    def _compute_numeric_variance(self, row, attr_code, cfg, tolerance, result) -> Dict:
        """Compute numeric variance"""
        actual = row.get(cfg['actual'])
        rec_target = row.get(cfg.get('rec_target', ''))
        rec_min = row.get(cfg.get('rec_min', ''))
        rec_max = row.get(cfg.get('rec_max', ''))
        stddev = row.get(cfg.get('stddev', ''))
        higher_better = cfg.get('higher_better', True)
        
        result['actual_value_numeric'] = float(actual) if pd.notna(actual) else None
        result['recommended_value_numeric'] = float(rec_target) if pd.notna(rec_target) else None
        
        if pd.isna(actual):
            result['is_actual_missing'] = True
            result['variance_status'] = 'MISSING_ACTUAL'
            result['within_tolerance'] = False
            result['severity_flag'] = 'WARNING'
            result['standardized_variance'] = 1.0
            result['weighted_contribution'] = result['weight_applied']
            return result
        
        if pd.isna(rec_target) and pd.isna(rec_min) and pd.isna(rec_max):
            result['is_recommended_missing'] = True
            result['variance_status'] = 'MISSING_RECOMMENDATION'
            return result
        
        actual = float(actual)
        
        # Compute variance
        if pd.notna(rec_target):
            rec_target = float(rec_target)
            result['variance_numeric'] = actual - rec_target
            if rec_target != 0:
                result['variance_pct'] = (result['variance_numeric'] / rec_target) * 100
        
        # Z-score
        if pd.notna(stddev) and float(stddev) > 0 and result['variance_numeric'] is not None:
            result['z_score'] = result['variance_numeric'] / float(stddev)
        
        # Tolerance check
        within_tol = True
        if tolerance:
            if tolerance.tolerance_type == 'PERCENTAGE' and tolerance.tolerance_pct:
                if result['variance_pct'] is not None:
                    within_tol = abs(result['variance_pct']) <= tolerance.tolerance_pct
            elif tolerance.tolerance_type == 'ABSOLUTE' and tolerance.tolerance_value:
                if result['variance_numeric'] is not None:
                    within_tol = abs(result['variance_numeric']) <= tolerance.tolerance_value
            elif tolerance.tolerance_type == 'RANGE':
                if pd.notna(rec_min) and actual < float(rec_min):
                    within_tol = False
                if pd.notna(rec_max) and actual > float(rec_max):
                    within_tol = False
                if tolerance.lower_threshold is not None and actual < tolerance.lower_threshold:
                    within_tol = False
                if tolerance.upper_threshold is not None and actual > tolerance.upper_threshold:
                    within_tol = False
        
        result['within_tolerance'] = within_tol
        
        # Status
        if within_tol:
            result['variance_status'] = 'ON_TARGET'
        elif higher_better:
            result['variance_status'] = 'BELOW' if (result['variance_numeric'] or 0) < 0 else 'ABOVE'
        else:
            result['variance_status'] = 'ABOVE' if (result['variance_numeric'] or 0) > 0 else 'BELOW'
        
        # Severity
        if not within_tol:
            if result['z_score'] is not None:
                result['severity_flag'] = 'CRITICAL' if abs(result['z_score']) > 3 else \
                    ('WARNING' if abs(result['z_score']) > 2 else 'OK')
            elif result['variance_pct'] is not None:
                tol_pct = (tolerance.tolerance_pct if tolerance and tolerance.tolerance_pct else 10) or 10
                result['severity_flag'] = 'CRITICAL' if abs(result['variance_pct']) > tol_pct * 3 else \
                    ('WARNING' if abs(result['variance_pct']) > tol_pct * 2 else 'OK')
        
        # Standardize
        if result['z_score'] is not None:
            result['standardized_variance'] = min(abs(result['z_score']) / 3, 1.0)
        elif result['variance_pct'] is not None:
            result['standardized_variance'] = min(abs(result['variance_pct']) / 100, 1.0)
        
        result['weighted_contribution'] = result['weight_applied'] * result['standardized_variance']
        
        return result


# =============================================================================
# REASON CODE ENGINE
# =============================================================================

class ReasonCodeEngine:
    """Rule-based engine for assigning reason codes"""
    
    def __init__(self, config: ConfigLoader):
        self.rules = sorted(config.reason_rules, key=lambda x: x['priority'])
    
    def assign_reason_codes(self, df_variance: pd.DataFrame) -> pd.DataFrame:
        """Assign reason codes to each inspection"""
        results = []
        
        for inspection_id, group in df_variance.groupby('inspection_id'):
            var_dict = self._build_variance_dict(group)
            codes = self._evaluate_rules(var_dict)
            
            results.append({
                'inspection_id': inspection_id,
                'reason_codes': codes,
                'primary_reason_code': codes[0] if codes else None
            })
        
        return pd.DataFrame(results)
    
    def _build_variance_dict(self, group: pd.DataFrame) -> Dict:
        """Build variance dictionary for rule evaluation"""
        d = {}
        for _, row in group.iterrows():
            d[row['attribute_code']] = {
                'variance_days': row.get('variance_days'),
                'variance_numeric': row.get('variance_numeric'),
                'variance_status': row.get('variance_status'),
                'within_tolerance': row.get('within_tolerance'),
                'is_actual_missing': row.get('is_actual_missing'),
                'z_score': row.get('z_score')
            }
        return d
    
    def _evaluate_rules(self, var_dict: Dict) -> List[str]:
        """Evaluate all rules"""
        matched = []
        for rule in self.rules:
            if self._evaluate_rule(rule, var_dict):
                matched.append(rule['reason_code'])
        return matched
    
    def _evaluate_rule(self, rule: Dict, var_dict: Dict) -> bool:
        """Evaluate a single rule"""
        for cond in rule['conditions']:
            if not self._check_condition(cond, var_dict):
                return False
        return True
    
    def _check_condition(self, cond: Dict, var_dict: Dict) -> bool:
        """Check a single condition"""
        attr = cond['attribute']
        op = cond['operator']
        
        if attr == 'ANY':
            for data in var_dict.values():
                if self._check_operator(op, data, cond):
                    return True
            return False
        
        if attr not in var_dict:
            return False
        
        return self._check_operator(op, var_dict[attr], cond)
    
    def _check_operator(self, op: str, data: Dict, cond: Dict) -> bool:
        """Check operator condition"""
        if op == 'LATE':
            min_days = cond.get('min_days', 0)
            return (data.get('variance_days') or 0) >= min_days
        elif op == 'EARLY':
            min_days = cond.get('min_days', 0)
            return (data.get('variance_days') or 0) <= -min_days
        elif op == 'ABOVE_MAX':
            return data.get('variance_status') == 'ABOVE' and not data.get('within_tolerance')
        elif op == 'BELOW_MIN':
            return data.get('variance_status') == 'BELOW' and not data.get('within_tolerance')
        elif op == 'BELOW_TARGET':
            return (data.get('variance_numeric') or 0) < 0
        elif op == 'OUT_OF_RANGE':
            return data.get('z_score') is not None and abs(data.get('z_score')) > 4
        elif op == 'MISSING_ACTUAL':
            return data.get('is_actual_missing', False)
        return False


# =============================================================================
# VARIANCE DECOMPOSER
# =============================================================================

class VarianceDecomposer:
    """Compute variance decomposition and summaries"""
    
    def compute_summaries(self, df_variance: pd.DataFrame, df_reason: pd.DataFrame) -> pd.DataFrame:
        """Compute inspection-level summaries"""
        summaries = []
        
        for inspection_id, group in df_variance.groupby('inspection_id'):
            score = group['weighted_contribution'].sum()
            
            if score <= 0.2:
                category = 'LOW'
            elif score <= 0.4:
                category = 'MEDIUM'
            elif score <= 0.6:
                category = 'HIGH'
            else:
                category = 'CRITICAL'
            
            top_drivers = group.nlargest(3, 'weighted_contribution')[
                ['attribute_code', 'weighted_contribution', 'variance_status']
            ].to_dict('records')
            
            reason_row = df_reason[df_reason['inspection_id'] == inspection_id]
            reason_codes = reason_row['reason_codes'].iloc[0] if len(reason_row) > 0 else []
            primary_reason = reason_row['primary_reason_code'].iloc[0] if len(reason_row) > 0 else None
            
            summaries.append({
                'inspection_id': inspection_id,
                'overall_variance_score': round(score, 4),
                'variance_category': category,
                'attributes_evaluated': len(group[~group['is_actual_missing'] & ~group['is_recommended_missing']]),
                'attributes_within_tolerance': len(group[group['within_tolerance'] == True]),
                'attributes_missing_actual': len(group[group['is_actual_missing'] == True]),
                'attributes_missing_rec': len(group[group['is_recommended_missing'] == True]),
                'top_variance_drivers': json.dumps(top_drivers),
                'reason_codes': reason_codes,
                'primary_reason_code': primary_reason
            })
        
        return pd.DataFrame(summaries)
    
    def compute_attribute_contributions(self, df_variance: pd.DataFrame) -> pd.DataFrame:
        """Compute attribute-level contributions"""
        agg = df_variance.groupby('attribute_code').agg({
            'weighted_contribution': ['sum', 'mean', 'count'],
            'within_tolerance': lambda x: (x == True).sum() / len(x) * 100,
            'standardized_variance': 'mean'
        }).round(4)
        
        agg.columns = ['total_contribution', 'avg_contribution', 'count', 'pct_within_tolerance', 'avg_std_variance']
        total = agg['total_contribution'].sum()
        agg['pct_of_total'] = (agg['total_contribution'] / total * 100).round(2) if total > 0 else 0
        
        return agg.reset_index().sort_values('pct_of_total', ascending=False)
    
    def compute_cvs_aggregation(self, df_insp: pd.DataFrame, df_summary: pd.DataFrame) -> pd.DataFrame:
        """Aggregate by crop-variety-season"""
        merged = df_insp[['inspection_id', 'crop_id', 'variety_id', 'season_id', 'crop_name', 
                         'variety_name', 'season_code']].merge(df_summary, on='inspection_id')
        
        agg = merged.groupby(['crop_id', 'variety_id', 'season_id', 'crop_name', 'variety_name', 'season_code']).agg({
            'inspection_id': 'count',
            'overall_variance_score': ['mean', 'max'],
            'attributes_within_tolerance': 'mean'
        }).round(4)
        
        agg.columns = ['inspection_count', 'avg_score', 'max_score', 'avg_attrs_ok']
        return agg.reset_index()
    
    def compute_location_aggregation(self, df_insp: pd.DataFrame, df_summary: pd.DataFrame) -> pd.DataFrame:
        """Aggregate by location"""
        merged = df_insp[['inspection_id', 'location_id', 'location_code', 'district_name', 
                         'agro_climatic_zone']].merge(df_summary, on='inspection_id')
        
        agg = merged.groupby(['location_id', 'location_code', 'district_name', 'agro_climatic_zone']).agg({
            'inspection_id': 'count',
            'overall_variance_score': 'mean',
            'attributes_within_tolerance': 'mean'
        }).round(4)
        
        agg.columns = ['inspection_count', 'avg_score', 'avg_attrs_ok']
        return agg.reset_index()
    
    def get_reason_code_distribution(self, df_summary: pd.DataFrame) -> pd.DataFrame:
        """Get reason code distribution"""
        all_codes = []
        for codes in df_summary['reason_codes']:
            if isinstance(codes, list):
                all_codes.extend(codes)
        
        if not all_codes:
            return pd.DataFrame(columns=['reason_code', 'count', 'pct'])
        
        counts = pd.Series(all_codes).value_counts()
        total = len(df_summary)
        
        return pd.DataFrame({
            'reason_code': counts.index,
            'count': counts.values,
            'pct': (counts.values / total * 100).round(2)
        })


# =============================================================================
# MAIN PIPELINE
# =============================================================================

class VarianceAnalysisPipeline:
    """Main orchestration pipeline"""
    
    def __init__(self, connection_string: Optional[str] = None):
        self.connection_string = connection_string
        self.config = ConfigLoader()
        self.dal = None
        self.calculator = None
        self.reason_engine = None
        self.decomposer = None
        
        # Results
        self.df_inspections = None
        self.df_recommendations = None
        self.df_merged = None
        self.df_variance = None
        self.df_reason_codes = None
        self.df_summaries = None
        
    def initialize(self, use_db: bool = True) -> None:
        """Initialize pipeline"""
        if use_db and self.connection_string:
            self.dal = DataAccessLayer(self.connection_string)
            self.config.load_from_database(self.dal.engine)
        else:
            self.config.load_defaults()
        
        self.calculator = VarianceCalculator(self.config)
        self.reason_engine = ReasonCodeEngine(self.config)
        self.decomposer = VarianceDecomposer()
        
        logger.info("Pipeline initialized")
    
    def load_data(self, **filters) -> None:
        """Load inspection and recommendation data"""
        if self.dal is None:
            raise ValueError("Database not connected")
        
        self.df_inspections = self.dal.load_inspections(**filters)
        
        crop_ids = self.df_inspections['crop_id'].unique().tolist()
        variety_ids = self.df_inspections['variety_id'].unique().tolist()
        season_ids = self.df_inspections['season_id'].unique().tolist()
        
        self.df_recommendations = self.dal.load_recommendations(crop_ids, variety_ids, season_ids)
        
        logger.info(f"Loaded {len(self.df_inspections)} inspections and {len(self.df_recommendations)} recommendations")
    
    def run_analysis(self) -> Dict[str, pd.DataFrame]:
        """Run full variance analysis"""
        if self.df_inspections is None:
            raise ValueError("No data loaded")
        
        logger.info("Step 1: Merging with recommendations...")
        self.df_merged = self.calculator.merge_with_recommendations(
            self.df_inspections, self.df_recommendations
        )
        
        logger.info("Step 2: Computing variances...")
        self.df_variance = self.calculator.compute_variances(self.df_merged)
        
        logger.info("Step 3: Assigning reason codes...")
        self.df_reason_codes = self.reason_engine.assign_reason_codes(self.df_variance)
        
        logger.info("Step 4: Computing summaries...")
        self.df_summaries = self.decomposer.compute_summaries(self.df_variance, self.df_reason_codes)
        
        logger.info("Step 5: Computing aggregations...")
        df_attr_contrib = self.decomposer.compute_attribute_contributions(self.df_variance)
        df_cvs_agg = self.decomposer.compute_cvs_aggregation(self.df_merged, self.df_summaries)
        df_loc_agg = self.decomposer.compute_location_aggregation(self.df_merged, self.df_summaries)
        df_reason_dist = self.decomposer.get_reason_code_distribution(self.df_summaries)
        
        logger.info("Analysis complete!")
        
        return {
            'variance_detail': self.df_variance,
            'inspection_summaries': self.df_summaries,
            'attribute_contributions': df_attr_contrib,
            'cvs_aggregation': df_cvs_agg,
            'location_aggregation': df_loc_agg,
            'reason_code_distribution': df_reason_dist,
            'merged_data': self.df_merged
        }
    
    def write_results(self) -> None:
        """Write results to database"""
        if self.dal and self.df_variance is not None and self.df_summaries is not None:
            self.dal.write_variance_results(self.df_variance, self.df_summaries)


# =============================================================================
# DEMO FUNCTIONS
# =============================================================================

def generate_demo_data():
    """Generate demo data without database"""
    np.random.seed(42)
    n = 50
    base_date = date(2024, 6, 1)
    
    inspections = []
    for i in range(n):
        soak_off = np.random.randint(-5, 10)
        sow_off = soak_off + np.random.randint(5, 12)
        trans_off = sow_off + np.random.randint(18, 25)
        
        inspections.append({
            'inspection_id': i + 1,
            'inspection_event_id': f'INS-{i+1:04d}',
            'inspection_date': base_date + pd.Timedelta(days=np.random.randint(30, 90)),
            'crop_id': np.random.choice([1, 3]),
            'variety_id': np.random.choice([1, 2, 3, 4, 7, 8]),
            'season_id': 1,
            'crop_name': np.random.choice(['Rice (Paddy)', 'Maize (Corn)']),
            'variety_name': np.random.choice(['Arize 6444 Gold', 'PHB 71', 'Swarna', 'Pioneer 30V92']),
            'season_code': 'KHARIF_2024',
            'season_start_date': base_date,
            'location_id': np.random.randint(9, 14),
            'location_code': f'ZN-{np.random.randint(1,5)}',
            'district_name': np.random.choice(['Guntur', 'Krishna', 'Warangal', 'Karimnagar']),
            'agro_climatic_zone': np.random.choice(['Krishna-Godavari Zone', 'Northern Telangana Zone']),
            'actual_soaking_date': base_date + pd.Timedelta(days=soak_off),
            'actual_sowing_date': base_date + pd.Timedelta(days=sow_off),
            'actual_transplant_date': base_date + pd.Timedelta(days=trans_off),
            'actual_flowering_date': base_date + pd.Timedelta(days=trans_off + np.random.randint(30, 40)),
            'actual_pest_severity': np.random.choice([0,1,2,3,4,5,6,7], p=[.25,.25,.2,.12,.08,.05,.03,.02]),
            'actual_tiller_count': np.random.randint(8, 20),
            'actual_health_score': np.random.choice([1,2,3,4,5], p=[.05,.1,.25,.4,.2]),
            'actual_plant_ratio': np.random.uniform(65, 100),
            'actual_disease_severity': np.random.choice([0,1,2,3,4,5,6], p=[.35,.25,.18,.1,.06,.04,.02])
        })
    
    # Add some missing values
    for i in np.random.choice(n, 5, replace=False):
        inspections[i]['actual_soaking_date'] = None
    for i in np.random.choice(n, 3, replace=False):
        inspections[i]['actual_tiller_count'] = None
    
    df_insp = pd.DataFrame(inspections)
    
    # Recommendations
    recs = []
    for crop_id, var_ids in [(1, [1,2,3,4]), (3, [7,8])]:
        for var_id in var_ids:
            recs.append({
                'recommendation_id': len(recs) + 1,
                'crop_id': crop_id,
                'variety_id': var_id,
                'season_id': 1,
                'rec_soaking_date': date(2024, 6, 1),
                'rec_soaking_offset': None,
                'rec_sowing_date': date(2024, 6, 8),
                'rec_sowing_offset': 7,
                'rec_transplant_date': date(2024, 6, 28),
                'rec_transplant_offset': 20,
                'rec_flowering_date': None,
                'rec_flowering_offset': 35,
                'rec_pest_severity_target': 0,
                'rec_pest_severity_max': 3,
                'rec_tiller_count_target': 15,
                'rec_tiller_count_min': 12,
                'rec_tiller_count_max': 20,
                'rec_health_score_target': 4,
                'rec_health_score_min': 3,
                'rec_plant_ratio_target': 93.0,
                'rec_plant_ratio_min': 83.0,
                'rec_disease_severity_target': 0,
                'rec_disease_severity_max': 2,
                'tiller_count_stddev': 2.5,
                'plant_ratio_stddev': 5.0
            })
    
    return df_insp, pd.DataFrame(recs)


def run_demo():
    """Run demo without database"""
    print("=" * 80)
    print("AGRICULTURAL VARIANCE ANALYSIS - DEMO")
    print("=" * 80)
    
    df_insp, df_rec = generate_demo_data()
    print(f"\nGenerated {len(df_insp)} inspections and {len(df_rec)} recommendations")
    
    pipeline = VarianceAnalysisPipeline()
    pipeline.initialize(use_db=False)
    pipeline.df_inspections = df_insp
    pipeline.df_recommendations = df_rec
    
    results = pipeline.run_analysis()
    
    print("\n" + "=" * 80)
    print("RESULTS")
    print("=" * 80)
    
    print("\n--- Inspection Summaries ---")
    print(results['inspection_summaries'][
        ['inspection_id', 'overall_variance_score', 'variance_category', 
         'attributes_within_tolerance', 'primary_reason_code']
    ].head(15).to_string(index=False))
    
    print("\n--- Attribute Contributions ---")
    print(results['attribute_contributions'].to_string(index=False))
    
    print("\n--- Reason Code Distribution ---")
    print(results['reason_code_distribution'].to_string(index=False))
    
    print("\n--- Key Metrics ---")
    summaries = results['inspection_summaries']
    print(f"Total Inspections: {len(summaries)}")
    print(f"Average Variance Score: {summaries['overall_variance_score'].mean():.4f}")
    print(f"\nCategory Distribution:")
    print(summaries['variance_category'].value_counts().to_string())
    
    return results


if __name__ == "__main__":
    run_demo()
