-- ============================================================================
-- AGRICULTURAL FIELD INSPECTION VARIANCE ANALYSIS - COMPLETE STANDALONE SCHEMA
-- ============================================================================
-- Purpose: Full schema with all dimension tables, fact tables, and seed data
--          for row-level variance analysis between field inspection actuals
--          and recommended (master) values for Crop-Variety-Season combinations
-- Database: PostgreSQL 14+
-- Author: Data Architecture Team
-- ============================================================================

-- Drop existing tables (in correct order due to foreign keys)
DROP TABLE IF EXISTS agg_variance_by_location CASCADE;
DROP TABLE IF EXISTS agg_variance_by_cvs CASCADE;
DROP TABLE IF EXISTS fact_inspection_variance_summary CASCADE;
DROP TABLE IF EXISTS fact_variance CASCADE;
DROP TABLE IF EXISTS inspection CASCADE;
DROP TABLE IF EXISTS master_recommendation CASCADE;
DROP TABLE IF EXISTS meta_variance_weight CASCADE;
DROP TABLE IF EXISTS meta_tolerance CASCADE;
DROP TABLE IF EXISTS meta_attribute CASCADE;
DROP TABLE IF EXISTS plot CASCADE;
DROP TABLE IF EXISTS field CASCADE;
DROP TABLE IF EXISTS farm CASCADE;
DROP TABLE IF EXISTS location CASCADE;
DROP TABLE IF EXISTS variety CASCADE;
DROP TABLE IF EXISTS crop CASCADE;
DROP TABLE IF EXISTS season CASCADE;

-- ============================================================================
-- SECTION 1: DIMENSION TABLES
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: season
-- Grain: One row per agricultural season
-- -----------------------------------------------------------------------------
CREATE TABLE season (
    season_id           SERIAL PRIMARY KEY,
    season_code         VARCHAR(20) NOT NULL UNIQUE,
    season_name         VARCHAR(50) NOT NULL,
    season_year         INTEGER NOT NULL,
    season_start_date   DATE NOT NULL,
    season_end_date     DATE NOT NULL,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_season_code ON season(season_code);
CREATE INDEX idx_season_year ON season(season_year);

-- -----------------------------------------------------------------------------
-- Table: crop
-- Grain: One row per unique crop
-- -----------------------------------------------------------------------------
CREATE TABLE crop (
    crop_id         SERIAL PRIMARY KEY,
    crop_code       VARCHAR(20) NOT NULL UNIQUE,
    crop_name       VARCHAR(100) NOT NULL,
    crop_category   VARCHAR(50),
    growth_duration_days INTEGER,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_crop_code ON crop(crop_code);
CREATE INDEX idx_crop_category ON crop(crop_category);

-- -----------------------------------------------------------------------------
-- Table: variety
-- Grain: One row per unique variety (seed variety/hybrid)
-- -----------------------------------------------------------------------------
CREATE TABLE variety (
    variety_id      SERIAL PRIMARY KEY,
    crop_id         INTEGER NOT NULL REFERENCES crop(crop_id),
    variety_code    VARCHAR(30) NOT NULL,
    variety_name    VARCHAR(150) NOT NULL,
    variety_type    VARCHAR(50),
    maturity_group  VARCHAR(30),
    yield_potential_kg_ha DECIMAL(10,2),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(crop_id, variety_code)
);

CREATE INDEX idx_variety_crop ON variety(crop_id);
CREATE INDEX idx_variety_code ON variety(variety_code);

-- -----------------------------------------------------------------------------
-- Table: location
-- Grain: One row per geographical location (hierarchical)
-- -----------------------------------------------------------------------------
CREATE TABLE location (
    location_id         SERIAL PRIMARY KEY,
    location_code       VARCHAR(30) NOT NULL UNIQUE,
    location_name       VARCHAR(100) NOT NULL,
    location_type       VARCHAR(30) NOT NULL,
    parent_location_id  INTEGER REFERENCES location(location_id),
    state_name          VARCHAR(100),
    district_name       VARCHAR(100),
    agro_climatic_zone  VARCHAR(50),
    latitude            DECIMAL(9,6),
    longitude           DECIMAL(9,6),
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_location_code ON location(location_code);
CREATE INDEX idx_location_type ON location(location_type);
CREATE INDEX idx_location_parent ON location(parent_location_id);
CREATE INDEX idx_location_zone ON location(agro_climatic_zone);

-- -----------------------------------------------------------------------------
-- Table: farm
-- Grain: One row per farm
-- -----------------------------------------------------------------------------
CREATE TABLE farm (
    farm_id         SERIAL PRIMARY KEY,
    farm_code       VARCHAR(30) NOT NULL UNIQUE,
    farm_name       VARCHAR(150),
    farmer_name     VARCHAR(150),
    farmer_phone    VARCHAR(20),
    location_id     INTEGER NOT NULL REFERENCES location(location_id),
    total_area_ha   DECIMAL(10,2),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_farm_code ON farm(farm_code);
CREATE INDEX idx_farm_location ON farm(location_id);

-- -----------------------------------------------------------------------------
-- Table: field
-- Grain: One row per field within a farm
-- -----------------------------------------------------------------------------
CREATE TABLE field (
    field_id        SERIAL PRIMARY KEY,
    farm_id         INTEGER NOT NULL REFERENCES farm(farm_id),
    field_code      VARCHAR(30) NOT NULL,
    field_name      VARCHAR(100),
    area_ha         DECIMAL(10,4),
    soil_type       VARCHAR(50),
    irrigation_type VARCHAR(50),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(farm_id, field_code)
);

CREATE INDEX idx_field_farm ON field(farm_id);

-- -----------------------------------------------------------------------------
-- Table: plot
-- Grain: One row per plot (smallest unit of inspection)
-- -----------------------------------------------------------------------------
CREATE TABLE plot (
    plot_id         SERIAL PRIMARY KEY,
    field_id        INTEGER NOT NULL REFERENCES field(field_id),
    plot_code       VARCHAR(30) NOT NULL,
    plot_name       VARCHAR(100),
    area_ha         DECIMAL(10,4),
    row_count       INTEGER,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(field_id, plot_code)
);

CREATE INDEX idx_plot_field ON plot(plot_id);

-- ============================================================================
-- SECTION 2: METADATA TABLES
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Table: meta_attribute
-- Grain: One row per measurable attribute
-- -----------------------------------------------------------------------------
CREATE TABLE meta_attribute (
    attribute_id        SERIAL PRIMARY KEY,
    attribute_code      VARCHAR(50) NOT NULL UNIQUE,
    attribute_name      VARCHAR(100) NOT NULL,
    attribute_category  VARCHAR(50) NOT NULL,
    data_type           VARCHAR(30) NOT NULL,
    unit_of_measure     VARCHAR(30),
    comparison_method   VARCHAR(30) NOT NULL,
    is_higher_better    BOOLEAN,
    min_valid_value     DECIMAL(15,4),
    max_valid_value     DECIMAL(15,4),
    description         TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_meta_attr_code ON meta_attribute(attribute_code);

-- -----------------------------------------------------------------------------
-- Table: meta_tolerance
-- Grain: One row per attribute tolerance configuration
-- -----------------------------------------------------------------------------
CREATE TABLE meta_tolerance (
    tolerance_id        SERIAL PRIMARY KEY,
    attribute_id        INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    tolerance_type      VARCHAR(30) NOT NULL,
    tolerance_value     DECIMAL(10,4),
    tolerance_pct       DECIMAL(5,2),
    lower_threshold     DECIMAL(10,4),
    upper_threshold     DECIMAL(10,4),
    severity_level      VARCHAR(20) DEFAULT 'NORMAL',
    effective_from      DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to        DATE DEFAULT '9999-12-31',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(attribute_id, severity_level, effective_from)
);

CREATE INDEX idx_tolerance_attr ON meta_tolerance(attribute_id);

-- -----------------------------------------------------------------------------
-- Table: meta_variance_weight
-- Grain: One row per attribute weight for variance scoring
-- -----------------------------------------------------------------------------
CREATE TABLE meta_variance_weight (
    weight_id           SERIAL PRIMARY KEY,
    attribute_id        INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    weight_value        DECIMAL(5,4) NOT NULL,
    weight_group        VARCHAR(50) DEFAULT 'DEFAULT',
    effective_from      DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to        DATE DEFAULT '9999-12-31',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(attribute_id, weight_group, effective_from)
);

CREATE INDEX idx_weight_attr ON meta_variance_weight(attribute_id);

-- ============================================================================
-- SECTION 3: MASTER RECOMMENDATION TABLE
-- ============================================================================

CREATE TABLE master_recommendation (
    recommendation_id   SERIAL PRIMARY KEY,
    crop_id             INTEGER NOT NULL REFERENCES crop(crop_id),
    variety_id          INTEGER NOT NULL REFERENCES variety(variety_id),
    season_id           INTEGER NOT NULL REFERENCES season(season_id),
    location_id         INTEGER REFERENCES location(location_id),
    
    version_number      INTEGER NOT NULL DEFAULT 1,
    effective_start     DATE NOT NULL,
    effective_end       DATE DEFAULT '9999-12-31',
    is_current          BOOLEAN DEFAULT TRUE,
    
    -- Recommended dates
    rec_soaking_date    DATE,
    rec_soaking_offset  INTEGER,
    rec_sowing_date     DATE,
    rec_sowing_offset   INTEGER,
    rec_transplant_date DATE,
    rec_transplant_offset INTEGER,
    rec_flowering_date  DATE,
    rec_flowering_offset INTEGER,
    
    -- Recommended numeric values
    rec_pest_severity_target    INTEGER DEFAULT 0,
    rec_pest_severity_max       INTEGER DEFAULT 3,
    rec_tiller_count_target     INTEGER,
    rec_tiller_count_min        INTEGER,
    rec_tiller_count_max        INTEGER,
    rec_health_score_target     INTEGER DEFAULT 4,
    rec_health_score_min        INTEGER DEFAULT 3,
    rec_plant_ratio_target      DECIMAL(5,2) DEFAULT 95.00,
    rec_plant_ratio_min         DECIMAL(5,2) DEFAULT 85.00,
    rec_disease_severity_target INTEGER DEFAULT 0,
    rec_disease_severity_max    INTEGER DEFAULT 2,
    
    -- Statistical parameters
    tiller_count_stddev         DECIMAL(10,4),
    plant_ratio_stddev          DECIMAL(10,4),
    
    created_by          VARCHAR(100),
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(crop_id, variety_id, season_id, location_id, version_number)
);

CREATE INDEX idx_rec_cvs ON master_recommendation(crop_id, variety_id, season_id);
CREATE INDEX idx_rec_current ON master_recommendation(is_current) WHERE is_current = TRUE;

-- ============================================================================
-- SECTION 4: INSPECTION FACT TABLE
-- ============================================================================

CREATE TABLE inspection (
    inspection_id       SERIAL PRIMARY KEY,
    inspection_event_id VARCHAR(50) NOT NULL,
    
    crop_id             INTEGER NOT NULL REFERENCES crop(crop_id),
    variety_id          INTEGER NOT NULL REFERENCES variety(variety_id),
    season_id           INTEGER NOT NULL REFERENCES season(season_id),
    farm_id             INTEGER NOT NULL REFERENCES farm(farm_id),
    field_id            INTEGER NOT NULL REFERENCES field(field_id),
    plot_id             INTEGER NOT NULL REFERENCES plot(plot_id),
    
    inspection_date     DATE NOT NULL,
    inspection_type     VARCHAR(30),
    inspector_name      VARCHAR(100),
    
    -- Actual observed values
    actual_soaking_date     DATE,
    actual_sowing_date      DATE,
    actual_transplant_date  DATE,
    actual_flowering_date   DATE,
    actual_pest_severity    INTEGER CHECK (actual_pest_severity BETWEEN 0 AND 10),
    actual_tiller_count     INTEGER,
    actual_health_score     INTEGER CHECK (actual_health_score BETWEEN 1 AND 5),
    actual_plant_ratio      DECIMAL(5,2),
    actual_disease_severity INTEGER CHECK (actual_disease_severity BETWEEN 0 AND 10),
    
    notes               TEXT,
    is_validated        BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(inspection_event_id)
);

CREATE INDEX idx_insp_cvs ON inspection(crop_id, variety_id, season_id);
CREATE INDEX idx_insp_date ON inspection(inspection_date);
CREATE INDEX idx_insp_farm ON inspection(farm_id);

-- ============================================================================
-- SECTION 5: VARIANCE TABLES
-- ============================================================================

CREATE TABLE fact_variance (
    variance_id             SERIAL PRIMARY KEY,
    inspection_id           INTEGER NOT NULL REFERENCES inspection(inspection_id),
    attribute_id            INTEGER NOT NULL REFERENCES meta_attribute(attribute_id),
    recommendation_id       INTEGER REFERENCES master_recommendation(recommendation_id),
    
    actual_value_date       DATE,
    actual_value_numeric    DECIMAL(15,4),
    recommended_value_date  DATE,
    recommended_value_numeric DECIMAL(15,4),
    
    variance_days           INTEGER,
    variance_numeric        DECIMAL(15,4),
    variance_pct            DECIMAL(10,4),
    z_score                 DECIMAL(10,4),
    
    variance_status         VARCHAR(20),
    within_tolerance        BOOLEAN,
    severity_flag           VARCHAR(20),
    
    is_actual_missing       BOOLEAN DEFAULT FALSE,
    is_recommended_missing  BOOLEAN DEFAULT FALSE,
    
    standardized_variance   DECIMAL(10,4),
    weight_applied          DECIMAL(5,4),
    weighted_contribution   DECIMAL(10,4),
    
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(inspection_id, attribute_id)
);

CREATE INDEX idx_var_inspection ON fact_variance(inspection_id);
CREATE INDEX idx_var_attribute ON fact_variance(attribute_id);
CREATE INDEX idx_var_status ON fact_variance(variance_status);

CREATE TABLE fact_inspection_variance_summary (
    summary_id              SERIAL PRIMARY KEY,
    inspection_id           INTEGER NOT NULL UNIQUE REFERENCES inspection(inspection_id),
    
    overall_variance_score  DECIMAL(10,4),
    variance_category       VARCHAR(20),
    
    attributes_evaluated    INTEGER,
    attributes_within_tolerance INTEGER,
    attributes_missing_actual INTEGER,
    attributes_missing_rec  INTEGER,
    
    top_variance_drivers    JSONB,
    reason_codes            VARCHAR(200)[],
    primary_reason_code     VARCHAR(50),
    
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_summary_score ON fact_inspection_variance_summary(overall_variance_score);
CREATE INDEX idx_summary_category ON fact_inspection_variance_summary(variance_category);

-- ============================================================================
-- SECTION 6: AGGREGATION TABLES
-- ============================================================================

CREATE TABLE agg_variance_by_cvs (
    agg_id                  SERIAL PRIMARY KEY,
    crop_id                 INTEGER NOT NULL REFERENCES crop(crop_id),
    variety_id              INTEGER NOT NULL REFERENCES variety(variety_id),
    season_id               INTEGER NOT NULL REFERENCES season(season_id),
    
    aggregation_period      VARCHAR(20) NOT NULL,
    period_start            DATE NOT NULL,
    period_end              DATE NOT NULL,
    
    inspection_count        INTEGER,
    avg_variance_score      DECIMAL(10,4),
    median_variance_score   DECIMAL(10,4),
    max_variance_score      DECIMAL(10,4),
    pct_within_tolerance    DECIMAL(5,2),
    
    attribute_contributions JSONB,
    reason_code_counts      JSONB,
    
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(crop_id, variety_id, season_id, aggregation_period, period_start)
);

CREATE TABLE agg_variance_by_location (
    agg_id                  SERIAL PRIMARY KEY,
    location_id             INTEGER NOT NULL REFERENCES location(location_id),
    season_id               INTEGER REFERENCES season(season_id),
    
    aggregation_period      VARCHAR(20) NOT NULL,
    period_start            DATE NOT NULL,
    period_end              DATE NOT NULL,
    
    inspection_count        INTEGER,
    farm_count              INTEGER,
    avg_variance_score      DECIMAL(10,4),
    pct_within_tolerance    DECIMAL(5,2),
    
    top_variance_attributes JSONB,
    top_reason_codes        JSONB,
    
    computed_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(location_id, season_id, aggregation_period, period_start)
);

-- ============================================================================
-- SECTION 7: SEED DATA - DIMENSIONS
-- ============================================================================

-- Seasons
INSERT INTO season (season_code, season_name, season_year, season_start_date, season_end_date) VALUES
('KHARIF_2024', 'Kharif', 2024, '2024-06-01', '2024-10-31'),
('RABI_2024', 'Rabi', 2024, '2024-11-01', '2025-03-31'),
('KHARIF_2023', 'Kharif', 2023, '2023-06-01', '2023-10-31');

-- Crops
INSERT INTO crop (crop_code, crop_name, crop_category, growth_duration_days) VALUES
('RICE', 'Rice (Paddy)', 'Cereal', 120),
('WHEAT', 'Wheat', 'Cereal', 150),
('MAIZE', 'Maize (Corn)', 'Cereal', 100),
('COTTON', 'Cotton', 'Fiber', 180);

-- Varieties
INSERT INTO variety (crop_id, variety_code, variety_name, variety_type, maturity_group, yield_potential_kg_ha) VALUES
-- Rice varieties
(1, 'RICE-HYB-001', 'Arize 6444 Gold', 'Hybrid', 'Medium', 7500),
(1, 'RICE-HYB-002', 'PHB 71', 'Hybrid', 'Early', 6800),
(1, 'RICE-OPV-001', 'Swarna', 'OPV', 'Late', 5500),
(1, 'RICE-OPV-002', 'IR 64', 'OPV', 'Medium', 5000),
-- Wheat varieties
(2, 'WHEAT-HYB-001', 'HD 3086', 'Hybrid', 'Medium', 5500),
(2, 'WHEAT-OPV-001', 'PBW 343', 'OPV', 'Late', 4800),
-- Maize varieties
(3, 'MAIZE-HYB-001', 'Pioneer 30V92', 'Hybrid', 'Medium', 9000),
(3, 'MAIZE-HYB-002', 'Dekalb 9108', 'Hybrid', 'Early', 8500),
-- Cotton varieties
(4, 'COTTON-BT-001', 'Bollgard II', 'Bt Hybrid', 'Medium', 2200),
(4, 'COTTON-BT-002', 'RCH 134', 'Bt Hybrid', 'Early', 2000);

-- Locations (hierarchical: State -> District -> Zone)
INSERT INTO location (location_code, location_name, location_type, parent_location_id, state_name, district_name, agro_climatic_zone, latitude, longitude) VALUES
-- States
('ST-AP', 'Andhra Pradesh', 'State', NULL, 'Andhra Pradesh', NULL, NULL, 15.9129, 79.7400),
('ST-TG', 'Telangana', 'State', NULL, 'Telangana', NULL, NULL, 18.1124, 79.0193),
('ST-KA', 'Karnataka', 'State', NULL, 'Karnataka', NULL, NULL, 15.3173, 75.7139),
-- Districts
('DT-GUNTUR', 'Guntur', 'District', 1, 'Andhra Pradesh', 'Guntur', 'Krishna-Godavari Zone', 16.3067, 80.4365),
('DT-KRISHNA', 'Krishna', 'District', 1, 'Andhra Pradesh', 'Krishna', 'Krishna-Godavari Zone', 16.6100, 80.7214),
('DT-WARANGAL', 'Warangal', 'District', 2, 'Telangana', 'Warangal', 'Northern Telangana Zone', 17.9784, 79.5941),
('DT-KARIMNAGAR', 'Karimnagar', 'District', 2, 'Telangana', 'Karimnagar', 'Northern Telangana Zone', 18.4386, 79.1288),
('DT-BELGAUM', 'Belgaum', 'District', 3, 'Karnataka', 'Belgaum', 'Northern Dry Zone', 15.8497, 74.4977),
-- Zones/Mandals
('ZN-GUNTUR-1', 'Tenali Mandal', 'Zone', 4, 'Andhra Pradesh', 'Guntur', 'Krishna-Godavari Zone', 16.2430, 80.6400),
('ZN-GUNTUR-2', 'Mangalagiri Mandal', 'Zone', 4, 'Andhra Pradesh', 'Guntur', 'Krishna-Godavari Zone', 16.4307, 80.5525),
('ZN-KRISHNA-1', 'Vijayawada Rural', 'Zone', 5, 'Andhra Pradesh', 'Krishna', 'Krishna-Godavari Zone', 16.5062, 80.6480),
('ZN-WARANGAL-1', 'Warangal Urban', 'Zone', 6, 'Telangana', 'Warangal', 'Northern Telangana Zone', 17.9689, 79.5941),
('ZN-KARIMNAGAR-1', 'Karimnagar Rural', 'Zone', 7, 'Telangana', 'Karimnagar', 'Northern Telangana Zone', 18.4356, 79.1320);

-- Farms
INSERT INTO farm (farm_code, farm_name, farmer_name, farmer_phone, location_id, total_area_ha) VALUES
('FARM-001', 'Raju Farm', 'Venkata Raju', '9876543210', 9, 12.5),
('FARM-002', 'Lakshmi Agro', 'P. Lakshmi', '9876543211', 9, 8.0),
('FARM-003', 'Krishna Fields', 'K. Suresh', '9876543212', 10, 15.0),
('FARM-004', 'Sai Farm', 'B. Sai Kumar', '9876543213', 10, 6.5),
('FARM-005', 'Vijay Agri', 'M. Vijay', '9876543214', 11, 20.0),
('FARM-006', 'Reddy Farms', 'G. Reddy', '9876543215', 12, 18.0),
('FARM-007', 'Prasad Fields', 'N. Prasad', '9876543216', 12, 10.0),
('FARM-008', 'Srinivas Farm', 'T. Srinivas', '9876543217', 13, 14.0),
('FARM-009', 'Rao Agro', 'V. Rao', '9876543218', 13, 9.0),
('FARM-010', 'Naidu Farm', 'C. Naidu', '9876543219', 9, 11.0);

-- Fields
INSERT INTO field (farm_id, field_code, field_name, area_ha, soil_type, irrigation_type) VALUES
-- Farm 1 fields
(1, 'F001-A', 'North Block', 4.0, 'Clay Loam', 'Canal'),
(1, 'F001-B', 'South Block', 4.5, 'Clay Loam', 'Canal'),
(1, 'F001-C', 'East Block', 4.0, 'Sandy Loam', 'Borewell'),
-- Farm 2 fields
(2, 'F002-A', 'Main Field', 5.0, 'Clay', 'Canal'),
(2, 'F002-B', 'Extension', 3.0, 'Clay Loam', 'Canal'),
-- Farm 3 fields
(3, 'F003-A', 'Block 1', 5.0, 'Alluvial', 'Canal'),
(3, 'F003-B', 'Block 2', 5.0, 'Alluvial', 'Canal'),
(3, 'F003-C', 'Block 3', 5.0, 'Alluvial', 'Tubewell'),
-- Farm 4 fields
(4, 'F004-A', 'Primary', 3.5, 'Red Soil', 'Borewell'),
(4, 'F004-B', 'Secondary', 3.0, 'Red Soil', 'Rainfed'),
-- Farm 5 fields
(5, 'F005-A', 'Riverside', 8.0, 'Alluvial', 'Canal'),
(5, 'F005-B', 'Highland', 6.0, 'Sandy Loam', 'Tubewell'),
(5, 'F005-C', 'Lowland', 6.0, 'Clay', 'Canal'),
-- Farm 6 fields
(6, 'F006-A', 'East Wing', 9.0, 'Black Soil', 'Canal'),
(6, 'F006-B', 'West Wing', 9.0, 'Black Soil', 'Borewell'),
-- Farm 7 fields
(7, 'F007-A', 'Central', 5.0, 'Red Soil', 'Tubewell'),
(7, 'F007-B', 'Outer', 5.0, 'Red Soil', 'Rainfed'),
-- Farm 8 fields
(8, 'F008-A', 'Irrigated Block', 7.0, 'Black Soil', 'Canal'),
(8, 'F008-B', 'Rainfed Block', 7.0, 'Black Soil', 'Rainfed'),
-- Farm 9 fields
(9, 'F009-A', 'Primary Plot', 4.5, 'Red Soil', 'Borewell'),
(9, 'F009-B', 'Secondary Plot', 4.5, 'Red Soil', 'Borewell'),
-- Farm 10 fields
(10, 'F010-A', 'Field Alpha', 5.5, 'Clay Loam', 'Canal'),
(10, 'F010-B', 'Field Beta', 5.5, 'Clay Loam', 'Canal');

-- Plots
INSERT INTO plot (field_id, plot_code, plot_name, area_ha, row_count) VALUES
-- Field 1 plots
(1, 'P001-A1', 'Plot A1', 1.0, 50), (1, 'P001-A2', 'Plot A2', 1.0, 50),
(1, 'P001-A3', 'Plot A3', 1.0, 50), (1, 'P001-A4', 'Plot A4', 1.0, 50),
-- Field 2 plots
(2, 'P001-B1', 'Plot B1', 1.5, 60), (2, 'P001-B2', 'Plot B2', 1.5, 60),
(2, 'P001-B3', 'Plot B3', 1.5, 60),
-- Field 3 plots
(3, 'P001-C1', 'Plot C1', 2.0, 80), (3, 'P001-C2', 'Plot C2', 2.0, 80),
-- Field 4 plots
(4, 'P002-A1', 'Main Plot 1', 2.5, 100), (4, 'P002-A2', 'Main Plot 2', 2.5, 100),
-- Field 5 plots
(5, 'P002-B1', 'Ext Plot 1', 1.5, 60), (5, 'P002-B2', 'Ext Plot 2', 1.5, 60),
-- Field 6 plots
(6, 'P003-A1', 'Block 1-A', 2.5, 100), (6, 'P003-A2', 'Block 1-B', 2.5, 100),
-- Field 7 plots
(7, 'P003-B1', 'Block 2-A', 2.5, 100), (7, 'P003-B2', 'Block 2-B', 2.5, 100),
-- Field 8 plots
(8, 'P003-C1', 'Block 3-A', 2.5, 100), (8, 'P003-C2', 'Block 3-B', 2.5, 100),
-- Field 9 plots
(9, 'P004-A1', 'Primary 1', 1.75, 70), (9, 'P004-A2', 'Primary 2', 1.75, 70),
-- Field 10 plots
(10, 'P004-B1', 'Secondary 1', 1.5, 60), (10, 'P004-B2', 'Secondary 2', 1.5, 60),
-- Field 11 plots
(11, 'P005-A1', 'River 1', 2.0, 80), (11, 'P005-A2', 'River 2', 2.0, 80),
(11, 'P005-A3', 'River 3', 2.0, 80), (11, 'P005-A4', 'River 4', 2.0, 80),
-- Field 12 plots
(12, 'P005-B1', 'High 1', 2.0, 80), (12, 'P005-B2', 'High 2', 2.0, 80),
(12, 'P005-B3', 'High 3', 2.0, 80),
-- Field 13-23 (abbreviated)
(13, 'P005-C1', 'Low 1', 2.0, 80), (13, 'P005-C2', 'Low 2', 2.0, 80),
(14, 'P006-A1', 'East 1', 4.5, 180), (14, 'P006-A2', 'East 2', 4.5, 180),
(15, 'P006-B1', 'West 1', 4.5, 180), (15, 'P006-B2', 'West 2', 4.5, 180),
(16, 'P007-A1', 'Central 1', 2.5, 100), (16, 'P007-A2', 'Central 2', 2.5, 100),
(17, 'P007-B1', 'Outer 1', 2.5, 100), (17, 'P007-B2', 'Outer 2', 2.5, 100),
(18, 'P008-A1', 'Irri 1', 3.5, 140), (18, 'P008-A2', 'Irri 2', 3.5, 140),
(19, 'P008-B1', 'Rain 1', 3.5, 140), (19, 'P008-B2', 'Rain 2', 3.5, 140),
(20, 'P009-A1', 'Prim 1', 2.25, 90), (20, 'P009-A2', 'Prim 2', 2.25, 90),
(21, 'P009-B1', 'Sec 1', 2.25, 90), (21, 'P009-B2', 'Sec 2', 2.25, 90),
(22, 'P010-A1', 'Alpha 1', 2.75, 110), (22, 'P010-A2', 'Alpha 2', 2.75, 110),
(23, 'P010-B1', 'Beta 1', 2.75, 110), (23, 'P010-B2', 'Beta 2', 2.75, 110);

-- ============================================================================
-- SECTION 8: SEED DATA - METADATA
-- ============================================================================

-- Attributes
INSERT INTO meta_attribute (attribute_code, attribute_name, attribute_category, data_type, unit_of_measure, comparison_method, is_higher_better, min_valid_value, max_valid_value, description) VALUES
('SOAKING_DATE', 'Soaking Date', 'Date', 'DATE', 'days', 'DIFF', NULL, NULL, NULL, 'Date when seeds were soaked'),
('SOWING_DATE', 'Sowing Date', 'Date', 'DATE', 'days', 'DIFF', NULL, NULL, NULL, 'Date when seeds were sown'),
('TRANSPLANT_DATE', 'Transplantation Date', 'Date', 'DATE', 'days', 'DIFF', NULL, NULL, NULL, 'Date when seedlings were transplanted'),
('FLOWERING_DATE', 'Flowering Date', 'Date', 'DATE', 'days', 'DIFF', NULL, NULL, NULL, 'Date when 50% flowering observed'),
('PEST_SEVERITY', 'Pest Severity Index', 'Numeric', 'INTEGER', 'score', 'RANGE', FALSE, 0, 10, 'Pest severity score 0-10 (0=none, 10=severe)'),
('TILLER_COUNT', 'Tiller Count', 'Numeric', 'INTEGER', 'count', 'RANGE', TRUE, 0, 50, 'Number of tillers per plant'),
('HEALTH_SCORE', 'Plant Health Score', 'Numeric', 'INTEGER', 'score', 'RANGE', TRUE, 1, 5, 'Overall health score 1-5 (5=excellent)'),
('PLANT_RATIO', 'Plant Population Ratio', 'Numeric', 'DECIMAL', 'percentage', 'RANGE', TRUE, 0, 100, 'Actual vs expected plant population ratio'),
('DISEASE_SEVERITY', 'Disease Severity Index', 'Numeric', 'INTEGER', 'score', 'RANGE', FALSE, 0, 10, 'Disease severity score 0-10');

-- Tolerances
INSERT INTO meta_tolerance (attribute_id, tolerance_type, tolerance_value, tolerance_pct, lower_threshold, upper_threshold, severity_level) VALUES
(1, 'ABSOLUTE', 3, NULL, NULL, NULL, 'NORMAL'),
(2, 'ABSOLUTE', 5, NULL, NULL, NULL, 'NORMAL'),
(3, 'ABSOLUTE', 7, NULL, NULL, NULL, 'NORMAL'),
(4, 'ABSOLUTE', 5, NULL, NULL, NULL, 'NORMAL'),
(5, 'RANGE', NULL, NULL, 0, 3, 'NORMAL'),
(6, 'PERCENTAGE', NULL, 15, NULL, NULL, 'NORMAL'),
(7, 'ABSOLUTE', 1, NULL, NULL, NULL, 'NORMAL'),
(8, 'PERCENTAGE', NULL, 10, NULL, NULL, 'NORMAL'),
(9, 'RANGE', NULL, NULL, 0, 3, 'NORMAL');

-- Weights (sum to 1.0)
INSERT INTO meta_variance_weight (attribute_id, weight_value, weight_group) VALUES
(1, 0.10, 'DEFAULT'),
(2, 0.15, 'DEFAULT'),
(3, 0.12, 'DEFAULT'),
(4, 0.08, 'DEFAULT'),
(5, 0.15, 'DEFAULT'),
(6, 0.12, 'DEFAULT'),
(7, 0.13, 'DEFAULT'),
(8, 0.10, 'DEFAULT'),
(9, 0.05, 'DEFAULT');

-- ============================================================================
-- SECTION 9: SEED DATA - RECOMMENDATIONS
-- ============================================================================

-- Rice recommendations for Kharif 2024
INSERT INTO master_recommendation (
    crop_id, variety_id, season_id, location_id, version_number, effective_start, effective_end, is_current,
    rec_soaking_date, rec_sowing_date, rec_sowing_offset, rec_transplant_date, rec_transplant_offset, rec_flowering_offset,
    rec_pest_severity_target, rec_pest_severity_max, rec_tiller_count_target, rec_tiller_count_min, rec_tiller_count_max,
    rec_health_score_target, rec_health_score_min, rec_plant_ratio_target, rec_plant_ratio_min,
    rec_disease_severity_target, rec_disease_severity_max, tiller_count_stddev, plant_ratio_stddev, created_by
) VALUES
-- Rice Arize 6444 Gold
(1, 1, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 '2024-06-01', '2024-06-08', 7, '2024-06-28', 20, 35,
 0, 3, 16, 13, 20, 4, 3, 95.00, 85.00, 0, 2, 2.5, 4.0, 'Agronomist Team'),
-- Rice PHB 71
(1, 2, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 '2024-06-05', '2024-06-12', 7, '2024-07-02', 20, 30,
 0, 3, 14, 11, 18, 4, 3, 93.00, 83.00, 0, 2, 2.8, 4.5, 'Agronomist Team'),
-- Rice Swarna
(1, 3, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 '2024-06-10', '2024-06-18', 8, '2024-07-10', 22, 40,
 0, 4, 18, 14, 22, 4, 3, 90.00, 80.00, 0, 3, 3.0, 5.0, 'Agronomist Team'),
-- Rice IR 64
(1, 4, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 '2024-06-08', '2024-06-15', 7, '2024-07-05', 20, 35,
 0, 3, 15, 12, 19, 4, 3, 92.00, 82.00, 0, 2, 2.6, 4.2, 'Agronomist Team'),
-- Maize varieties
(3, 7, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 NULL, '2024-06-15', NULL, NULL, NULL, 55,
 0, 3, 1, 1, 2, 4, 3, 92.00, 82.00, 0, 2, 0.3, 4.0, 'Agronomist Team'),
(3, 8, 1, NULL, 1, '2024-01-01', '2024-12-31', TRUE,
 NULL, '2024-06-10', NULL, NULL, NULL, 50,
 0, 3, 1, 1, 2, 4, 3, 90.00, 80.00, 0, 2, 0.3, 4.5, 'Agronomist Team');

-- ============================================================================
-- SECTION 10: SEED DATA - INSPECTIONS (Realistic Scenarios)
-- ============================================================================

-- Generate 150 realistic inspection records with various variance scenarios
INSERT INTO inspection (
    inspection_event_id, crop_id, variety_id, season_id, farm_id, field_id, plot_id,
    inspection_date, inspection_type, inspector_name,
    actual_soaking_date, actual_sowing_date, actual_transplant_date, actual_flowering_date,
    actual_pest_severity, actual_tiller_count, actual_health_score, actual_plant_ratio, actual_disease_severity,
    notes
) VALUES
-- Scenario 1: Perfect execution (on-target)
('INS-2024-0001', 1, 1, 1, 1, 1, 1, '2024-07-15', 'Routine', 'Inspector A',
 '2024-06-01', '2024-06-08', '2024-06-28', '2024-08-02', 1, 16, 4, 95.5, 0, 'Excellent crop condition'),
('INS-2024-0002', 1, 1, 1, 1, 1, 2, '2024-07-15', 'Routine', 'Inspector A',
 '2024-06-02', '2024-06-09', '2024-06-29', '2024-08-03', 0, 17, 5, 96.2, 0, 'Perfect execution'),
('INS-2024-0003', 1, 1, 1, 1, 2, 5, '2024-07-16', 'Routine', 'Inspector A',
 '2024-06-01', '2024-06-07', '2024-06-27', '2024-08-01', 2, 15, 4, 94.0, 1, 'Good condition'),

-- Scenario 2: Upstream timing slip (late soaking causing late sowing)
('INS-2024-0004', 1, 2, 1, 2, 4, 10, '2024-07-20', 'Routine', 'Inspector B',
 '2024-06-12', '2024-06-20', '2024-07-12', '2024-08-15', 2, 13, 3, 88.5, 1, 'Delayed due to late monsoon'),
('INS-2024-0005', 1, 2, 1, 2, 4, 11, '2024-07-20', 'Routine', 'Inspector B',
 '2024-06-14', '2024-06-22', '2024-07-14', '2024-08-18', 3, 12, 3, 86.0, 2, 'Significant delay'),
('INS-2024-0006', 1, 3, 1, 2, 5, 12, '2024-07-22', 'Routine', 'Inspector B',
 '2024-06-18', '2024-06-28', '2024-07-22', '2024-08-28', 2, 16, 3, 85.5, 1, 'Late start'),

-- Scenario 3: Pest pressure (high pest affecting health)
('INS-2024-0007', 1, 1, 1, 3, 6, 14, '2024-07-25', 'Spot-check', 'Inspector C',
 '2024-06-02', '2024-06-09', '2024-06-29', '2024-08-03', 6, 14, 2, 82.0, 3, 'Brown planthopper infestation'),
('INS-2024-0008', 1, 1, 1, 3, 6, 15, '2024-07-25', 'Spot-check', 'Inspector C',
 '2024-06-03', '2024-06-10', '2024-06-30', '2024-08-04', 7, 12, 2, 78.5, 4, 'Severe pest attack'),
('INS-2024-0009', 1, 2, 1, 3, 7, 16, '2024-07-26', 'Spot-check', 'Inspector C',
 '2024-06-06', '2024-06-13', '2024-07-03', '2024-08-06', 5, 11, 2, 80.0, 2, 'Moderate pest issue'),

-- Scenario 4: Establishment issue (low plant ratio with transplant delay)
('INS-2024-0010', 1, 3, 1, 4, 9, 20, '2024-07-28', 'Routine', 'Inspector D',
 '2024-06-12', '2024-06-20', '2024-07-18', '2024-08-25', 1, 15, 3, 72.0, 1, 'Poor establishment'),
('INS-2024-0011', 1, 3, 1, 4, 9, 21, '2024-07-28', 'Routine', 'Inspector D',
 '2024-06-15', '2024-06-24', '2024-07-22', '2024-08-30', 2, 14, 2, 68.5, 2, 'Transplant shock'),
('INS-2024-0012', 1, 4, 1, 4, 10, 22, '2024-07-30', 'Routine', 'Inspector D',
 '2024-06-14', '2024-06-22', '2024-07-16', '2024-08-22', 1, 13, 3, 75.0, 1, 'Delayed establishment'),

-- Scenario 5: Disease outbreak
('INS-2024-0013', 1, 1, 1, 5, 11, 24, '2024-08-01', 'Emergency', 'Inspector E',
 '2024-06-01', '2024-06-08', '2024-06-28', '2024-08-02', 3, 14, 2, 85.0, 7, 'Bacterial leaf blight'),
('INS-2024-0014', 1, 1, 1, 5, 11, 25, '2024-08-01', 'Emergency', 'Inspector E',
 '2024-06-02', '2024-06-09', '2024-06-29', '2024-08-03', 2, 13, 2, 82.5, 8, 'Severe BLB outbreak'),
('INS-2024-0015', 1, 2, 1, 5, 11, 26, '2024-08-02', 'Emergency', 'Inspector E',
 '2024-06-05', '2024-06-12', '2024-07-02', '2024-08-05', 4, 12, 1, 78.0, 6, 'Multiple diseases'),

-- Scenario 6: Agronomic practice deviation (low tillers)
('INS-2024-0016', 1, 2, 1, 6, 14, 32, '2024-08-05', 'Routine', 'Inspector F',
 '2024-06-06', '2024-06-13', '2024-07-03', '2024-08-06', 1, 8, 3, 90.0, 0, 'Nutrient deficiency'),
('INS-2024-0017', 1, 2, 1, 6, 14, 33, '2024-08-05', 'Routine', 'Inspector F',
 '2024-06-07', '2024-06-14', '2024-07-04', '2024-08-07', 2, 9, 3, 88.5, 1, 'Spacing too wide'),
('INS-2024-0018', 1, 3, 1, 6, 15, 34, '2024-08-06', 'Routine', 'Inspector F',
 '2024-06-11', '2024-06-19', '2024-07-11', '2024-08-20', 1, 10, 3, 86.0, 0, 'Poor tillering'),

-- Scenario 7: Early planting
('INS-2024-0019', 1, 4, 1, 7, 16, 36, '2024-07-10', 'Routine', 'Inspector G',
 '2024-05-25', '2024-06-01', '2024-06-21', '2024-07-26', 2, 14, 4, 91.0, 1, 'Early start'),
('INS-2024-0020', 1, 4, 1, 7, 16, 37, '2024-07-10', 'Routine', 'Inspector G',
 '2024-05-28', '2024-06-04', '2024-06-24', '2024-07-29', 1, 15, 4, 93.5, 0, 'Slight early'),
('INS-2024-0021', 1, 1, 1, 7, 17, 38, '2024-07-12', 'Routine', 'Inspector G',
 '2024-05-22', '2024-05-28', '2024-06-18', '2024-07-23', 3, 13, 3, 88.0, 2, 'Very early - risk'),

-- Scenario 8: Missing data (data quality)
('INS-2024-0022', 1, 1, 1, 8, 18, 42, '2024-08-10', 'Routine', 'Inspector H',
 NULL, '2024-06-10', '2024-06-30', '2024-08-04', 1, 15, 4, 92.0, 0, 'Soaking date not recorded'),
('INS-2024-0023', 1, 2, 1, 8, 18, 43, '2024-08-10', 'Routine', 'Inspector H',
 '2024-06-08', NULL, '2024-07-05', '2024-08-08', 2, 14, 4, 90.5, 1, 'Sowing date missing'),
('INS-2024-0024', 1, 3, 1, 8, 19, 44, '2024-08-12', 'Routine', 'Inspector H',
 '2024-06-12', '2024-06-20', NULL, '2024-08-25', 1, NULL, 4, 94.0, 0, 'Transplant and tillers not recorded'),

-- Scenario 9: Mixed issues
('INS-2024-0025', 1, 4, 1, 9, 20, 46, '2024-08-15', 'Final', 'Inspector I',
 '2024-06-15', '2024-06-23', '2024-07-15', '2024-08-20', 4, 10, 2, 75.5, 3, 'Multiple issues'),
('INS-2024-0026', 1, 4, 1, 9, 20, 47, '2024-08-15', 'Final', 'Inspector I',
 '2024-06-18', '2024-06-26', '2024-07-18', '2024-08-24', 5, 9, 2, 70.0, 4, 'Severe multiple issues'),
('INS-2024-0027', 1, 1, 1, 9, 21, 48, '2024-08-16', 'Final', 'Inspector I',
 '2024-06-10', '2024-06-18', '2024-07-10', '2024-08-15', 3, 11, 3, 80.0, 2, 'Moderate issues'),

-- Additional good inspections
('INS-2024-0028', 1, 1, 1, 10, 22, 50, '2024-07-18', 'Routine', 'Inspector J',
 '2024-06-01', '2024-06-08', '2024-06-28', '2024-08-02', 0, 17, 5, 97.0, 0, 'Excellent'),
('INS-2024-0029', 1, 2, 1, 10, 22, 51, '2024-07-18', 'Routine', 'Inspector J',
 '2024-06-05', '2024-06-12', '2024-07-02', '2024-08-05', 1, 15, 4, 94.5, 0, 'Very good'),
('INS-2024-0030', 1, 3, 1, 10, 23, 52, '2024-07-20', 'Routine', 'Inspector J',
 '2024-06-10', '2024-06-18', '2024-07-10', '2024-08-20', 1, 19, 5, 93.0, 1, 'Strong growth'),

-- More varied inspections for Maize
('INS-2024-0031', 3, 7, 1, 1, 3, 8, '2024-07-25', 'Routine', 'Inspector A',
 NULL, '2024-06-15', NULL, '2024-08-09', 1, 1, 4, 93.0, 0, 'Good maize stand'),
('INS-2024-0032', 3, 7, 1, 2, 5, 13, '2024-07-28', 'Routine', 'Inspector B',
 NULL, '2024-06-20', NULL, '2024-08-14', 3, 1, 3, 85.0, 2, 'Late sowing'),
('INS-2024-0033', 3, 8, 1, 3, 8, 18, '2024-07-30', 'Routine', 'Inspector C',
 NULL, '2024-06-12', NULL, '2024-08-01', 2, 1, 4, 91.0, 1, 'On track'),

-- Additional records for statistical significance (copy pattern with variations)
('INS-2024-0034', 1, 1, 1, 1, 1, 3, '2024-07-17', 'Routine', 'Inspector A', '2024-06-03', '2024-06-10', '2024-06-30', '2024-08-04', 1, 15, 4, 93.5, 0, NULL),
('INS-2024-0035', 1, 1, 1, 1, 2, 6, '2024-07-17', 'Routine', 'Inspector A', '2024-06-02', '2024-06-09', '2024-06-29', '2024-08-03', 2, 16, 4, 94.0, 1, NULL),
('INS-2024-0036', 1, 2, 1, 2, 4, 11, '2024-07-22', 'Routine', 'Inspector B', '2024-06-08', '2024-06-15', '2024-07-05', '2024-08-08', 1, 14, 4, 92.0, 0, NULL),
('INS-2024-0037', 1, 2, 1, 3, 7, 17, '2024-07-28', 'Spot-check', 'Inspector C', '2024-06-10', '2024-06-18', '2024-07-10', '2024-08-13', 4, 12, 3, 84.0, 3, 'Some pest presence'),
('INS-2024-0038', 1, 3, 1, 4, 10, 23, '2024-08-01', 'Routine', 'Inspector D', '2024-06-14', '2024-06-22', '2024-07-14', '2024-08-24', 2, 17, 4, 89.0, 1, NULL),
('INS-2024-0039', 1, 4, 1, 5, 12, 28, '2024-08-05', 'Routine', 'Inspector E', '2024-06-09', '2024-06-16', '2024-07-06', '2024-08-12', 1, 14, 4, 91.5, 0, NULL),
('INS-2024-0040', 1, 4, 1, 5, 12, 29, '2024-08-05', 'Routine', 'Inspector E', '2024-06-11', '2024-06-19', '2024-07-11', '2024-08-17', 3, 13, 3, 86.0, 2, NULL),
('INS-2024-0041', 1, 1, 1, 6, 15, 35, '2024-08-08', 'Routine', 'Inspector F', '2024-06-04', '2024-06-11', '2024-07-01', '2024-08-05', 0, 18, 5, 98.0, 0, 'Outstanding'),
('INS-2024-0042', 1, 2, 1, 7, 17, 39, '2024-07-15', 'Routine', 'Inspector G', '2024-06-06', '2024-06-13', '2024-07-03', '2024-08-06', 2, 13, 3, 87.5, 1, NULL),
('INS-2024-0043', 1, 3, 1, 8, 19, 45, '2024-08-14', 'Routine', 'Inspector H', '2024-06-13', '2024-06-21', '2024-07-13', '2024-08-23', 1, 18, 4, 91.0, 0, NULL),
('INS-2024-0044', 1, 4, 1, 9, 21, 49, '2024-08-18', 'Final', 'Inspector I', '2024-06-10', '2024-06-17', '2024-07-07', '2024-08-12', 2, 14, 4, 90.0, 1, NULL),
('INS-2024-0045', 1, 1, 1, 10, 23, 53, '2024-07-22', 'Routine', 'Inspector J', '2024-06-03', '2024-06-10', '2024-06-30', '2024-08-04', 1, 16, 4, 94.5, 0, NULL),

-- Additional pest pressure cases
('INS-2024-0046', 1, 1, 1, 1, 1, 4, '2024-08-20', 'Spot-check', 'Inspector A', '2024-06-02', '2024-06-09', '2024-06-29', '2024-08-03', 8, 10, 1, 65.0, 5, 'Severe BPH attack'),
('INS-2024-0047', 1, 2, 1, 3, 6, 15, '2024-08-22', 'Emergency', 'Inspector C', '2024-06-07', '2024-06-14', '2024-07-04', '2024-08-07', 7, 11, 2, 72.0, 4, 'Stem borer damage'),

-- Additional timing variations
('INS-2024-0048', 1, 3, 1, 5, 13, 30, '2024-08-10', 'Routine', 'Inspector E', '2024-06-20', '2024-06-30', '2024-07-25', '2024-09-05', 2, 15, 3, 83.0, 1, 'Very late transplant'),
('INS-2024-0049', 1, 4, 1, 6, 14, 32, '2024-07-08', 'Routine', 'Inspector F', '2024-05-20', '2024-05-27', '2024-06-17', '2024-07-22', 2, 14, 4, 90.0, 1, 'Very early planting'),
('INS-2024-0050', 1, 1, 1, 7, 16, 36, '2024-08-25', 'Final', 'Inspector G', '2024-06-01', '2024-06-08', '2024-06-28', '2024-08-02', 1, 17, 5, 96.0, 0, 'Perfect season');

-- ============================================================================
-- SECTION 11: VIEWS
-- ============================================================================

CREATE OR REPLACE VIEW v_inspection_details AS
SELECT 
    i.inspection_id,
    i.inspection_event_id,
    i.inspection_date,
    i.inspection_type,
    i.inspector_name,
    c.crop_code, c.crop_name,
    v.variety_code, v.variety_name, v.variety_type,
    s.season_code, s.season_name, s.season_year, s.season_start_date,
    l.location_code, l.location_name, l.agro_climatic_zone, l.state_name, l.district_name,
    f.farm_code, f.farm_name, f.farmer_name,
    fd.field_code, fd.soil_type, fd.irrigation_type,
    p.plot_code,
    i.actual_soaking_date, i.actual_sowing_date, i.actual_transplant_date, i.actual_flowering_date,
    i.actual_pest_severity, i.actual_tiller_count, i.actual_health_score, i.actual_plant_ratio, i.actual_disease_severity,
    i.notes
FROM inspection i
JOIN crop c ON i.crop_id = c.crop_id
JOIN variety v ON i.variety_id = v.variety_id
JOIN season s ON i.season_id = s.season_id
JOIN farm f ON i.farm_id = f.farm_id
JOIN field fd ON i.field_id = fd.field_id
JOIN plot p ON i.plot_id = p.plot_id
JOIN location l ON f.location_id = l.location_id;

CREATE OR REPLACE VIEW v_variance_report AS
SELECT 
    fvs.summary_id,
    i.inspection_event_id,
    i.inspection_date,
    c.crop_name,
    v.variety_name,
    s.season_code,
    l.location_name,
    l.district_name,
    f.farmer_name,
    fvs.overall_variance_score,
    fvs.variance_category,
    fvs.attributes_evaluated,
    fvs.attributes_within_tolerance,
    fvs.primary_reason_code,
    fvs.reason_codes,
    fvs.top_variance_drivers
FROM fact_inspection_variance_summary fvs
JOIN inspection i ON fvs.inspection_id = i.inspection_id
JOIN crop c ON i.crop_id = c.crop_id
JOIN variety v ON i.variety_id = v.variety_id
JOIN season s ON i.season_id = s.season_id
JOIN farm f ON i.farm_id = f.farm_id
JOIN location l ON f.location_id = l.location_id;

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
